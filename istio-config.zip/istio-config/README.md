# Istio Service Mesh — Fintech Platform

Adds mTLS, mesh-level circuit breaking, and fine-grained traffic control
**alongside** the existing Harness Blue-Green pipelines, per your choice —
this does not replace how deploys happen, only how traffic behaves once
services are running.

## What this gets you that Kustomize/NetworkPolicy alone didn't

| Capability | Before (K8s NetworkPolicy) | With Istio |
|---|---|---|
| Service-to-service auth | IP/port matching only | Cryptographically verified identity (mTLS + SPIFFE) — a pod can't spoof being `api-gateway` just by getting the right IP |
| Encryption in transit (pod-to-pod) | None | Automatic, STRICT mTLS mesh-wide |
| Circuit breaking | App-level only (Resilience4j, api-gateway only) | Per-pod, network-level, on **every** service automatically via DestinationRule |
| Traffic shifting | All-or-nothing (Harness swap) | Weighted routing available as an option per-service |
| Retries/timeouts | App-level only, inconsistent across services | Centrally defined per-service in VirtualService, consistent policy |

## Structure

```
istio-config/
├── istio-install.yaml              # IstioOperator: HA control plane, ClusterIP ingress gateway
├── namespace-and-gateway.yaml      # namespace injection label + Istio Gateway/VirtualService for ingress
├── security/
│   ├── peer-authentication.yaml    # STRICT mTLS, mesh-wide
│   └── authorization-policies.yaml # who can call whom, by verified identity
└── traffic/
    ├── _template.yaml               # documented master pattern
    └── generated/<service>.yaml     # DestinationRule + VirtualService per service
```

## Install order (this matters)

```bash
# 1. Install Istio control plane
istioctl install -f istio-install.yaml -y

# 2. Enable sidecar injection + create the Gateway — do this BEFORE any
#    service pods exist, or they won't have sidecars until next recreated
kubectl apply -f namespace-and-gateway.yaml

# 3. Deploy/redeploy all 7 services (via Helm — see ../fintech-helm-chart/)
#    so every pod picks up the injected sidecar
helm upgrade --install ledger-service ../fintech-helm-chart -f ../fintech-helm-chart/values/ledger-service.yaml -n fintech
# ... repeat for all 7

# 4. Confirm every pod has 2/2 containers (app + istio-proxy) before continuing
kubectl get pods -n fintech

# 5. ONLY once every pod is meshed, apply strict mTLS — applying this
#    earlier would break communication for any not-yet-meshed pod
kubectl apply -f security/peer-authentication.yaml
kubectl apply -f security/authorization-policies.yaml

# 6. Apply traffic policies (circuit breaking, timeouts, retries)
kubectl apply -f traffic/generated/
```

## Circuit breaker tuning rationale

Payment-critical services (`ledger-service`, `upi-connector-service`,
`neft-rtgs-imps-connector-service`) use a **tighter** `consecutive5xxErrors`
threshold (3) than standard services (5) — a bad pod on the payment path
gets ejected from the routing pool faster, since the cost of routing even
a few more requests to a failing ledger/UPI pod is higher than for, say,
insurance premium collection. `maxEjectionPercent: 50` on every service is
a safety ceiling — even if more than half a service's pods look unhealthy
simultaneously (e.g. a bad deploy), Istio won't eject more than half,
avoiding a self-inflicted total outage from an overly aggressive breaker
during a genuinely bad rollout (Harness's rollback should catch that case
before it gets this far, but this is a second line of defense).

## Using Istio for a canary/experiment independent of Harness

The generated VirtualServices default to 100% weight on `subset: v1`, 0%
on `v2` — a pass-through with no behavior change. To run a quick traffic
experiment without going through a full Harness pipeline run:

```bash
# Deploy a v2 release of, say, insurance-payments-service
helm upgrade --install insurance-payments-service-v2 ../fintech-helm-chart \
  -f ../fintech-helm-chart/values/insurance-payments-service.yaml \
  --set version=v2 --set nameOverride=insurance-payments-service -n fintech

# Shift 10% of traffic to it
kubectl patch virtualservice insurance-payments-service -n fintech --type=merge -p '
spec:
  http:
  - route:
    - destination: {host: insurance-payments-service.fintech.svc.cluster.local, subset: v1}
      weight: 90
    - destination: {host: insurance-payments-service.fintech.svc.cluster.local, subset: v2}
      weight: 10
'
```

Treat this as a manual/experimental capability, not the primary deployment
path — Harness's approval gates and rollback automation are still the
system of record for real releases.

## Verify before relying on this in production

- **TLS certificate** (`fintech-tls-cert` referenced in the Gateway) isn't
  provisioned by anything here — wire up cert-manager with a
  Let's Encrypt/Google CA issuer, or import your existing certificate as a
  K8s TLS secret.
- **`istioctl analyze -n fintech`** — run this after any change to catch
  misconfigurations (missing subsets, orphaned VirtualServices) before they
  cause routing failures, Istio's own built-in linter.
- **Istio version compatibility with your GKE version** — verify against
  the current Istio/GKE compatibility matrix before installing; both
  projects move fast enough that this file's exact API versions
  (`security.istio.io/v1`, `networking.istio.io/v1`) should be confirmed
  against whatever Istio release you actually install.
