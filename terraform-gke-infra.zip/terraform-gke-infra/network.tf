# Private VPC — nodes get no public IPs (private cluster below), so Cloud
# NAT is required for pods to reach the internet (e.g. calling UPI/bank
# rail/insurer partner APIs, pulling images, hitting Google APIs).

resource "google_compute_network" "fintech_vpc" {
  name                    = "fintech-vpc-${var.environment}"
  auto_create_subnetworks = false
}

resource "google_compute_subnetwork" "fintech_subnet" {
  name          = "fintech-subnet-${var.environment}"
  ip_cidr_range = "10.10.0.0/20"
  region        = var.gcp_region
  network       = google_compute_network.fintech_vpc.id

  # Secondary ranges required for GKE's VPC-native (alias IP) networking —
  # separate ranges for Pod IPs and Service IPs, sized generously since
  # re-sizing a live cluster's ranges later is not possible.
  secondary_ip_range {
    range_name    = "gke-pods"
    ip_cidr_range = "10.20.0.0/14"
  }
  secondary_ip_range {
    range_name    = "gke-services"
    ip_cidr_range = "10.30.0.0/20"
  }

  private_ip_google_access = true
}

resource "google_compute_router" "fintech_router" {
  name    = "fintech-router-${var.environment}"
  region  = var.gcp_region
  network = google_compute_network.fintech_vpc.id
}

resource "google_compute_router_nat" "fintech_nat" {
  name                               = "fintech-nat-${var.environment}"
  router                             = google_compute_router.fintech_router.name
  region                             = var.gcp_region
  nat_ip_allocate_option             = "AUTO_ONLY"
  source_subnetwork_ip_ranges_to_nat = "ALL_SUBNETWORKS_ALL_IP_RANGES"

  # Logs NAT connections for audit/troubleshooting — useful when tracing an
  # outbound call to a BaaS/insurer partner during an incident.
  log_config {
    enable = true
    filter = "ERRORS_ONLY"
  }
}

# Private IP range reserved for Cloud SQL / Memorystore VPC peering
resource "google_compute_global_address" "private_service_range" {
  name          = "fintech-private-service-range-${var.environment}"
  purpose       = "VPC_PEERING"
  address_type  = "INTERNAL"
  prefix_length = 20
  network       = google_compute_network.fintech_vpc.id
}

resource "google_service_networking_connection" "private_vpc_connection" {
  network                 = google_compute_network.fintech_vpc.id
  service                 = "servicenetworking.googleapis.com"
  reserved_peering_ranges = [google_compute_global_address.private_service_range.name]
}
