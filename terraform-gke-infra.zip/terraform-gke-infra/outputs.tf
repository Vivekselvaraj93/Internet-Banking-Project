output "cluster_name" {
  value = google_container_cluster.fintech.name
}

output "cluster_endpoint" {
  value     = google_container_cluster.fintech.endpoint
  sensitive = true
}

output "get_credentials_command" {
  value = "gcloud container clusters get-credentials ${google_container_cluster.fintech.name} --region ${var.gcp_region} --project ${var.gcp_project_id}"
}

output "cloudsql_connection_name" {
  description = "Use this as the Cloud SQL Auth Proxy's connection string argument in each service's deployment sidecar"
  value       = google_sql_database_instance.fintech_postgres.connection_name
}

output "cloudsql_private_ip" {
  value = google_sql_database_instance.fintech_postgres.private_ip_address
}

output "redis_host" {
  value = google_redis_instance.fintech_redis.host
}

output "redis_port" {
  value = google_redis_instance.fintech_redis.port
}

output "service_account_emails" {
  value = { for k, v in google_service_account.service_identities : k => v.email }
}
