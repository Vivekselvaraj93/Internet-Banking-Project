# Memorystore for Redis, HA tier — backs the API Gateway's idempotency-key
# reservation (IdempotencyFilter) and rate limiting. STANDARD_HA provisions
# a replica in a second zone with automatic failover; losing this would
# briefly weaken (not eliminate — the ledger's own idempotency check via
# transactionId is the ultimate backstop) duplicate-request protection
# during the failover window, so HA tier is the right choice for this
# platform rather than BASIC.

resource "google_redis_instance" "fintech_redis" {
  name           = "fintech-redis-${var.environment}"
  region         = var.gcp_region
  tier           = var.redis_tier
  memory_size_gb = var.redis_memory_size_gb

  redis_version     = "REDIS_7_2"
  authorized_network = google_compute_network.fintech_vpc.id
  connect_mode       = "PRIVATE_SERVICE_ACCESS"

  depends_on = [google_service_networking_connection.private_vpc_connection]

  auth_enabled            = true
  transit_encryption_mode = "SERVER_AUTHENTICATION"

  maintenance_policy {
    weekly_maintenance_window {
      day = "SUNDAY"
      start_time {
        hours   = 20
        minutes = 30
      }
    }
  }
}
