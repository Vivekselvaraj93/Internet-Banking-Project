variable "gcp_project_id" {
  description = "GCP project ID"
  type        = string
}

variable "gcp_region" {
  description = "Primary region — a REGIONAL (not zonal) cluster spans all zones in this region for control-plane and node HA"
  type        = string
  default     = "us-central1"
}

variable "environment" {
  description = "Environment name, used in resource naming (dev/staging/production)"
  type        = string
  default     = "production"
}

variable "cluster_name" {
  description = "GKE cluster name"
  type        = string
  default     = "fintech-cluster"
}

# --- General-purpose node pool (auth, gateway, insurance, etc.) ---
variable "general_pool_machine_type" {
  type    = string
  default = "e2-standard-4"
}

variable "general_pool_min_nodes_per_zone" {
  description = "Minimum nodes PER ZONE — with 3 zones this means at least 3x this number cluster-wide"
  type        = number
  default     = 1
}

variable "general_pool_max_nodes_per_zone" {
  type    = number
  default = 5
}

# --- Payment-critical node pool (ledger, UPI, bank rails, orchestration) ---
# Isolated onto dedicated nodes via taint/toleration so a noisy-neighbor
# workload on the general pool can never starve payment processing of CPU/memory.
variable "payment_pool_machine_type" {
  type    = string
  default = "e2-standard-8"
}

variable "payment_pool_min_nodes_per_zone" {
  type    = number
  default = 2
}

variable "payment_pool_max_nodes_per_zone" {
  type    = number
  default = 10
}

# --- Cloud SQL (Postgres, regional HA) ---
variable "cloudsql_tier" {
  description = "Machine tier for the Cloud SQL HA instance"
  type        = string
  default     = "db-custom-4-16384" # 4 vCPU, 16GB RAM — size up for real production throughput
}

variable "cloudsql_disk_size_gb" {
  type    = number
  default = 100
}

# --- Memorystore (Redis, HA tier) ---
variable "redis_memory_size_gb" {
  type    = number
  default = 5
}

variable "redis_tier" {
  description = "BASIC (single node, no failover) or STANDARD_HA (replica + automatic failover)"
  type        = string
  default     = "STANDARD_HA"
}
