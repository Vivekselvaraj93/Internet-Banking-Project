# Two node pools, both spread across every zone in the region by default
# (GKE regional node pools auto-distribute across zones) — this is what
# lets pod anti-affinity + topology spread constraints (see k8s-ha-overlay)
# actually achieve zone-level fault tolerance, not just pod-count redundancy
# on the same physical failure domain.

# ------------------------------------------------------------------
# General-purpose pool: api-gateway, auth-service, insurance-payments-service,
# international-payments-service — real workloads but not the absolute
# highest-QPS, latency-critical path.
# ------------------------------------------------------------------
resource "google_container_node_pool" "general" {
  name     = "general-pool"
  location = var.gcp_region
  cluster  = google_container_cluster.fintech.name

  autoscaling {
    min_node_count = var.general_pool_min_nodes_per_zone
    max_node_count = var.general_pool_max_nodes_per_zone
  }

  management {
    auto_repair  = true
    auto_upgrade = true
  }

  node_config {
    machine_type = var.general_pool_machine_type
    disk_size_gb = 50
    disk_type    = "pd-ssd"

    workload_metadata_config {
      mode = "GKE_METADATA" # required for Workload Identity
    }

    shielded_instance_config {
      enable_secure_boot          = true
      enable_integrity_monitoring = true
    }

    labels = {
      workload-tier = "general"
    }
  }

  upgrade_settings {
    max_surge       = 1
    max_unavailable = 0 # never take capacity offline during a node upgrade
  }
}

# ------------------------------------------------------------------
# Payment-critical pool: ledger-service, upi-connector-service,
# neft-rtgs-imps-connector-service, payment-orchestration-service. Tainted
# so ONLY pods that explicitly tolerate it land here — isolates the highest
# -throughput, most latency-sensitive workloads from noisy neighbors on the
# general pool, and gives them a dedicated autoscaling budget so a traffic
# spike on, say, insurance-payments-service can never starve UPI processing
# of nodes to scale onto.
# ------------------------------------------------------------------
resource "google_container_node_pool" "payment_critical" {
  name     = "payment-critical-pool"
  location = var.gcp_region
  cluster  = google_container_cluster.fintech.name

  autoscaling {
    min_node_count = var.payment_pool_min_nodes_per_zone
    max_node_count = var.payment_pool_max_nodes_per_zone
  }

  management {
    auto_repair  = true
    auto_upgrade = true
  }

  node_config {
    machine_type = var.payment_pool_machine_type
    disk_size_gb = 100
    disk_type    = "pd-ssd"

    workload_metadata_config {
      mode = "GKE_METADATA"
    }

    shielded_instance_config {
      enable_secure_boot          = true
      enable_integrity_monitoring = true
    }

    labels = {
      workload-tier = "payment-critical"
    }

    taint {
      key    = "workload-tier"
      value  = "payment-critical"
      effect = "NO_SCHEDULE"
    }
  }

  upgrade_settings {
    max_surge       = 2 # larger surge budget given tighter latency/throughput requirements during a rolling node upgrade
    max_unavailable = 0
  }
}
