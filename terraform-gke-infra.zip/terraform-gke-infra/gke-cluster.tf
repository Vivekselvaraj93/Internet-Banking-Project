# A REGIONAL cluster (not zonal) replicates the control plane across 3
# zones in the region automatically — this is the single most important
# setting for control-plane HA. Combined with node pools spread across the
# same 3 zones (node-pools.tf), a full zone outage takes out at most 1/3 of
# capacity, not the whole cluster.

resource "google_container_cluster" "fintech" {
  provider = google-beta

  name     = "${var.cluster_name}-${var.environment}"
  location = var.gcp_region # region, not a zone => regional cluster

  network    = google_compute_network.fintech_vpc.id
  subnetwork = google_compute_subnetwork.fintech_subnet.id

  # We manage node pools explicitly (node-pools.tf) for separate
  # general-purpose vs payment-critical pools — the default node pool
  # created alongside the cluster is removed immediately.
  remove_default_node_pool = true
  initial_node_count       = 1

  networking_mode = "VPC_NATIVE"
  ip_allocation_policy {
    cluster_secondary_range_name  = "gke-pods"
    services_secondary_range_name = "gke-services"
  }

  # Private cluster: nodes have no public IPs. The control plane remains
  # reachable via its private endpoint from within the VPC (and from
  # authorized external CIDRs below, e.g. your CI/CD or admin IPs).
  private_cluster_config {
    enable_private_nodes    = true
    enable_private_endpoint = false # set true only once all cluster admin access is routed through a VPN/bastion
    master_ipv4_cidr_block  = "172.16.0.0/28"
  }

  master_authorized_networks_config {
    # Restrict this to your actual CI/CD runner and admin IP ranges before
    # applying — 0.0.0.0/0 here would defeat the purpose of a private cluster.
    cidr_blocks {
      cidr_block   = "0.0.0.0/0"
      display_name = "REPLACE_ME_WITH_ACTUAL_ADMIN_CIDRS"
    }
  }

  # Workload Identity — lets pods authenticate to GCP APIs (Secret Manager,
  # Cloud SQL, Artifact Registry) using a bound Kubernetes ServiceAccount
  # rather than mounted JSON key files. This is what each service's
  # k8s/03-deployment.yaml's `serviceAccountName: <service>-ksa` is designed
  # to work with (see the IAM bindings in iam.tf).
  workload_identity_config {
    workload_pool = "${var.gcp_project_id}.svc.id.goog"
  }

  # Regular release channel: automatic patch upgrades with a reasonable lag
  # behind Rapid, balancing security patching against stability — Stable is
  # more conservative still if your compliance posture prefers that.
  release_channel {
    channel = "REGULAR"
  }

  # Maintenance window during typically low-traffic hours — adjust to your
  # actual customer traffic pattern (this example assumes an India-market
  # platform, so 2-4 AM IST = 20:30-22:30 UTC).
  maintenance_policy {
    recurring_window {
      start_time = "2026-01-01T20:30:00Z"
      end_time   = "2026-01-01T22:30:00Z"
      recurrence = "FREQ=WEEKLY;BYDAY=SU"
    }
  }

  # Shielded GKE nodes: verified boot + integrity monitoring, standard
  # hardening for any production cluster and expected by most compliance frameworks.
  node_config {
    shielded_instance_config {
      enable_secure_boot          = true
      enable_integrity_monitoring = true
    }
  }

  addons_config {
    horizontal_pod_autoscaling {
      disabled = false
    }
    http_load_balancing {
      disabled = false
    }
    gcp_filestore_csi_driver_config {
      disabled = true # enable only if a service later needs ReadWriteMany volumes
    }
  }

  # Cluster-level logging/monitoring to Cloud Operations — feeds Cloud
  # Logging/Monitoring alongside (not instead of) the Prometheus/Grafana
  # stack built earlier; the two are complementary; Cloud Monitoring is
  # useful for GKE-infra-level signals Prometheus doesn't see out of the box.
  logging_config {
    enable_components = ["SYSTEM_COMPONENTS", "WORKLOADS"]
  }
  monitoring_config {
    enable_components = ["SYSTEM_COMPONENTS"]
    managed_prometheus {
      enabled = false # kube-prometheus-stack (self-managed) is already deployed; avoid running two Prometheus stacks unless intentionally federating them
    }
  }

  deletion_protection = true
}
