# Cloud SQL for Postgres, regional HA configuration: a synchronous standby
# in a second zone, automatic failover typically within 60s of a primary
# failure. This replaces the "self-managed Postgres pod" placeholder
# referenced in each service's DB_HOST default — production should point
# every service at this instance instead (via the Cloud SQL Auth Proxy
# sidecar, already stubbed out commented-in ledger-service's deployment.yaml).

resource "google_sql_database_instance" "fintech_postgres" {
  name             = "fintech-postgres-${var.environment}"
  database_version = "POSTGRES_16"
  region           = var.gcp_region

  deletion_protection = true

  depends_on = [google_service_networking_connection.private_vpc_connection]

  settings {
    tier              = var.cloudsql_tier
    availability_type = "REGIONAL" # this is what makes it HA — provisions a standby in a different zone with synchronous replication
    disk_size         = var.cloudsql_disk_size_gb
    disk_type         = "PD_SSD"
    disk_autoresize   = true

    ip_configuration {
      ipv4_enabled    = false # private IP only — no public endpoint
      private_network = google_compute_network.fintech_vpc.id
    }

    backup_configuration {
      enabled                        = true
      point_in_time_recovery_enabled = true
      start_time                     = "18:00" # UTC — adjust to a low-traffic window
      transaction_log_retention_days = 7
      backup_retention_settings {
        retained_backups = 30
      }
    }

    maintenance_window {
      day  = 7 # Sunday
      hour = 20
    }

    insights_config {
      query_insights_enabled  = true
      query_string_length     = 1024
      record_application_tags = true
    }

    database_flags {
      name  = "max_connections"
      value = "500" # size relative to (sum of each service's HikariCP maximum-pool-size) x replica count, with headroom
    }
  }
}

# One logical database per service — mirrors the DB_NAME each service's
# application.yml already expects (ledger, auth, upi, bankrails,
# intlpayments, insurance). Keeping them on one HA instance is a reasonable
# cost/ops tradeoff for an MVP-to-growth stage platform; split into separate
# instances later if any one service's load starts contending with others.
resource "google_sql_database" "service_databases" {
  for_each = toset([
    "ledger",
    "auth",
    "upi",
    "bankrails",
    "intlpayments",
    "insurance",
  ])

  name     = each.value
  instance = google_sql_database_instance.fintech_postgres.name
}

# One DB user per service, least-privilege (each service only knows its own
# password, stored in GCP Secret Manager and synced into K8s via the
# ExternalSecret templates already defined in each service's k8s/ folder).
resource "google_sql_user" "service_users" {
  for_each = toset([
    "ledger_app",
    "auth_app",
    "upi_app",
    "bankrails_app",
    "intlpayments_app",
    "insurance_app",
  ])

  name     = each.value
  instance = google_sql_database_instance.fintech_postgres.name
  password = "CHANGE_ME_SET_VIA_TERRAFORM_VARIABLE_OR_SECRET_MANAGER" # never leave this literal — see README
}
