# GKE Infrastructure — Terraform

Provisions the foundational infrastructure for a high-throughput, highly
available deployment of the fintech platform's 7 microservices.

## What this provisions

- **Regional (multi-zone) private GKE cluster** — control plane replicated
  across 3 zones automatically; nodes have no public IPs
- **Two node pools**: `general-pool` (api-gateway, auth, insurance, intl
  payments) and `payment-critical-pool` (ledger, UPI, bank rails —
  tainted/isolated so these workloads always have dedicated scaling headroom)
- **Cloud SQL for Postgres, REGIONAL (HA) availability** — synchronous
  standby in a second zone, automatic failover, replacing the placeholder
  in-cluster Postgres each service's `application.yml` currently defaults to
- **Memorystore Redis, STANDARD_HA tier** — backs API Gateway's idempotency
  and rate-limiting logic
- **Workload Identity bindings** — one scoped GCP service account per
  microservice, matching each service's existing `serviceAccountName` in
  its `k8s/03-deployment.yaml`
- **Private VPC + Cloud NAT** — no node has a public IP; outbound internet
  (for BaaS/insurer partner API calls) goes through Cloud NAT

## Why these specific choices matter for HA/throughput

| Choice | Effect |
|---|---|
| Regional cluster (not zonal) | Control plane survives a full zone outage |
| Node pools auto-spread across zones | Combined with pod anti-affinity (see `k8s-ha-overlay/`), a zone failure takes out at most ~1/3 of any service's pods |
| Separate payment-critical pool + taint | A traffic spike or bug in a lower-priority service can never starve the ledger/UPI/bank-rail pools of nodes to scale onto |
| Cloud SQL REGIONAL availability_type | Automatic failover to a synchronous standby, typically <60s, instead of a single point of failure |
| Redis STANDARD_HA | Idempotency-key reservation survives a Redis node failure |
| `max_unavailable = 0` on node pool upgrades | Node upgrades never reduce serving capacity |

## Usage

```bash
# One-time: create the remote state bucket
gsutil mb -l us-central1 gs://YOUR_PROJECT-terraform-state
gsutil versioning set on gs://YOUR_PROJECT-terraform-state

cp terraform.tfvars.example terraform.tfvars
# edit terraform.tfvars with your real project ID and sizing

terraform init
terraform plan -out=tfplan
terraform apply tfplan
```

Then connect kubectl to the new cluster:
```bash
terraform output get_credentials_command   # prints the exact gcloud command
```

## Before applying to a real environment

- **`master_authorized_networks_config`** in `gke-cluster.tf` currently
  allows `0.0.0.0/0` with a placeholder label — this MUST be locked down to
  your actual CI/CD runner and admin IP ranges before apply, or you've
  defeated the purpose of a private cluster.
- **`google_sql_user` passwords** in `cloudsql.tf` are literal placeholders
  — wire these to a `random_password` resource + Secret Manager, or pass
  via a Terraform variable sourced from your secrets pipeline. Never commit
  real passwords into `.tf` files.
- **Sizing** (machine types, node counts, Cloud SQL tier) are reasonable
  starting points, not load-tested numbers for your actual transaction
  volume — run a load test against staging and adjust before relying on
  these for production traffic.
- **Cost**: a regional cluster with 2 node pools (min 1+2 nodes per zone x
  3 zones) + regional Cloud SQL + HA Redis has real baseline cost even at
  idle (roughly several hundred USD/month before any traffic) — right-size
  `min_nodes_per_zone` down for a dev/staging copy of this same config.

## Migrating existing services onto this infrastructure

Each service's `k8s/01-configmap.yaml` currently defaults `DB_HOST` to an
in-cluster `postgres-service...` placeholder. Update it to
`terraform output cloudsql_private_ip`, and uncomment the Cloud SQL Auth
Proxy sidecar block already stubbed out (commented) in
`ledger-service/k8s/03-deployment.yaml` — apply the same sidecar pattern to
the other 5 database-backed services.
