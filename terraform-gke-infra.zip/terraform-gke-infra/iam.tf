# One GCP service account per microservice, bound to that service's
# Kubernetes ServiceAccount via Workload Identity. This is what lets each
# pod authenticate to Cloud SQL / Secret Manager / Artifact Registry
# without ever mounting a JSON key file — and critically, keeps each
# service's GCP permissions scoped to only what it needs (e.g.
# upi-connector-service's identity has no reason to touch Cloud SQL for
# the auth database).

locals {
  services = [
    "api-gateway",
    "ledger-service",
    "auth-service",
    "upi-connector-service",
    "neft-rtgs-imps-connector-service",
    "international-payments-service",
    "insurance-payments-service",
  ]
}

resource "google_service_account" "service_identities" {
  for_each = toset(local.services)

  account_id   = "${each.value}-gsa"
  display_name = "Workload Identity SA for ${each.value}"
}

# Binds each GCP service account to the matching Kubernetes ServiceAccount
# (namespace/name convention: fintech/<service>-ksa — matches
# `serviceAccountName` already set in every service's k8s/03-deployment.yaml).
resource "google_service_account_iam_member" "workload_identity_binding" {
  for_each = toset(local.services)

  service_account_id = google_service_account.service_identities[each.value].name
  role                = "roles/iam.workloadIdentityUser"
  member              = "serviceAccount:${var.gcp_project_id}.svc.id.goog[fintech/${each.value}-ksa]"
}

# Cloud SQL Client role — required for the Cloud SQL Auth Proxy sidecar
# pattern used by ledger-service, auth-service, and the connector services.
resource "google_project_iam_member" "cloudsql_client" {
  for_each = toset([
    "ledger-service", "auth-service", "upi-connector-service",
    "neft-rtgs-imps-connector-service", "international-payments-service",
    "insurance-payments-service",
  ])

  project = var.gcp_project_id
  role    = "roles/cloudsql.client"
  member  = "serviceAccount:${google_service_account.service_identities[each.value].email}"
}

# Secret Manager access — every service reads its own DB credentials/API
# keys via the ExternalSecret templates already defined per service.
resource "google_project_iam_member" "secret_accessor" {
  for_each = toset(local.services)

  project = var.gcp_project_id
  role    = "roles/secretmanager.secretAccessor"
  member  = "serviceAccount:${google_service_account.service_identities[each.value].email}"
}
