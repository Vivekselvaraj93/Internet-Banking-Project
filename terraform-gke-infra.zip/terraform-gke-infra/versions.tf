terraform {
  required_version = ">= 1.7.0"

  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.30"
    }
    google-beta = {
      source  = "hashicorp/google-beta"
      version = "~> 5.30"
    }
  }

  # Remote state is required for a production fintech workload — local state
  # risks loss/corruption and gives no locking against concurrent applies.
  # Create the bucket once, out of band, before running terraform init:
  #   gsutil mb -l us-central1 gs://YOUR_PROJECT-terraform-state
  #   gsutil versioning set on gs://YOUR_PROJECT-terraform-state
  backend "gcs" {
    bucket = "YOUR_PROJECT-terraform-state"
    prefix = "fintech-platform/gke"
  }
}

provider "google" {
  project = var.gcp_project_id
  region  = var.gcp_region
}

provider "google-beta" {
  project = var.gcp_project_id
  region  = var.gcp_region
}
