terraform {
  required_version = ">= 1.7.0"
  required_providers {
    google = { source = "hashicorp/google", version = "~> 5.30" }
  }
  backend "gcs" {
    prefix = "iam"
  }
}

# ------------------------------------------------------------------
# Google Groups are the recommended IAM grant target in any real landing
# zone — grant roles to a group, manage membership in Google Workspace/
# Cloud Identity admin console (or via the Cloud Identity Groups API,
# outside this Terraform's scope since it needs a separate, more
# sensitive set of permissions). NEVER grant IAM roles to individual user
# emails directly at the folder/org level — that becomes unmanageable and
# unauditable within months.
#
# This file assumes the groups below already exist (create once via
# Workspace admin console or `gcloud identity groups create`) — Terraform
# only manages what roles they're granted, not group membership itself.
# ------------------------------------------------------------------

locals {
  groups = {
    org_admins        = "gcp-organization-admins@${var.domain}"
    security_admins   = "gcp-security-admins@${var.domain}"
    network_admins    = "gcp-network-admins@${var.domain}"
    billing_admins    = "gcp-billing-admins@${var.domain}"
    developers        = "gcp-developers@${var.domain}"
    release_approvers = "gcp-fintech-release-approvers@${var.domain}" # matches the Harness user group referenced in harness-deployment/pipelines/*.yaml
  }
}

# ------------------------------------------------------------------
# Folder-level bindings — every project created under these folders
# inherits these grants automatically.
# ------------------------------------------------------------------

resource "google_folder_iam_member" "org_admins_folder_admin" {
  folder = var.fintech_platform_folder_id
  role   = "roles/resourcemanager.folderAdmin"
  member = "group:${local.groups.org_admins}"
}

resource "google_folder_iam_member" "security_admins_security" {
  folder = var.fintech_platform_folder_id
  role   = "roles/iam.securityAdmin"
  member = "group:${local.groups.security_admins}"
}

resource "google_folder_iam_member" "security_admins_scc" {
  folder = var.fintech_platform_folder_id
  role   = "roles/securitycenter.admin"
  member = "group:${local.groups.security_admins}"
}

resource "google_folder_iam_member" "network_admins_network" {
  folder = var.fintech_platform_folder_id
  role   = "roles/compute.networkAdmin"
  member = "group:${local.groups.network_admins}"
}

resource "google_folder_iam_member" "billing_admins_viewer" {
  folder = var.fintech_platform_folder_id
  role   = "roles/billing.viewer"
  member = "group:${local.groups.billing_admins}"
}

# Developers get a custom, deliberately narrow role in non-production
# only — full editor/owner is never appropriate even in dev, since dev
# projects still sit under the same data-residency org policy and
# shouldn't become a backdoor for bad habits that later get assumed safe
# in production.
resource "google_folder_iam_member" "developers_non_prod" {
  folder = var.non_production_folder_id
  role   = google_organization_iam_custom_role.fintech_developer.id
  member = "group:${local.groups.developers}"
}

# In production, developers get READ-ONLY by default. Actual deploys
# happen exclusively through the Harness pipelines (already built),
# authenticated as the Harness delegate's own service account, not as
# individual developers — this is what makes the two-person-approval rule
# in the Harness production pipelines meaningful rather than bypassable.
resource "google_folder_iam_member" "developers_prod_viewer" {
  folder = var.production_folder_id
  role   = "roles/viewer"
  member = "group:${local.groups.developers}"
}

resource "google_folder_iam_member" "release_approvers_prod" {
  folder = var.production_folder_id
  role   = "roles/logging.viewer" # able to inspect logs during an approval review, nothing more
  member = "group:${local.groups.release_approvers}"
}

# ------------------------------------------------------------------
# Custom role: fintech-developer — deploy/debug capability in
# non-production without full Editor (which includes IAM grant rights,
# billing changes, and org-policy-adjacent permissions no developer role
# should carry).
# ------------------------------------------------------------------
resource "google_organization_iam_custom_role" "fintech_developer" {
  org_id      = var.org_id
  role_id     = "fintechDeveloper"
  title       = "Fintech Platform Developer"
  description = "Deploy and debug access in non-production projects, without IAM/billing/org-policy permissions"
  permissions = [
    "container.pods.get",
    "container.pods.list",
    "container.pods.getLogs",
    "container.deployments.get",
    "container.deployments.list",
    "container.services.get",
    "container.services.list",
    "logging.logEntries.list",
    "monitoring.timeSeries.list",
    "cloudsql.instances.get",
    "cloudsql.instances.list",
  ]
}
