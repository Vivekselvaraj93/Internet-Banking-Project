variable "org_id" {
  type = string
}

variable "domain" {
  description = "Your Workspace/Cloud Identity domain, e.g. yourfintech.com"
  type        = string
}

variable "fintech_platform_folder_id" {
  description = "From 01-organization output: fintech_platform_folder_id"
  type        = string
}

variable "non_production_folder_id" {
  description = "From 01-organization output: non_production_folder_id"
  type        = string
}

variable "production_folder_id" {
  description = "From 01-organization output: production_folder_id"
  type        = string
}
