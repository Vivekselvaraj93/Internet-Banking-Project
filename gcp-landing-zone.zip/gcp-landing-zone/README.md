# GCP Landing Zone — Fintech Platform

The foundational layer everything else (the GKE cluster, Cloud SQL, Harness
delegate, Istio) is deployed onto. This is deliberately separate from
`terraform-gke-infra/` built earlier — that provisions a *cluster inside a
project*; this provisions *the organization structure, guardrails, and
projects themselves*. Apply this first, then adapt `terraform-gke-infra`
to deploy into the `production` (and `dev`/`staging`) projects this creates.

## Resource hierarchy this builds

```
Organization (yourfintech.com)
└── Folder: fintech-platform
    ├── Folder: bootstrap
    │   └── Project: fintech-bootstrap        (Terraform state, seed IAM — created manually once, see 00-bootstrap/)
    ├── Folder: shared-services
    │   └── Project: fintech-shared-services   (Shared VPC host, Artifact Registry, central logging, KMS)
    ├── Folder: non-production
    │   ├── Project: fintech-dev
    │   └── Project: fintech-staging
    └── Folder: production
        └── Project: fintech-production
```

## Why folders, not just projects

Folders are where **org policy constraints** (data residency, IAM
restrictions, network controls) actually get inherited down to every
project underneath — this is the mechanism that makes "RBI requires
payment data to stay in India" an *enforced technical control* rather than
just a line in a compliance document. `production` gets the strictest
policies; `non-production` gets slightly relaxed ones (e.g. dev needs
faster iteration, doesn't need the same data-residency lock given it
shouldn't hold real customer data anyway).

## Stages and deployment order

Each numbered folder is an **independent Terraform root module with its
own state file** — this is intentional, not an oversight. A landing zone
that's one giant Terraform configuration means every change (even a minor
IAM tweak) risks touching your entire org's blast radius. Separate state
per stage means a networking change can't accidentally re-plan your
billing budgets.

| Stage | Provisions | Depends on |
|---|---|---|
| `00-bootstrap` | The seed project holding Terraform state buckets for every other stage, and the CI/CD service account that runs `terraform apply` for stages 01+ | Nothing — created first, largely by hand or a minimal manual bootstrap |
| `01-organization` | Folder hierarchy, org policy constraints (data residency, IAM domain restriction, no external IPs, no SA keys) | `00-bootstrap` |
| `02-iam` | Google Groups → custom roles → IAM bindings at folder level | `01-organization` |
| `03-projects` | The actual dev/staging/production/shared-services projects, API enablement, Artifact Registry | `01-organization` |
| `04-networking` | Shared VPC host (in shared-services), subnets per environment, Cloud NAT, firewall baseline, service-project attachment | `03-projects` |
| `05-security` | Central KMS keyring, org-level audit log sink, VPC Service Controls perimeter around production | `03-projects`, `04-networking` |
| `06-billing` | Budget alerts per project | `03-projects` |

Apply in order:
```bash
cd 00-bootstrap && terraform init && terraform apply
cd ../01-organization && terraform init && terraform apply
cd ../02-iam && terraform init && terraform apply
cd ../03-projects && terraform init && terraform apply
cd ../04-networking && terraform init && terraform apply
cd ../05-security && terraform init && terraform apply
cd ../06-billing && terraform init && terraform apply
```

## Connecting this to what's already built

- `terraform-gke-infra/` (the GKE cluster) should be re-pointed at the
  `fintech-production` project this landing zone creates, and its VPC/subnet
  resources should be **removed** in favor of attaching to the Shared VPC
  this landing zone's `03-networking` stage creates instead — a real
  landing zone centralizes networking in the Shared VPC host project rather
  than each workload project managing its own VPC.
- Artifact Registry (referenced by every service's Dockerfile push target
  and Harness connector) should move to `fintech-shared-services`, shared
  across environments rather than duplicated per project.
- The Harness Delegate should run inside `fintech-shared-services` or
  directly in each environment's cluster — either works; running it
  centrally in shared-services and granting it cross-project deploy
  permissions is simpler to operate at your current scale.

## RBI data localization — where this is actually enforced

`01-organization/folders-and-policies.tf` applies the `gcp.resourceLocations`
org policy constraint at the `fintech-platform` folder level, restricting
**every resource created in every project under it** to `asia-south1`
(Mumbai) and `asia-south2` (Delhi) — the two GCP regions in India. This is
the technical backstop that makes data residency non-negotiable rather than
a matter of remembering to pick the right region in every future Terraform
apply: even a well-meaning engineer who forgets and tries to spin up a
`us-central1` Cloud SQL instance will have the request rejected by the
policy, not just caught in review.

**Important**: this means `terraform-gke-infra`'s default region
(`us-central1`) must be changed to `asia-south1` before deploying into the
projects this landing zone creates — that default was written before this
constraint existed. Update `gcp_region` in that stage's `terraform.tfvars`.
