variable "bootstrap_project_id" {
  description = "The manually-created seed project ID that will hold Terraform state for all other stages"
  type        = string
}

variable "region" {
  description = "GCP region for state buckets — kept in-region for data residency from day one"
  type        = string
  default     = "asia-south1" # Mumbai — see README's RBI data localization note
}

output "state_bucket_names" {
  value = { for k, v in google_storage_bucket.terraform_state : k => v.name }
}

output "terraform_ci_service_account_email" {
  value = google_service_account.terraform_ci.email
}
