# The bootstrap project is the one piece of this landing zone that isn't
# fully hands-off Terraform — a Terraform state bucket can't store the
# state of the project that creates it. The realistic sequence is:
#   1. Create the bootstrap project by hand (or via `gcloud`) once, linked
#      to your billing account.
#   2. Run THIS stage against it with local state (just this once) to
#      create the state buckets every other stage will use.
#   3. From then on, stages 01+ are fully automated with remote state.
#
# This file documents that one-time manual step and then codifies
# everything reproducible after it.

terraform {
  required_version = ">= 1.7.0"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.30"
    }
  }
  # Deliberately local state for this stage only — see explanation above.
}

provider "google" {
  project = var.bootstrap_project_id
  region  = var.region
}

# ------------------------------------------------------------------
# One GCS bucket per downstream stage, each with versioning (state history
# / recovery) and a retention-friendly lifecycle. Separate buckets (not one
# shared bucket with prefixes) so IAM on state access can be scoped
# per-stage — e.g. only security-admins can read 05-security's state,
# which may contain sensitive KMS key material references.
# ------------------------------------------------------------------
locals {
  stages = [
    "organization",
    "iam",
    "networking",
    "projects",
    "security",
    "billing",
  ]
}

resource "google_storage_bucket" "terraform_state" {
  for_each = toset(local.stages)

  name     = "${var.bootstrap_project_id}-tfstate-${each.value}"
  location = var.region
  project  = var.bootstrap_project_id

  versioning {
    enabled = true
  }

  uniform_bucket_level_access = true

  lifecycle_rule {
    condition {
      num_newer_versions = 20
    }
    action {
      type = "Delete"
    }
  }

  # Data residency — even Terraform state (which can contain sensitive
  # resource IDs/config) stays in-region from day one.
  # location is already asia-south1 via var.region default.
}

# ------------------------------------------------------------------
# CI/CD service account that will actually run `terraform apply` for
# stages 01-06 going forward (e.g. from a Cloud Build trigger, or a
# Harness pipeline dedicated to infra changes — separate from the
# application deploy pipelines already built). Broad org-level permissions
# are granted narrowly and explicitly in each downstream stage's IAM,
# not blanket-granted here.
# ------------------------------------------------------------------
resource "google_service_account" "terraform_ci" {
  project      = var.bootstrap_project_id
  account_id   = "terraform-landing-zone-ci"
  display_name = "Terraform CI/CD — Landing Zone stages 01-06"
}

resource "google_storage_bucket_iam_member" "ci_state_access" {
  for_each = google_storage_bucket.terraform_state

  bucket = each.value.name
  role   = "roles/storage.objectAdmin"
  member = "serviceAccount:${google_service_account.terraform_ci.email}"
}
