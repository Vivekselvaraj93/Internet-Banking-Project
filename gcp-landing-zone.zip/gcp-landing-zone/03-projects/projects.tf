terraform {
  required_version = ">= 1.7.0"
  required_providers {
    google = { source = "hashicorp/google", version = "~> 5.30" }
  }
  backend "gcs" {
    prefix = "projects"
  }
}

locals {
  # APIs every environment project needs — matches what terraform-gke-infra
  # and the application services actually use (GKE, Cloud SQL, Redis,
  # Secret Manager, Artifact Registry, Cloud Build for CI).
  common_apis = [
    "container.googleapis.com",
    "sqladmin.googleapis.com",
    "redis.googleapis.com",
    "secretmanager.googleapis.com",
    "artifactregistry.googleapis.com",
    "cloudbuild.googleapis.com",
    "compute.googleapis.com",
    "servicenetworking.googleapis.com",
    "cloudkms.googleapis.com",
    "logging.googleapis.com",
    "monitoring.googleapis.com",
    "iam.googleapis.com",
    "iamcredentials.googleapis.com",
    "cloudresourcemanager.googleapis.com",
  ]
}

resource "google_project" "shared_services" {
  name            = "fintech-shared-services"
  project_id      = "fintech-shared-services"
  folder_id       = var.shared_services_folder_id
  billing_account = var.billing_account_id
}

resource "google_project" "dev" {
  name            = "fintech-dev"
  project_id      = "fintech-dev"
  folder_id       = var.non_production_folder_id
  billing_account = var.billing_account_id
}

resource "google_project" "staging" {
  name            = "fintech-staging"
  project_id      = "fintech-staging"
  folder_id       = var.non_production_folder_id
  billing_account = var.billing_account_id
}

resource "google_project" "production" {
  name            = "fintech-production"
  project_id      = "fintech-production"
  folder_id       = var.production_folder_id
  billing_account = var.billing_account_id
}

locals {
  all_projects = {
    shared_services = google_project.shared_services.project_id
    dev             = google_project.dev.project_id
    staging         = google_project.staging.project_id
    production      = google_project.production.project_id
  }
}

resource "google_project_service" "apis" {
  for_each = {
    for pair in setproduct(keys(local.all_projects), local.common_apis) :
    "${pair[0]}.${pair[1]}" => {
      project = local.all_projects[pair[0]]
      api     = pair[1]
    }
  }

  project            = each.value.project
  service            = each.value.api
  disable_on_destroy = false
}

# Artifact Registry lives centrally in shared-services, shared across all
# environments — replaces the per-environment assumption in each service's
# earlier Dockerfile/cloudbuild.yaml (us-central1-docker.pkg.dev/...) —
# update those to point at this registry instead, in asia-south1 per the
# data residency policy.
resource "google_artifact_registry_repository" "fintech_images" {
  project       = google_project.shared_services.project_id
  location      = var.region
  repository_id = "fintech-images"
  format        = "DOCKER"
  description   = "Container images for all fintech platform microservices, shared across dev/staging/production"

  depends_on = [google_project_service.apis]
}
