variable "billing_account_id" {
  description = "Find via: gcloud billing accounts list"
  type        = string
}

variable "shared_services_folder_id" {
  type = string
}

variable "non_production_folder_id" {
  type = string
}

variable "production_folder_id" {
  type = string
}

variable "region" {
  type    = string
  default = "asia-south1"
}

output "shared_services_project_id" {
  value = google_project.shared_services.project_id
}

output "dev_project_id" {
  value = google_project.dev.project_id
}

output "staging_project_id" {
  value = google_project.staging.project_id
}

output "production_project_id" {
  value = google_project.production.project_id
}

output "artifact_registry_url" {
  value = "${var.region}-docker.pkg.dev/${google_project.shared_services.project_id}/${google_artifact_registry_repository.fintech_images.repository_id}"
}
