terraform {
  required_version = ">= 1.7.0"
  required_providers {
    google = { source = "hashicorp/google", version = "~> 5.30" }
  }
  backend "gcs" {
    prefix = "billing"
  }
}

# Budget alerts don't stop spend by themselves — they notify. Pair this
# with a real on-call process for the notification channel below, or a
# runaway HPA (see fintech-helm-chart's autoscaling.maxReplicas) scaling
# to its ceiling under a traffic spike could burn budget for hours before
# a human notices.

resource "google_monitoring_notification_channel" "billing_alerts" {
  project      = var.shared_services_project_id
  display_name = "Fintech Platform Billing Alerts"
  type         = "email"
  labels = {
    email_address = var.billing_alert_email
  }
}

locals {
  budgets = {
    dev = {
      project_id = var.dev_project_id
      amount_inr = 50000
    }
    staging = {
      project_id = var.staging_project_id
      amount_inr = 100000
    }
    production = {
      project_id = var.production_project_id
      amount_inr = 500000 # size against your actual terraform-gke-infra + Cloud SQL + Redis sizing, this is a placeholder starting point
    }
  }
}

resource "google_billing_budget" "environment_budgets" {
  for_each = local.budgets

  billing_account = var.billing_account_id
  display_name    = "fintech-${each.key}-monthly-budget"

  budget_filter {
    projects = ["projects/${each.value.project_id}"]
  }

  amount {
    specified_amount {
      currency_code = "INR"
      units         = each.value.amount_inr
    }
  }

  # Alert at 50%, 80%, 100%, and 120% (overrun) of budget — the 120%
  # threshold specifically catches a genuine runaway (e.g. an
  # autoscaler stuck at max replicas, or a misconfigured Cloud SQL tier
  # change) rather than just ordinary approach-to-budget.
  threshold_rules {
    threshold_percent = 0.5
  }
  threshold_rules {
    threshold_percent = 0.8
  }
  threshold_rules {
    threshold_percent = 1.0
  }
  threshold_rules {
    threshold_percent = 1.2
  }

  all_updates_rule {
    monitoring_notification_channels = [google_monitoring_notification_channel.billing_alerts.id]
  }
}
