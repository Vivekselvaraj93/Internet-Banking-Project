variable "billing_account_id" { type = string }
variable "shared_services_project_id" { type = string }
variable "dev_project_id" { type = string }
variable "staging_project_id" { type = string }
variable "production_project_id" { type = string }
variable "billing_alert_email" {
  description = "Where budget threshold alerts are sent — route to a real on-call channel, not a personal inbox"
  type        = string
}
