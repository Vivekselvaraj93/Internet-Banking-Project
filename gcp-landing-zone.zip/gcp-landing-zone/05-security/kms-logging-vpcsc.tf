terraform {
  required_version = ">= 1.7.0"
  required_providers {
    google      = { source = "hashicorp/google", version = "~> 5.30" }
    google-beta = { source = "hashicorp/google-beta", version = "~> 5.30" }
  }
  backend "gcs" {
    prefix = "security"
  }
}

# ------------------------------------------------------------------
# Central KMS keyring — encrypts Cloud SQL (CMEK), GCS buckets, and
# Secret Manager entries across all environments with keys your
# organization controls the lifecycle of, rather than relying solely on
# Google's default encryption. A real requirement for many fintech
# compliance frameworks (and good practice regardless).
# ------------------------------------------------------------------
resource "google_kms_key_ring" "fintech" {
  project  = var.shared_services_project_id
  name     = "fintech-keyring"
  location = var.region
}

resource "google_kms_crypto_key" "cloudsql_cmek" {
  name            = "cloudsql-cmek"
  key_ring        = google_kms_key_ring.fintech.id
  rotation_period = "7776000s" # 90 days

  lifecycle {
    prevent_destroy = true # destroying a KMS key that's encrypting live data is catastrophic and irreversible
  }
}

resource "google_kms_crypto_key" "secrets_cmek" {
  name            = "secrets-cmek"
  key_ring        = google_kms_key_ring.fintech.id
  rotation_period = "7776000s"

  lifecycle {
    prevent_destroy = true
  }
}

# ------------------------------------------------------------------
# Organization-level aggregated audit log sink — every Admin Activity,
# Data Access, and System Event log across EVERY project under
# fintech-platform flows into one central, tamper-evident destination.
# This is what lets you answer "who did what, when" across the whole
# platform during an incident or regulatory audit, rather than hunting
# through per-project logs (some of which a compromised project's own
# IAM could have been used to delete).
# ------------------------------------------------------------------
resource "google_logging_organization_sink" "audit_sink" {
  name             = "fintech-audit-sink"
  org_id           = var.org_id
  include_children = true
  destination      = "storage.googleapis.com/${google_storage_bucket.audit_logs.name}"

  filter = <<-EOT
    logName:"cloudaudit.googleapis.com"
  EOT
}

resource "google_storage_bucket" "audit_logs" {
  project  = var.shared_services_project_id
  name     = "${var.shared_services_project_id}-audit-logs"
  location = var.region

  uniform_bucket_level_access = true

  # 7-year retention — a reasonable starting point for financial audit
  # trail requirements; confirm the exact figure against your specific
  # regulatory obligations (this varies by transaction type and
  # jurisdiction) before relying on this default.
  retention_policy {
    retention_period = 220752000 # ~7 years in seconds
    is_locked         = false     # keep false until you're certain of the exact retention requirement — locking is irreversible
  }

  lifecycle_rule {
    condition {
      age = 2555 # 7 years
    }
    action {
      type = "Delete"
    }
  }
}

resource "google_storage_bucket_iam_member" "sink_writer" {
  bucket = google_storage_bucket.audit_logs.name
  role   = "roles/storage.objectCreator"
  member = google_logging_organization_sink.audit_sink.writer_identity
}

# ------------------------------------------------------------------
# VPC Service Controls — draws a hard perimeter around the production
# project's APIs (Cloud SQL, Storage, Secret Manager) so that even a
# correctly-authenticated identity CANNOT exfiltrate data to a resource
# outside the perimeter (e.g. copying a Cloud SQL export to a personal GCS
# bucket) — this defends against credential theft/insider risk in a way
# IAM alone cannot, since IAM only asks "is this identity allowed", not
# "is this destination allowed regardless of identity".
#
# VPC-SC is genuinely complex to operate correctly (it WILL block
# legitimate cross-project calls unless every access pattern is explicitly
# allowed via access levels/bridges) — this is provided as a foundational
# starting point, not a set-and-forget config. Budget real time to test
# thoroughly in staging before enabling STRICT enforcement in production,
# and expect to iterate on the access policy below.
# ------------------------------------------------------------------
resource "google_access_context_manager_access_policy" "fintech" {
  parent = "organizations/${var.org_id}"
  title  = "fintech-platform-access-policy"
}

resource "google_access_context_manager_service_perimeter" "production_perimeter" {
  parent = "accessPolicies/${google_access_context_manager_access_policy.fintech.name}"
  name   = "accessPolicies/${google_access_context_manager_access_policy.fintech.name}/servicePerimeters/production_perimeter"
  title  = "production_perimeter"

  status {
    restricted_services = [
      "sqladmin.googleapis.com",
      "storage.googleapis.com",
      "secretmanager.googleapis.com",
    ]
    resources = [
      "projects/${var.production_project_number}",
    ]
  }
}
