variable "org_id" { type = string }
variable "shared_services_project_id" { type = string }
variable "production_project_number" {
  description = "Numeric project number (not ID) of fintech-production — required by VPC-SC"
  type        = string
}
variable "region" {
  type    = string
  default = "asia-south1"
}
