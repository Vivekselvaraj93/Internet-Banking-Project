terraform {
  required_version = ">= 1.7.0"
  required_providers {
    google = { source = "hashicorp/google", version = "~> 5.30" }
  }
  backend "gcs" {
    prefix = "networking"
  }
}

# ------------------------------------------------------------------
# Shared VPC: one host project (shared-services) owns the actual network;
# dev/staging/production attach as SERVICE projects and deploy resources
# (GKE clusters, Cloud SQL private IPs) into subnets owned by the host.
# This is the standard landing-zone networking pattern — centralizes
# firewall rules, Cloud NAT, and DNS in one place instead of each
# environment reinventing its own, while still keeping IAM/billing/quotas
# separate per environment project.
#
# This REPLACES the standalone VPC that terraform-gke-infra/network.tf
# created — that file assumed a single-project world; re-point
# terraform-gke-infra's GKE cluster at THIS shared VPC's subnets instead
# once this stage is applied, and remove its own network.tf resources.
# ------------------------------------------------------------------

resource "google_compute_network" "shared_vpc_host" {
  project                 = var.shared_services_project_id
  name                    = "fintech-shared-vpc"
  auto_create_subnetworks = false
}

resource "google_compute_shared_vpc_host_project" "host" {
  project = var.shared_services_project_id
}

resource "google_compute_shared_vpc_service_project" "dev" {
  host_project    = var.shared_services_project_id
  service_project = var.dev_project_id
  depends_on      = [google_compute_shared_vpc_host_project.host]
}

resource "google_compute_shared_vpc_service_project" "staging" {
  host_project    = var.shared_services_project_id
  service_project = var.staging_project_id
  depends_on      = [google_compute_shared_vpc_host_project.host]
}

resource "google_compute_shared_vpc_service_project" "production" {
  host_project    = var.shared_services_project_id
  service_project = var.production_project_id
  depends_on      = [google_compute_shared_vpc_host_project.host]
}

# ------------------------------------------------------------------
# One subnet per environment, in asia-south1 per the data-residency org
# policy — non-overlapping ranges so a future VPC peering or on-prem VPN
# never hits a CIDR collision.
# ------------------------------------------------------------------
resource "google_compute_subnetwork" "dev" {
  project       = var.shared_services_project_id
  name          = "fintech-dev-subnet"
  region        = var.region
  network       = google_compute_network.shared_vpc_host.id
  ip_cidr_range = "10.10.0.0/20"

  secondary_ip_range {
    range_name    = "gke-pods"
    ip_cidr_range = "10.110.0.0/14"
  }
  secondary_ip_range {
    range_name    = "gke-services"
    ip_cidr_range = "10.120.0.0/20"
  }

  private_ip_google_access = true
}

resource "google_compute_subnetwork" "staging" {
  project       = var.shared_services_project_id
  name          = "fintech-staging-subnet"
  region        = var.region
  network       = google_compute_network.shared_vpc_host.id
  ip_cidr_range = "10.20.0.0/20"

  secondary_ip_range {
    range_name    = "gke-pods"
    ip_cidr_range = "10.130.0.0/14"
  }
  secondary_ip_range {
    range_name    = "gke-services"
    ip_cidr_range = "10.140.0.0/20"
  }

  private_ip_google_access = true
}

resource "google_compute_subnetwork" "production" {
  project       = var.shared_services_project_id
  name          = "fintech-production-subnet"
  region        = var.region
  network       = google_compute_network.shared_vpc_host.id
  ip_cidr_range = "10.30.0.0/20"

  secondary_ip_range {
    range_name    = "gke-pods"
    ip_cidr_range = "10.150.0.0/14"
  }
  secondary_ip_range {
    range_name    = "gke-services"
    ip_cidr_range = "10.160.0.0/20"
  }

  private_ip_google_access = true
}

# Grant each environment project's future GKE service agent the ability
# to use the host project's specific subnet — required for Shared VPC to
# actually let a service-project GKE cluster deploy into these subnets.
resource "google_compute_subnetwork_iam_member" "dev_gke_user" {
  project    = var.shared_services_project_id
  region     = var.region
  subnetwork = google_compute_subnetwork.dev.name
  role       = "roles/compute.networkUser"
  member     = "serviceAccount:${var.dev_project_number}@cloudservices.gserviceaccount.com"
}

resource "google_compute_subnetwork_iam_member" "staging_gke_user" {
  project    = var.shared_services_project_id
  region     = var.region
  subnetwork = google_compute_subnetwork.staging.name
  role       = "roles/compute.networkUser"
  member     = "serviceAccount:${var.staging_project_number}@cloudservices.gserviceaccount.com"
}

resource "google_compute_subnetwork_iam_member" "production_gke_user" {
  project    = var.shared_services_project_id
  region     = var.region
  subnetwork = google_compute_subnetwork.production.name
  role       = "roles/compute.networkUser"
  member     = "serviceAccount:${var.production_project_number}@cloudservices.gserviceaccount.com"
}

# ------------------------------------------------------------------
# One Cloud Router + NAT per region, shared by all three environment
# subnets — private nodes in any environment reach the internet (BaaS/
# insurer partner APIs) through this single, centrally-audited egress path.
# ------------------------------------------------------------------
resource "google_compute_router" "shared_router" {
  project = var.shared_services_project_id
  name    = "fintech-shared-router"
  region  = var.region
  network = google_compute_network.shared_vpc_host.id
}

resource "google_compute_router_nat" "shared_nat" {
  project                            = var.shared_services_project_id
  name                               = "fintech-shared-nat"
  router                             = google_compute_router.shared_router.name
  region                             = var.region
  nat_ip_allocate_option             = "AUTO_ONLY"
  source_subnetwork_ip_ranges_to_nat = "ALL_SUBNETWORKS_ALL_IP_RANGES"

  log_config {
    enable = true
    filter = "ERRORS_ONLY"
  }
}

# Baseline firewall: deny all ingress by default (GKE/Istio-level policies
# from k8s-ha-overlay and istio-config handle intra-cluster traffic
# control; this is the VPC-level backstop), allow only health-check ranges
# and internal RFC1918 traffic.
resource "google_compute_firewall" "deny_all_ingress" {
  project   = var.shared_services_project_id
  name      = "deny-all-ingress"
  network   = google_compute_network.shared_vpc_host.id
  priority  = 65534
  direction = "INGRESS"
  deny {
    protocol = "all"
  }
  source_ranges = ["0.0.0.0/0"]
}

resource "google_compute_firewall" "allow_internal" {
  project   = var.shared_services_project_id
  name      = "allow-internal"
  network   = google_compute_network.shared_vpc_host.id
  priority  = 1000
  direction = "INGRESS"
  allow {
    protocol = "all"
  }
  source_ranges = ["10.0.0.0/8"]
}

resource "google_compute_firewall" "allow_gcp_health_checks" {
  project   = var.shared_services_project_id
  name      = "allow-gcp-health-checks"
  network   = google_compute_network.shared_vpc_host.id
  priority  = 1000
  direction = "INGRESS"
  allow {
    protocol = "tcp"
  }
  # GCP's documented health-check source ranges
  source_ranges = ["35.191.0.0/16", "130.211.0.0/22"]
}
