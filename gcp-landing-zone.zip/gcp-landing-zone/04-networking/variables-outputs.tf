variable "shared_services_project_id" { type = string }
variable "dev_project_id" { type = string }
variable "staging_project_id" { type = string }
variable "production_project_id" { type = string }

# Project numbers (not IDs) are required for the Shared VPC service-agent
# IAM grants — find via: gcloud projects describe <project_id> --format='value(projectNumber)'
variable "dev_project_number" { type = string }
variable "staging_project_number" { type = string }
variable "production_project_number" { type = string }

variable "region" {
  type    = string
  default = "asia-south1"
}

output "shared_vpc_id" {
  value = google_compute_network.shared_vpc_host.id
}

output "dev_subnet_self_link" {
  value = google_compute_subnetwork.dev.self_link
}

output "staging_subnet_self_link" {
  value = google_compute_subnetwork.staging.self_link
}

output "production_subnet_self_link" {
  value = google_compute_subnetwork.production.self_link
}
