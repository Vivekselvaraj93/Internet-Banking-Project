variable "org_id" {
  description = "Numeric GCP Organization ID (find via: gcloud organizations list)"
  type        = string
}

variable "org_customer_id" {
  description = "Cloud Identity/Workspace customer ID (find via: gcloud organizations describe <org_id> --format='value(owner.directoryCustomerId)') — used for the domain-restricted-sharing policy"
  type        = string
}

variable "region" {
  type    = string
  default = "asia-south1"
}

output "fintech_platform_folder_id" {
  value = google_folder.fintech_platform.name
}

output "shared_services_folder_id" {
  value = google_folder.shared_services.name
}

output "non_production_folder_id" {
  value = google_folder.non_production.name
}

output "production_folder_id" {
  value = google_folder.production.name
}
