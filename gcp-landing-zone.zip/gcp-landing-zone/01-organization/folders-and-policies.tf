terraform {
  required_version = ">= 1.7.0"
  required_providers {
    google      = { source = "hashicorp/google", version = "~> 5.30" }
    google-beta = { source = "hashicorp/google-beta", version = "~> 5.30" }
  }
  backend "gcs" {
    # bucket filled in via -backend-config at init time, using the
    # 00-bootstrap output: terraform init -backend-config="bucket=<state_bucket_names.organization>"
    prefix = "organization"
  }
}

provider "google" {
  region = var.region
}

# ------------------------------------------------------------------
# Folder hierarchy — see README for the full tree diagram.
# ------------------------------------------------------------------
resource "google_folder" "fintech_platform" {
  display_name = "fintech-platform"
  parent       = "organizations/${var.org_id}"
}

resource "google_folder" "shared_services" {
  display_name = "shared-services"
  parent       = google_folder.fintech_platform.name
}

resource "google_folder" "non_production" {
  display_name = "non-production"
  parent       = google_folder.fintech_platform.name
}

resource "google_folder" "production" {
  display_name = "production"
  parent       = google_folder.fintech_platform.name
}

# ------------------------------------------------------------------
# Org policy constraints applied at the fintech_platform folder — every
# project created under ANY of the three sub-folders inherits these
# automatically, with no per-project action required.
# ------------------------------------------------------------------

# THE constraint that makes RBI data localization an enforced technical
# control rather than a documentation promise. Every resource
# (Compute, Cloud SQL, GCS, etc.) created anywhere under fintech-platform
# must be in one of these two Indian regions, full stop.
resource "google_org_policy_policy" "resource_locations" {
  name   = "${google_folder.fintech_platform.name}/policies/gcp.resourceLocations"
  parent = google_folder.fintech_platform.name

  spec {
    rules {
      values {
        allowed_values = [
          "in:asia-south1-locations",  # Mumbai
          "in:asia-south2-locations",  # Delhi
        ]
      }
    }
  }
}

# No exported/downloadable service account keys anywhere under this
# folder — forces Workload Identity (already how every service in
# terraform-gke-infra's iam.tf authenticates) instead of long-lived key
# files that can leak.
resource "google_org_policy_policy" "disable_sa_key_creation" {
  name   = "${google_folder.fintech_platform.name}/policies/iam.disableServiceAccountKeyCreation"
  parent = google_folder.fintech_platform.name

  spec {
    rules {
      enforce = "TRUE"
    }
  }
}

# No VM or GKE node ever gets a public IP — everything reaches the
# internet via Cloud NAT only (consistent with terraform-gke-infra's
# private cluster design, now enforced org-wide rather than
# per-configuration best-effort).
resource "google_org_policy_policy" "restrict_vm_external_ip" {
  name   = "${google_folder.fintech_platform.name}/policies/compute.vmExternalIpAccess"
  parent = google_folder.fintech_platform.name

  spec {
    rules {
      deny_all = "TRUE"
    }
  }
}

# Only identities from your own Google Workspace/Cloud Identity domain can
# ever be granted IAM roles on anything under this folder — blocks an
# accidental grant to a personal Gmail address, a real and common
# misconfiguration.
resource "google_org_policy_policy" "domain_restricted_sharing" {
  name   = "${google_folder.fintech_platform.name}/policies/iam.allowedPolicyMemberDomains"
  parent = google_folder.fintech_platform.name

  spec {
    rules {
      values {
        allowed_values = [var.org_customer_id] # your Cloud Identity/Workspace customer ID, not the domain string itself
      }
    }
  }
}

# Cloud SQL instances (like the one terraform-gke-infra provisions) may
# never have a public IP — private IP only, enforced org-wide.
resource "google_org_policy_policy" "restrict_cloudsql_public_ip" {
  name   = "${google_folder.fintech_platform.name}/policies/sql.restrictPublicIp"
  parent = google_folder.fintech_platform.name

  spec {
    rules {
      enforce = "TRUE"
    }
  }
}

# GCS buckets must use uniform bucket-level access (no legacy per-object
# ACLs) — simpler, more auditable permission model, standard hardening.
resource "google_org_policy_policy" "uniform_bucket_access" {
  name   = "${google_folder.fintech_platform.name}/policies/storage.uniformBucketLevelAccess"
  parent = google_folder.fintech_platform.name

  spec {
    rules {
      enforce = "TRUE"
    }
  }
}

# ------------------------------------------------------------------
# A SLIGHTLY relaxed override for non-production: allow SA key creation
# only in dev, since some local-development workflows still expect a
# downloadable key (not recommended long-term, but a pragmatic allowance
# during early development). Everything else still inherits the stricter
# folder-level policies above.
# ------------------------------------------------------------------
resource "google_org_policy_policy" "dev_allow_sa_keys" {
  name   = "${google_folder.non_production.name}/policies/iam.disableServiceAccountKeyCreation"
  parent = google_folder.non_production.name

  spec {
    rules {
      enforce = "FALSE"
    }
  }
}
