from contextlib import asynccontextmanager

import structlog
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from prometheus_fastapi_instrumentator import Instrumentator

from app.core.config import settings
from app.api.v1.endpoints import wallet, transfers

logger = structlog.get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting Banking Payment Service", env=settings.APP_ENV)
    yield
    logger.info("Shutting down Banking Payment Service")


app = FastAPI(
    title="Banking Payment Service",
    description="""
## Banking Payment Service API

A production-grade payment backend supporting:
- **P2P Transfers** — Send money to any registered user by email
- **Wallet Management** — Top-up, withdraw, balance inquiry
- **Payment Gateway** — Stripe & Razorpay integration
- **Transaction History** — Paginated, filterable transaction ledger

### Authentication
All endpoints require a Bearer JWT token. Get one via `POST /api/v1/auth/login`.
    """,
    version="1.0.0",
    docs_url="/docs" if not settings.is_production else None,
    redoc_url="/redoc" if not settings.is_production else None,
    lifespan=lifespan,
)

# ── Middleware ────────────────────────────────────────────────────────────────

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def log_requests(request: Request, call_next):
    logger.info(
        "request",
        method=request.method,
        url=str(request.url),
        client=request.client.host if request.client else "unknown",
    )
    response = await call_next(request)
    logger.info("response", status_code=response.status_code)
    return response


# ── Exception Handlers ────────────────────────────────────────────────────────

@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError):
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content={"detail": str(exc)},
    )


@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    logger.error("unhandled_exception", error=str(exc), exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "An internal error occurred. Please try again later."},
    )


# ── Routers ───────────────────────────────────────────────────────────────────

API_PREFIX = "/api/v1"

app.include_router(wallet.router, prefix=API_PREFIX)
app.include_router(transfers.router, prefix=API_PREFIX)

# ── Monitoring ────────────────────────────────────────────────────────────────

Instrumentator().instrument(app).expose(app, endpoint="/metrics")


@app.get("/health", tags=["Health"])
async def health_check():
    return {"status": "ok", "service": settings.APP_NAME, "env": settings.APP_ENV}
