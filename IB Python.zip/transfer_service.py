import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.models import (
    Transaction, TransactionStatus, TransactionType,
    User, Wallet, WalletStatus
)
from app.schemas.schemas import P2PTransferRequest, TransactionFilter, TransactionListResponse
from app.services.exceptions import (
    UserNotFoundError, InsufficientFundsError,
    WalletFrozenError, DailyLimitExceededError,
    TransferLimitError, SelfTransferError
)


class TransferService:

    def __init__(self, db: AsyncSession):
        self.db = db

    async def p2p_transfer(
        self, sender_id: uuid.UUID, request: P2PTransferRequest
    ) -> Transaction:
        """Atomic P2P transfer between two wallets."""

        # --- Validate amount limits ---
        if request.amount < Decimal(str(settings.MIN_TRANSFER_AMOUNT)):
            raise TransferLimitError(f"Minimum transfer amount is {settings.MIN_TRANSFER_AMOUNT}")
        if request.amount > Decimal(str(settings.MAX_TRANSFER_AMOUNT)):
            raise TransferLimitError(f"Maximum transfer amount is {settings.MAX_TRANSFER_AMOUNT}")

        # --- Fetch sender ---
        sender_result = await self.db.execute(
            select(User).where(User.id == sender_id)
        )
        sender = sender_result.scalar_one_or_none()
        if not sender:
            raise UserNotFoundError("Sender not found")

        # --- Fetch receiver ---
        receiver_result = await self.db.execute(
            select(User).where(User.email == request.receiver_email)
        )
        receiver = receiver_result.scalar_one_or_none()
        if not receiver:
            raise UserNotFoundError(f"Receiver with email {request.receiver_email} not found")

        if sender.id == receiver.id:
            raise SelfTransferError("Cannot transfer to yourself")

        # --- Fetch wallets ---
        sender_wallet_result = await self.db.execute(
            select(Wallet).where(Wallet.user_id == sender_id)
        )
        sender_wallet = sender_wallet_result.scalar_one_or_none()
        if not sender_wallet:
            raise WalletFrozenError("Sender wallet not found")

        receiver_wallet_result = await self.db.execute(
            select(Wallet).where(Wallet.user_id == receiver.id)
        )
        receiver_wallet = receiver_wallet_result.scalar_one_or_none()
        if not receiver_wallet:
            raise UserNotFoundError("Receiver wallet not found")

        # --- Validate sender wallet ---
        if sender_wallet.status == WalletStatus.FROZEN:
            raise WalletFrozenError("Your wallet is frozen. Contact support.")

        if receiver_wallet.status == WalletStatus.FROZEN:
            raise WalletFrozenError("Receiver's wallet is frozen.")

        # --- Check balance ---
        if sender_wallet.balance < request.amount:
            raise InsufficientFundsError(
                f"Insufficient balance. Available: {sender_wallet.balance}"
            )

        # --- Check daily limit ---
        await self._check_daily_limit(sender_wallet, request.amount)

        # --- Create transaction (atomic) ---
        reference_id = f"P2P-{uuid.uuid4().hex[:12].upper()}"
        txn = Transaction(
            sender_id=sender_id,
            receiver_id=receiver.id,
            amount=request.amount,
            currency=request.currency,
            transaction_type=TransactionType.P2P_TRANSFER,
            status=TransactionStatus.PROCESSING,
            reference_id=reference_id,
            description=request.description,
        )
        self.db.add(txn)

        # --- Debit sender, credit receiver ---
        sender_wallet.balance -= request.amount
        sender_wallet.daily_spent += request.amount
        receiver_wallet.balance += request.amount

        txn.status = TransactionStatus.COMPLETED
        txn.completed_at = datetime.now(timezone.utc)

        await self.db.commit()
        await self.db.refresh(txn)
        return txn

    async def get_transaction_history(
        self, user_id: uuid.UUID, filters: TransactionFilter
    ) -> TransactionListResponse:
        from sqlalchemy import or_

        query = select(Transaction).where(
            or_(
                Transaction.sender_id == user_id,
                Transaction.receiver_id == user_id,
            )
        )

        if filters.status:
            query = query.where(Transaction.status == filters.status)
        if filters.transaction_type:
            query = query.where(Transaction.transaction_type == filters.transaction_type)
        if filters.start_date:
            query = query.where(Transaction.created_at >= filters.start_date)
        if filters.end_date:
            query = query.where(Transaction.created_at <= filters.end_date)
        if filters.min_amount:
            query = query.where(Transaction.amount >= filters.min_amount)
        if filters.max_amount:
            query = query.where(Transaction.amount <= filters.max_amount)

        # Total count
        count_result = await self.db.execute(
            select(func.count()).select_from(query.subquery())
        )
        total = count_result.scalar_one()

        # Paginate
        offset = (filters.page - 1) * filters.page_size
        query = query.order_by(Transaction.created_at.desc()).offset(offset).limit(filters.page_size)
        result = await self.db.execute(query)
        transactions = result.scalars().all()

        return TransactionListResponse(
            transactions=transactions,
            total=total,
            page=filters.page,
            page_size=filters.page_size,
            total_pages=(total + filters.page_size - 1) // filters.page_size,
        )

    async def get_transaction_by_reference(
        self, reference_id: str, user_id: uuid.UUID
    ) -> Transaction:
        from sqlalchemy import or_
        result = await self.db.execute(
            select(Transaction).where(
                Transaction.reference_id == reference_id,
                or_(
                    Transaction.sender_id == user_id,
                    Transaction.receiver_id == user_id,
                ),
            )
        )
        txn = result.scalar_one_or_none()
        if not txn:
            raise ValueError(f"Transaction {reference_id} not found")
        return txn

    async def _check_daily_limit(self, wallet: Wallet, amount: Decimal) -> None:
        now = datetime.now(timezone.utc)
        if wallet.daily_reset_at is None or wallet.daily_reset_at.date() < now.date():
            wallet.daily_spent = Decimal("0.00")
            wallet.daily_reset_at = now

        if wallet.daily_spent + amount > Decimal(str(settings.DAILY_TRANSFER_LIMIT)):
            raise DailyLimitExceededError(
                f"Daily limit of {settings.DAILY_TRANSFER_LIMIT} would be exceeded."
            )
