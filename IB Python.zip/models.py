import uuid
from datetime import datetime
from decimal import Decimal
from enum import Enum as PyEnum

from sqlalchemy import (
    Boolean, Column, DateTime, Enum, ForeignKey,
    Numeric, String, Text, func
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from app.db.base import Base


class UserStatus(str, PyEnum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    PENDING_KYC = "pending_kyc"
    CLOSED = "closed"


class TransactionStatus(str, PyEnum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    REVERSED = "reversed"


class TransactionType(str, PyEnum):
    P2P_TRANSFER = "p2p_transfer"
    WALLET_TOPUP = "wallet_topup"
    WALLET_WITHDRAWAL = "wallet_withdrawal"
    PAYMENT_GATEWAY = "payment_gateway"
    REFUND = "refund"


class WalletStatus(str, PyEnum):
    ACTIVE = "active"
    FROZEN = "frozen"
    CLOSED = "closed"


class PaymentGateway(str, PyEnum):
    STRIPE = "stripe"
    RAZORPAY = "razorpay"
    INTERNAL = "internal"


# ── Mixins ──────────────────────────────────────────────────────────────────

class TimestampMixin:
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)


class UUIDMixin:
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True)


# ── Models ───────────────────────────────────────────────────────────────────

class User(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "users"

    email = Column(String(255), unique=True, nullable=False, index=True)
    phone = Column(String(20), unique=True, nullable=True, index=True)
    full_name = Column(String(255), nullable=False)
    hashed_password = Column(String(255), nullable=False)
    status = Column(Enum(UserStatus), default=UserStatus.PENDING_KYC, nullable=False)
    is_verified = Column(Boolean, default=False, nullable=False)
    kyc_verified = Column(Boolean, default=False, nullable=False)

    # Relationships
    wallet = relationship("Wallet", back_populates="user", uselist=False)
    sent_transactions = relationship("Transaction", foreign_keys="Transaction.sender_id", back_populates="sender")
    received_transactions = relationship("Transaction", foreign_keys="Transaction.receiver_id", back_populates="receiver")
    payment_methods = relationship("PaymentMethod", back_populates="user")

    def __repr__(self) -> str:
        return f"<User {self.email}>"


class Wallet(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "wallets"

    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False, unique=True, index=True)
    balance = Column(Numeric(precision=18, scale=2), default=Decimal("0.00"), nullable=False)
    currency = Column(String(3), default="INR", nullable=False)
    status = Column(Enum(WalletStatus), default=WalletStatus.ACTIVE, nullable=False)
    daily_spent = Column(Numeric(precision=18, scale=2), default=Decimal("0.00"), nullable=False)
    daily_reset_at = Column(DateTime(timezone=True), nullable=True)

    # Relationships
    user = relationship("User", back_populates="wallet")

    def __repr__(self) -> str:
        return f"<Wallet user={self.user_id} balance={self.balance}>"


class Transaction(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "transactions"

    sender_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True, index=True)
    receiver_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True, index=True)
    amount = Column(Numeric(precision=18, scale=2), nullable=False)
    currency = Column(String(3), default="INR", nullable=False)
    transaction_type = Column(Enum(TransactionType), nullable=False)
    status = Column(Enum(TransactionStatus), default=TransactionStatus.PENDING, nullable=False)
    reference_id = Column(String(255), unique=True, nullable=False, index=True)
    gateway = Column(Enum(PaymentGateway), nullable=True)
    gateway_transaction_id = Column(String(255), nullable=True, index=True)
    description = Column(Text, nullable=True)
    metadata_ = Column("metadata", Text, nullable=True)  # JSON string
    failed_reason = Column(Text, nullable=True)
    completed_at = Column(DateTime(timezone=True), nullable=True)

    # Relationships
    sender = relationship("User", foreign_keys=[sender_id], back_populates="sent_transactions")
    receiver = relationship("User", foreign_keys=[receiver_id], back_populates="received_transactions")

    def __repr__(self) -> str:
        return f"<Transaction {self.reference_id} {self.amount} {self.status}>"


class PaymentMethod(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "payment_methods"

    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False, index=True)
    gateway = Column(Enum(PaymentGateway), nullable=False)
    gateway_customer_id = Column(String(255), nullable=True)
    gateway_method_id = Column(String(255), nullable=False)
    type = Column(String(50), nullable=False)       # card, upi, netbanking
    last_four = Column(String(4), nullable=True)
    brand = Column(String(50), nullable=True)       # visa, mastercard
    is_default = Column(Boolean, default=False, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)

    # Relationships
    user = relationship("User", back_populates="payment_methods")

    def __repr__(self) -> str:
        return f"<PaymentMethod {self.type} {self.last_four}>"


class AuditLog(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "audit_logs"

    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True, index=True)
    action = Column(String(100), nullable=False, index=True)
    resource_type = Column(String(100), nullable=True)
    resource_id = Column(String(255), nullable=True)
    ip_address = Column(String(45), nullable=True)
    user_agent = Column(Text, nullable=True)
    details = Column(Text, nullable=True)  # JSON string
