# 🏦 Banking Payment Service

A production-grade Python payment backend built with **FastAPI**, **SQLAlchemy (async)**, **PostgreSQL**, and **Redis**.

---

## 📐 Architecture Overview

```
banking_payment_service/
├── app/
│   ├── api/
│   │   └── v1/
│   │       ├── endpoints/
│   │       │   ├── wallet.py          # Wallet top-up, withdrawal, balance
│   │       │   └── transfers.py       # P2P transfers, transaction history
│   │       └── dependencies.py        # JWT auth dependency
│   ├── core/
│   │   └── config.py                  # Pydantic settings from .env
│   ├── db/
│   │   ├── base.py                    # SQLAlchemy declarative base
│   │   └── session.py                 # Async DB session factory
│   ├── models/
│   │   └── models.py                  # ORM models (User, Wallet, Transaction…)
│   ├── schemas/
│   │   └── schemas.py                 # Pydantic request/response schemas
│   ├── services/
│   │   ├── wallet_service.py          # Wallet business logic
│   │   ├── transfer_service.py        # P2P transfer logic + history
│   │   ├── payment_gateway_service.py # Stripe & Razorpay integration
│   │   └── exceptions.py             # Domain exceptions
│   └── main.py                        # FastAPI app, middleware, routers
├── tests/
│   ├── unit/                          # Unit tests per service
│   └── integration/                   # Integration tests with test DB
├── migrations/                        # Alembic migrations
├── docs/                              # Architecture diagrams, runbooks
├── docker-compose.yml
├── Dockerfile
├── requirements.txt
└── .env.example
```

---

## 🚀 Features

| Feature | Description |
|---|---|
| **P2P Transfers** | Send money to any registered user by email with atomic debit/credit |
| **Wallet Management** | Top-up via Stripe/Razorpay, withdraw to bank, freeze/unfreeze |
| **Payment Gateways** | Stripe & Razorpay via a factory pattern — easy to add more |
| **Transaction History** | Paginated, filterable ledger with 8 filter options |
| **Daily Limits** | Configurable per-user daily transfer limits with auto-reset |
| **JWT Auth** | Access + refresh token flow with HTTPBearer |
| **Async Everything** | Full async stack: FastAPI + asyncpg + SQLAlchemy async |
| **Observability** | Structured logs (structlog), Prometheus metrics, Sentry |

---

## ⚡ Quick Start

### 1. Clone & configure

```bash
cp .env.example .env
# Edit .env with your DB URL, Stripe/Razorpay keys, and JWT secrets
```

### 2. Run with Docker Compose

```bash
docker-compose up --build
```

This starts:
- **API** at http://localhost:8000
- **PostgreSQL** at localhost:5432
- **Redis** at localhost:6379
- **Celery worker** for async tasks

### 3. Run database migrations

```bash
docker-compose exec api alembic upgrade head
```

### 4. Visit the API docs

```
http://localhost:8000/docs
```

---

## 🔧 Local Development (without Docker)

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Start Postgres and Redis locally, then:
alembic upgrade head
uvicorn app.main:app --reload
```

---

## 🔑 API Reference

### Authentication

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/v1/auth/register` | Register a new user |
| POST | `/api/v1/auth/login` | Login and get JWT tokens |
| POST | `/api/v1/auth/refresh` | Refresh access token |

### Wallet

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/v1/wallet` | Get wallet details |
| GET | `/api/v1/wallet/balance` | Get balance + daily limits |
| POST | `/api/v1/wallet/topup` | Top-up via payment gateway |
| POST | `/api/v1/wallet/withdraw` | Withdraw to bank |
| POST | `/api/v1/wallet/freeze` | Freeze wallet |

### Transfers

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/v1/transfers` | P2P transfer by receiver email |
| GET | `/api/v1/transfers` | Transaction history (paginated) |
| GET | `/api/v1/transfers/{reference_id}` | Single transaction lookup |

### Payments

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/v1/payments/intent` | Create payment intent (Stripe/Razorpay) |
| POST | `/api/v1/payments/verify` | Verify a completed payment |
| POST | `/api/v1/payments/refund` | Initiate a refund |
| POST | `/api/v1/payments/webhook/stripe` | Stripe webhook handler |
| POST | `/api/v1/payments/webhook/razorpay` | Razorpay webhook handler |

---

## 🧪 Testing

```bash
pytest tests/ -v --cov=app --cov-report=html
```

---

## 🛡️ Security Checklist

- [x] JWT with short-lived access tokens (30 min) + refresh tokens (7 days)
- [x] Password hashing with bcrypt
- [x] Webhook signature verification (Stripe & Razorpay)
- [x] Daily transfer limits per user
- [x] Min/max per-transaction limits
- [x] Wallet freeze capability
- [ ] Rate limiting (add `slowapi` middleware)
- [ ] KYC verification flow
- [ ] Two-factor authentication (TOTP)
- [ ] PCI-DSS compliance review (never store raw card data)

---

## ⚙️ Configuration Reference

| Variable | Default | Description |
|---|---|---|
| `DATABASE_URL` | required | PostgreSQL async URL |
| `JWT_SECRET_KEY` | required | JWT signing secret |
| `STRIPE_SECRET_KEY` | optional | Stripe API key |
| `RAZORPAY_KEY_ID` | optional | Razorpay key ID |
| `MAX_TRANSFER_AMOUNT` | 100,000 | Max single transfer (INR) |
| `DAILY_TRANSFER_LIMIT` | 500,000 | Daily limit per user (INR) |
| `ENABLE_P2P_TRANSFERS` | true | Feature flag |
| `ENABLE_WALLET` | true | Feature flag |

---

## 🗺️ Roadmap

- [ ] Auth service (register/login endpoints)
- [ ] KYC verification integration
- [ ] Bank account linking (via Razorpay/Stripe)
- [ ] Scheduled/recurring payments
- [ ] SMS/email notifications (via Celery tasks)
- [ ] Admin dashboard
- [ ] Multi-currency support
