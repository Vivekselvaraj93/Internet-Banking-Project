import uuid
from decimal import Decimal
from abc import ABC, abstractmethod

import stripe
import razorpay

from app.core.config import settings
from app.models.models import PaymentGateway
from app.schemas.schemas import PaymentIntentRequest, PaymentIntentResponse


# ── Abstract Gateway Interface ─────────────────────────────────────────────────

class BasePaymentGateway(ABC):

    @abstractmethod
    async def create_payment_intent(self, request: PaymentIntentRequest) -> PaymentIntentResponse:
        ...

    @abstractmethod
    async def verify_payment(self, gateway_transaction_id: str) -> dict:
        ...

    @abstractmethod
    async def refund(self, gateway_transaction_id: str, amount: Decimal) -> dict:
        ...


# ── Stripe ────────────────────────────────────────────────────────────────────

class StripeGateway(BasePaymentGateway):

    def __init__(self):
        stripe.api_key = settings.STRIPE_SECRET_KEY

    async def create_payment_intent(self, request: PaymentIntentRequest) -> PaymentIntentResponse:
        # Stripe amounts are in smallest currency unit (paise for INR)
        amount_in_paise = int(request.amount * 100)

        intent = stripe.PaymentIntent.create(
            amount=amount_in_paise,
            currency=request.currency.lower(),
            description=request.description,
            metadata=request.metadata or {},
            automatic_payment_methods={"enabled": True},
        )

        return PaymentIntentResponse(
            payment_intent_id=intent["id"],
            client_secret=intent["client_secret"],
            order_id=None,
            amount=request.amount,
            currency=request.currency,
            gateway=PaymentGateway.STRIPE,
            status=intent["status"],
        )

    async def verify_payment(self, gateway_transaction_id: str) -> dict:
        intent = stripe.PaymentIntent.retrieve(gateway_transaction_id)
        return {
            "id": intent["id"],
            "status": intent["status"],
            "amount": Decimal(intent["amount"]) / 100,
            "currency": intent["currency"].upper(),
        }

    async def refund(self, gateway_transaction_id: str, amount: Decimal) -> dict:
        refund = stripe.Refund.create(
            payment_intent=gateway_transaction_id,
            amount=int(amount * 100),
        )
        return {
            "refund_id": refund["id"],
            "status": refund["status"],
            "amount": Decimal(refund["amount"]) / 100,
        }

    def verify_webhook(self, payload: bytes, sig_header: str) -> dict:
        return stripe.Webhook.construct_event(
            payload, sig_header, settings.STRIPE_WEBHOOK_SECRET
        )


# ── Razorpay ──────────────────────────────────────────────────────────────────

class RazorpayGateway(BasePaymentGateway):

    def __init__(self):
        self.client = razorpay.Client(
            auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET)
        )

    async def create_payment_intent(self, request: PaymentIntentRequest) -> PaymentIntentResponse:
        amount_in_paise = int(request.amount * 100)

        order = self.client.order.create({
            "amount": amount_in_paise,
            "currency": request.currency.upper(),
            "notes": request.metadata or {},
            "receipt": f"rcpt_{uuid.uuid4().hex[:10]}",
        })

        return PaymentIntentResponse(
            payment_intent_id=order["id"],
            client_secret=None,
            order_id=order["id"],
            amount=request.amount,
            currency=request.currency,
            gateway=PaymentGateway.RAZORPAY,
            status=order["status"],
        )

    async def verify_payment(self, gateway_transaction_id: str) -> dict:
        payment = self.client.payment.fetch(gateway_transaction_id)
        return {
            "id": payment["id"],
            "status": payment["status"],
            "amount": Decimal(payment["amount"]) / 100,
            "currency": payment["currency"],
        }

    async def refund(self, gateway_transaction_id: str, amount: Decimal) -> dict:
        refund = self.client.payment.refund(
            gateway_transaction_id,
            {"amount": int(amount * 100)}
        )
        return {
            "refund_id": refund["id"],
            "status": refund["status"],
            "amount": Decimal(refund["amount"]) / 100,
        }

    def verify_webhook_signature(
        self, order_id: str, payment_id: str, signature: str
    ) -> bool:
        try:
            self.client.utility.verify_payment_signature({
                "razorpay_order_id": order_id,
                "razorpay_payment_id": payment_id,
                "razorpay_signature": signature,
            })
            return True
        except Exception:
            return False


# ── Factory ───────────────────────────────────────────────────────────────────

class PaymentGatewayFactory:

    _gateways: dict[PaymentGateway, type[BasePaymentGateway]] = {
        PaymentGateway.STRIPE: StripeGateway,
        PaymentGateway.RAZORPAY: RazorpayGateway,
    }

    @classmethod
    def get(cls, gateway: PaymentGateway) -> BasePaymentGateway:
        gateway_class = cls._gateways.get(gateway)
        if not gateway_class:
            raise ValueError(f"Unsupported payment gateway: {gateway}")
        return gateway_class()
