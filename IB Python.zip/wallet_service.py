import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.models import (
    Transaction, TransactionStatus, TransactionType,
    User, Wallet, WalletStatus
)
from app.schemas.schemas import WalletTopupRequest, WalletWithdrawRequest
from app.services.exceptions import (
    InsufficientFundsError, WalletFrozenError, DailyLimitExceededError,
    WalletNotFoundError
)


class WalletService:

    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_wallet(self, user_id: uuid.UUID) -> Wallet:
        result = await self.db.execute(
            select(Wallet).where(Wallet.user_id == user_id)
        )
        wallet = result.scalar_one_or_none()
        if not wallet:
            raise WalletNotFoundError(f"Wallet not found for user {user_id}")
        return wallet

    async def create_wallet(self, user_id: uuid.UUID, currency: str = "INR") -> Wallet:
        wallet = Wallet(user_id=user_id, currency=currency)
        self.db.add(wallet)
        await self.db.flush()
        return wallet

    async def get_balance(self, user_id: uuid.UUID) -> dict:
        wallet = await self.get_wallet(user_id)
        return {
            "balance": wallet.balance,
            "currency": wallet.currency,
            "daily_spent": wallet.daily_spent,
            "daily_remaining": Decimal(str(settings.DAILY_TRANSFER_LIMIT)) - wallet.daily_spent,
        }

    async def topup(self, user_id: uuid.UUID, request: WalletTopupRequest) -> Transaction:
        """Credit wallet after successful gateway payment."""
        wallet = await self.get_wallet(user_id)

        if wallet.status == WalletStatus.FROZEN:
            raise WalletFrozenError("Wallet is frozen. Contact support.")

        # Create transaction record
        txn = Transaction(
            sender_id=None,
            receiver_id=user_id,
            amount=request.amount,
            currency=request.currency,
            transaction_type=TransactionType.WALLET_TOPUP,
            status=TransactionStatus.PENDING,
            reference_id=f"TXN-{uuid.uuid4().hex[:12].upper()}",
            gateway=request.gateway,
            description="Wallet top-up",
        )
        self.db.add(txn)

        # Update wallet balance
        wallet.balance += request.amount
        txn.status = TransactionStatus.COMPLETED
        txn.completed_at = datetime.now(timezone.utc)

        await self.db.commit()
        await self.db.refresh(txn)
        return txn

    async def withdraw(self, user_id: uuid.UUID, request: WalletWithdrawRequest) -> Transaction:
        wallet = await self.get_wallet(user_id)

        if wallet.status == WalletStatus.FROZEN:
            raise WalletFrozenError("Wallet is frozen. Contact support.")

        if wallet.balance < request.amount:
            raise InsufficientFundsError(
                f"Insufficient balance. Available: {wallet.balance}, Requested: {request.amount}"
            )

        await self._check_daily_limit(wallet, request.amount)

        txn = Transaction(
            sender_id=user_id,
            receiver_id=None,
            amount=request.amount,
            currency=wallet.currency,
            transaction_type=TransactionType.WALLET_WITHDRAWAL,
            status=TransactionStatus.PROCESSING,
            reference_id=f"TXN-{uuid.uuid4().hex[:12].upper()}",
            description=request.description or "Wallet withdrawal",
        )
        self.db.add(txn)

        wallet.balance -= request.amount
        wallet.daily_spent += request.amount
        # NOTE: Actual bank payout would be triggered via Celery task here

        await self.db.commit()
        await self.db.refresh(txn)
        return txn

    async def freeze_wallet(self, user_id: uuid.UUID) -> Wallet:
        wallet = await self.get_wallet(user_id)
        wallet.status = WalletStatus.FROZEN
        await self.db.commit()
        return wallet

    async def unfreeze_wallet(self, user_id: uuid.UUID) -> Wallet:
        wallet = await self.get_wallet(user_id)
        wallet.status = WalletStatus.ACTIVE
        await self.db.commit()
        return wallet

    async def _check_daily_limit(self, wallet: Wallet, amount: Decimal) -> None:
        # Reset daily counter if it's a new day
        now = datetime.now(timezone.utc)
        if wallet.daily_reset_at is None or wallet.daily_reset_at.date() < now.date():
            wallet.daily_spent = Decimal("0.00")
            wallet.daily_reset_at = now

        if wallet.daily_spent + amount > Decimal(str(settings.DAILY_TRANSFER_LIMIT)):
            raise DailyLimitExceededError(
                f"Daily transfer limit of {settings.DAILY_TRANSFER_LIMIT} would be exceeded."
            )
