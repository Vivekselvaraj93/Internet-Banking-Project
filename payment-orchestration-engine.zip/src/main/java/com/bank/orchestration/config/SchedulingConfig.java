package com.bank.orchestration.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

/** Enables the @Scheduled reconciliation jobs in ReconciliationService. */
@Configuration
@EnableScheduling
public class SchedulingConfig {
}
