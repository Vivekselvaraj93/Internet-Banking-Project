package com.bank.orchestration.controller;

import com.bank.orchestration.dto.PaymentRequest;
import com.bank.orchestration.dto.PaymentResponse;
import com.bank.orchestration.exception.DuplicateTransactionException;
import com.bank.orchestration.service.PaymentOrchestrationService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/payments")
public class PaymentController {

    private final PaymentOrchestrationService orchestrationService;

    public PaymentController(PaymentOrchestrationService orchestrationService) {
        this.orchestrationService = orchestrationService;
    }

    /**
     * Initiate a payment across any rail (NEFT/RTGS/IMPS/UPI/INTERNATIONAL/INSURANCE_PREMIUM).
     * The client MUST generate and reuse the same idempotencyKey on retry.
     */
    @PostMapping
    public ResponseEntity<PaymentResponse> initiatePayment(@Valid @RequestBody PaymentRequest request) {
        try {
            PaymentResponse response = orchestrationService.initiatePayment(request);
            HttpStatus status = switch (response.getStatus()) {
                case SUCCESS -> HttpStatus.OK;
                case FAILED -> HttpStatus.UNPROCESSABLE_ENTITY;
                default -> HttpStatus.ACCEPTED; // still processing / pending reconciliation
            };
            return ResponseEntity.status(status).body(response);
        } catch (DuplicateTransactionException dup) {
            // Idempotent replay: return the ORIGINAL outcome with 200, never re-process.
            return ResponseEntity.ok(dup.getExistingResponse());
        }
    }
}
