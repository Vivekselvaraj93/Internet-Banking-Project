package com.bank.orchestration.controller;

import com.bank.orchestration.dto.PaymentResponse;
import com.bank.orchestration.service.InsurancePaymentService;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/insurance-payments")
public class InsurancePaymentController {

    private final InsurancePaymentService insurancePaymentService;

    public InsurancePaymentController(InsurancePaymentService insurancePaymentService) {
        this.insurancePaymentService = insurancePaymentService;
    }

    @PostMapping("/premium")
    public ResponseEntity<PaymentResponse> payPremium(@RequestBody PremiumPaymentRequest request) {
        PaymentResponse response = insurancePaymentService.payPremium(
                request.sourceAccountId(), request.insurerSettlementAccountId(), request.amount(),
                request.insurerCode(), request.policyNumber(), request.idempotencyKey());
        return ResponseEntity.ok(response);
    }

    public record PremiumPaymentRequest(
            @NotNull UUID sourceAccountId,
            @NotNull UUID insurerSettlementAccountId,
            @NotNull BigDecimal amount,
            @NotBlank String insurerCode,
            @NotBlank String policyNumber,
            @NotBlank String idempotencyKey) {
    }
}
