package com.bank.orchestration.controller;

import com.bank.orchestration.exception.InsufficientFundsException;
import com.bank.orchestration.exception.LedgerImbalanceException;
import com.bank.orchestration.exception.NoEligibleRailException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(InsufficientFundsException.class)
    public ResponseEntity<Object> handleInsufficientFunds(InsufficientFundsException ex) {
        return error(HttpStatus.UNPROCESSABLE_ENTITY, "INSUFFICIENT_FUNDS", ex.getMessage());
    }

    @ExceptionHandler(NoEligibleRailException.class)
    public ResponseEntity<Object> handleNoRail(NoEligibleRailException ex) {
        return error(HttpStatus.UNPROCESSABLE_ENTITY, "NO_ELIGIBLE_RAIL", ex.getMessage());
    }

    @ExceptionHandler(LedgerImbalanceException.class)
    public ResponseEntity<Object> handleLedgerImbalance(LedgerImbalanceException ex) {
        // This should already have paged on-call; surface as 500 to the caller.
        return error(HttpStatus.INTERNAL_SERVER_ERROR, "LEDGER_IMBALANCE", ex.getMessage());
    }

    private ResponseEntity<Object> error(HttpStatus status, String code, String message) {
        return ResponseEntity.status(status).body(Map.of(
                "timestamp", Instant.now().toString(),
                "code", code,
                "message", message
        ));
    }
}
