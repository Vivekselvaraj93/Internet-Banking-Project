package com.bank.orchestration.dto;

import com.bank.orchestration.model.RailType;
import com.bank.orchestration.model.Urgency;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Inbound request from client apps / API gateway.
 * idempotencyKey MUST be generated client-side and reused verbatim on retry.
 */
public class PaymentRequest {

    @NotNull
    private UUID sourceAccountId;

    /** Optional: if the payment is an internal transfer to another wallet on this platform */
    private UUID destAccountId;

    private String destBankIfsc;
    private String destAccountNumber;
    private String destVpa; // for UPI

    @NotNull
    @DecimalMin(value = "0.01")
    private BigDecimal amount;

    @NotNull
    private String currency = "INR";

    @NotNull
    private Urgency urgency;

    private boolean international = false;

    /** Explicit rail override; if provided, rail selection logic is bypassed.
     *  Useful for INSURANCE_PREMIUM which is not amount/urgency driven. */
    private RailType railOverride;

    @NotBlank
    private String idempotencyKey;

    private String narration;

    // getters / setters
    public UUID getSourceAccountId() { return sourceAccountId; }
    public void setSourceAccountId(UUID sourceAccountId) { this.sourceAccountId = sourceAccountId; }
    public UUID getDestAccountId() { return destAccountId; }
    public void setDestAccountId(UUID destAccountId) { this.destAccountId = destAccountId; }
    public String getDestBankIfsc() { return destBankIfsc; }
    public void setDestBankIfsc(String destBankIfsc) { this.destBankIfsc = destBankIfsc; }
    public String getDestAccountNumber() { return destAccountNumber; }
    public void setDestAccountNumber(String destAccountNumber) { this.destAccountNumber = destAccountNumber; }
    public String getDestVpa() { return destVpa; }
    public void setDestVpa(String destVpa) { this.destVpa = destVpa; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public Urgency getUrgency() { return urgency; }
    public void setUrgency(Urgency urgency) { this.urgency = urgency; }
    public boolean isInternational() { return international; }
    public void setInternational(boolean international) { this.international = international; }
    public RailType getRailOverride() { return railOverride; }
    public void setRailOverride(RailType railOverride) { this.railOverride = railOverride; }
    public String getIdempotencyKey() { return idempotencyKey; }
    public void setIdempotencyKey(String idempotencyKey) { this.idempotencyKey = idempotencyKey; }
    public String getNarration() { return narration; }
    public void setNarration(String narration) { this.narration = narration; }
}
