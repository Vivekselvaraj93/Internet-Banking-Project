package com.bank.orchestration.dto;

import com.bank.orchestration.model.RailType;
import com.bank.orchestration.model.TransactionStatus;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public class PaymentResponse {
    private UUID transactionId;
    private TransactionStatus status;
    private RailType railUsed;
    private String railReference;
    private BigDecimal amount;
    private Instant initiatedAt;
    private Instant completedAt;
    private String failureReason;

    public PaymentResponse() {}

    public PaymentResponse(UUID transactionId, TransactionStatus status, RailType railUsed,
                            String railReference, BigDecimal amount, Instant initiatedAt,
                            Instant completedAt, String failureReason) {
        this.transactionId = transactionId;
        this.status = status;
        this.railUsed = railUsed;
        this.railReference = railReference;
        this.amount = amount;
        this.initiatedAt = initiatedAt;
        this.completedAt = completedAt;
        this.failureReason = failureReason;
    }

    public UUID getTransactionId() { return transactionId; }
    public TransactionStatus getStatus() { return status; }
    public RailType getRailUsed() { return railUsed; }
    public String getRailReference() { return railReference; }
    public BigDecimal getAmount() { return amount; }
    public Instant getInitiatedAt() { return initiatedAt; }
    public Instant getCompletedAt() { return completedAt; }
    public String getFailureReason() { return failureReason; }
}
