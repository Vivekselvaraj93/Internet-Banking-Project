package com.bank.orchestration.dto;

/** Outcome of a single call to a rail connector / BaaS partner. */
public class RailResult {

    public enum Outcome { SUCCESS, PENDING, FAILED, TIMEOUT }

    private final Outcome outcome;
    private final String railReference; // UTR/RRN
    private final String failureReason;
    private final boolean retryable;

    private RailResult(Outcome outcome, String railReference, String failureReason, boolean retryable) {
        this.outcome = outcome;
        this.railReference = railReference;
        this.failureReason = failureReason;
        this.retryable = retryable;
    }

    public static RailResult success(String railReference) {
        return new RailResult(Outcome.SUCCESS, railReference, null, false);
    }

    public static RailResult pending(String railReference) {
        return new RailResult(Outcome.PENDING, railReference, null, false);
    }

    public static RailResult failed(String reason, boolean retryable) {
        return new RailResult(Outcome.FAILED, null, reason, retryable);
    }

    public static RailResult timeout() {
        return new RailResult(Outcome.TIMEOUT, null, "partner timeout", true);
    }

    public Outcome getOutcome() { return outcome; }
    public String getRailReference() { return railReference; }
    public String getFailureReason() { return failureReason; }
    public boolean isRetryable() { return retryable; }
}
