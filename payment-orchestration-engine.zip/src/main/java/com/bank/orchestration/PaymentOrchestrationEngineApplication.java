package com.bank.orchestration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentOrchestrationEngineApplication {
    public static void main(String[] args) {
        SpringApplication.run(PaymentOrchestrationEngineApplication.class, args);
    }
}
