package com.bank.orchestration.connector;

import com.bank.orchestration.dto.RailResult;
import com.bank.orchestration.model.RailType;
import com.bank.orchestration.model.Transaction;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * RTGS: real-time gross settlement, minimum amount 2,00,000 INR (no max), 24x7 since Dec 2020.
 * Reserved for high-value, time-critical transfers.
 */
@Component
public class RtgsConnector extends AbstractPartnerConnector {

    // NOTE: pull this from a config table / feature-flag service, not a hardcoded constant -
    // RBI revises rail limits periodically (see architecture doc section 5).
    private static final BigDecimal RTGS_MIN_AMOUNT = new BigDecimal("200000");

    public RtgsConnector(PartnerApiClient partnerApiClient) {
        super(partnerApiClient);
    }

    @Override
    public RailType getRailType() {
        return RailType.RTGS;
    }

    @Override
    public RailResult send(Transaction transaction) {
        if (transaction.getAmount().compareTo(RTGS_MIN_AMOUNT) < 0) {
            return RailResult.failed("AMOUNT_BELOW_RTGS_MINIMUM", false);
        }
        return super.send(transaction);
    }
}
