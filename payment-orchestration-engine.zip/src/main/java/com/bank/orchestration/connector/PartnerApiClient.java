package com.bank.orchestration.connector;

import com.bank.orchestration.dto.RailResult;
import com.bank.orchestration.model.RailType;
import com.bank.orchestration.model.Transaction;

/**
 * Generic abstraction over a BaaS/sponsor-bank partner's HTTP API
 * (Setu / Decentro / Cashfree Payouts / M2P / RazorpayX).
 *
 * Swap the Spring bean implementation (see MockPartnerApiClient) for a real
 * RestClient/WebClient-based implementation that:
 *   - signs requests per the partner's auth scheme (HMAC / OAuth2 client-credentials)
 *   - sends the deterministic partnerReference so partner-side retries are also idempotent
 *   - maps partner-specific HTTP/error codes into RailResult
 */
public interface PartnerApiClient {

    RailResult submitPayment(RailType rail, String partnerReference, Transaction transaction);

    RailResult getPaymentStatus(RailType rail, String partnerReference);
}
