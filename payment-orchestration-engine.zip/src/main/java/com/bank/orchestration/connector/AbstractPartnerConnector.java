package com.bank.orchestration.connector;

import com.bank.orchestration.dto.RailResult;
import com.bank.orchestration.model.Transaction;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public abstract class AbstractPartnerConnector implements RailConnector {

    protected final PartnerApiClient partnerApiClient;

    protected AbstractPartnerConnector(PartnerApiClient partnerApiClient) {
        this.partnerApiClient = partnerApiClient;
    }

    /**
     * Deterministic reference derived from the transaction's idempotency_key, NOT a random UUID.
     * This is what actually makes retries safe at the partner: the same idempotency_key
     * always produces the same partnerReference, so a retried HTTP call (e.g. after our own
     * timeout) is recognized by the partner as the same payment instruction rather than a
     * duplicate one.
     */
    protected String deriveDeterministicReference(Transaction transaction) {
        try {
            MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
            byte[] hash = sha256.digest(
                    (getRailType().name() + ":" + transaction.getIdempotencyKey())
                            .getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.substring(0, 32); // partner refs are typically capped at ~32-40 chars
        } catch (NoSuchAlgorithmException e) {
            // SHA-256 is always available on the JVM; this branch is unreachable in practice.
            throw new IllegalStateException(e);
        }
    }

    @Override
    public RailResult send(Transaction transaction) {
        String partnerReference = deriveDeterministicReference(transaction);
        return partnerApiClient.submitPayment(getRailType(), partnerReference, transaction);
    }

    @Override
    public RailResult checkStatus(Transaction transaction) {
        String partnerReference = deriveDeterministicReference(transaction);
        return partnerApiClient.getPaymentStatus(getRailType(), partnerReference);
    }
}
