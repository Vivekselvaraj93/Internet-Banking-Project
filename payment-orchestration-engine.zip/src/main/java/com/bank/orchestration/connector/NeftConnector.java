package com.bank.orchestration.connector;

import com.bank.orchestration.model.RailType;
import org.springframework.stereotype.Component;

/**
 * NEFT: batched settlement (half-hourly windows), no min/max amount, 24x7 since Dec 2019.
 * Slowest of the domestic rails but has the widest bank coverage - used as the default
 * fallback when IMPS/UPI/RTGS are unavailable or amount doesn't warrant a faster rail.
 */
@Component
public class NeftConnector extends AbstractPartnerConnector {

    public NeftConnector(PartnerApiClient partnerApiClient) {
        super(partnerApiClient);
    }

    @Override
    public RailType getRailType() {
        return RailType.NEFT;
    }
}
