package com.bank.orchestration.connector;

import com.bank.orchestration.dto.RailResult;
import com.bank.orchestration.model.RailType;
import com.bank.orchestration.model.Transaction;

/**
 * Abstraction over a BaaS/sponsor-bank partner API for a single rail.
 * Real implementations call out to Setu / Decentro / Cashfree / M2P / RazorpayX etc.
 * Every implementation MUST be idempotent: calling send() twice with the same
 * transaction.idempotencyKey must not create two payments at the partner.
 */
public interface RailConnector {

    RailType getRailType();

    /** Send the payment instruction to the partner. Must be idempotent on transaction.getIdempotencyKey(). */
    RailResult send(Transaction transaction);

    /** Poll the partner's status API - used by the reconciliation job for anything not terminal. */
    RailResult checkStatus(Transaction transaction);
}
