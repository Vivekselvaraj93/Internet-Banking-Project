package com.bank.orchestration.connector;

import com.bank.orchestration.dto.RailResult;
import com.bank.orchestration.model.RailType;
import com.bank.orchestration.model.Transaction;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * IMPS: real-time, 24x7, no minimum, ~5L max (bank-dependent). Used for INSTANT urgency
 * above the UPI per-txn limit, and as the auto-fallback when UPI or RTGS fail.
 */
@Component
public class ImpsConnector extends AbstractPartnerConnector {

    private static final BigDecimal IMPS_MAX_AMOUNT = new BigDecimal("500000");

    public ImpsConnector(PartnerApiClient partnerApiClient) {
        super(partnerApiClient);
    }

    @Override
    public RailType getRailType() {
        return RailType.IMPS;
    }

    @Override
    public RailResult send(Transaction transaction) {
        if (transaction.getAmount().compareTo(IMPS_MAX_AMOUNT) > 0) {
            return RailResult.failed("AMOUNT_ABOVE_IMPS_MAXIMUM", false);
        }
        return super.send(transaction);
    }
}
