package com.bank.orchestration.connector;

import com.bank.orchestration.dto.RailResult;
import com.bank.orchestration.model.RailType;
import com.bank.orchestration.model.Transaction;
import org.springframework.stereotype.Component;

/**
 * Cross-border payout via an Authorized Dealer (AD) bank / SWIFT, or a cross-border
 * specialist (Nium, Wise Platform, Thunes, Cashfree cross-border).
 * Real implementation must run OFAC/sanctions + FEMA/LRS purpose-code checks
 * BEFORE calling send() - see RiskEngine integration point in PaymentOrchestrationService.
 */
@Component
public class InternationalConnector extends AbstractPartnerConnector {

    public InternationalConnector(PartnerApiClient partnerApiClient) {
        super(partnerApiClient);
    }

    @Override
    public RailType getRailType() {
        return RailType.INTERNATIONAL;
    }
}
