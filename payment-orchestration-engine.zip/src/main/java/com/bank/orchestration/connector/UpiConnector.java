package com.bank.orchestration.connector;

import com.bank.orchestration.dto.RailResult;
import com.bank.orchestration.model.RailType;
import com.bank.orchestration.model.Transaction;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;

/**
 * UPI: real-time, 24x7, no minimum, ~1L per-txn cap (higher for select categories -
 * e.g. capital markets, insurance, IPO, tax payments per current NPCI circulars).
 * Requires a valid destination VPA (or a UPI-linked account+IFSC collect flow).
 */
@Component
public class UpiConnector extends AbstractPartnerConnector {

    private static final BigDecimal UPI_DEFAULT_MAX_AMOUNT = new BigDecimal("100000");

    public UpiConnector(PartnerApiClient partnerApiClient) {
        super(partnerApiClient);
    }

    @Override
    public RailType getRailType() {
        return RailType.UPI;
    }

    @Override
    public RailResult send(Transaction transaction) {
        if (!StringUtils.hasText(transaction.getDestVpa())
                && !StringUtils.hasText(transaction.getDestAccountNumber())) {
            return RailResult.failed("MISSING_DEST_VPA_OR_ACCOUNT", false);
        }
        if (transaction.getAmount().compareTo(UPI_DEFAULT_MAX_AMOUNT) > 0) {
            return RailResult.failed("AMOUNT_ABOVE_UPI_PER_TXN_LIMIT", false);
        }
        return super.send(transaction);
    }
}
