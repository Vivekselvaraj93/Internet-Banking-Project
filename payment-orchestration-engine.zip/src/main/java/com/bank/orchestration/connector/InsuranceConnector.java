package com.bank.orchestration.connector;

import com.bank.orchestration.model.RailType;
import org.springframework.stereotype.Component;

/**
 * Insurance premium collection: routed through the same payment gateway as any other
 * merchant category (not a separate settlement rail like NEFT/RTGS). The distinguishing
 * behavior lives in the orchestration layer - narration/metadata tags the transaction
 * with the policy number and insurer code for downstream reconciliation with the insurer/
 * insurtech's premium ledger.
 *
 * NOTE: if the platform also *distributes* insurance (quotes, policy issuance, commission),
 * that requires a separate IRDAI Web Aggregator/Corporate Agent license and is out of scope
 * for this connector, which only handles premium payment collection.
 */
@Component
public class InsuranceConnector extends AbstractPartnerConnector {

    public InsuranceConnector(PartnerApiClient partnerApiClient) {
        super(partnerApiClient);
    }

    @Override
    public RailType getRailType() {
        return RailType.INSURANCE_PREMIUM;
    }
}
