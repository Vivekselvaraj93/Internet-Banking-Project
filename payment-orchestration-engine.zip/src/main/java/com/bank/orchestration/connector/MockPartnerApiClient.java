package com.bank.orchestration.connector;

import com.bank.orchestration.dto.RailResult;
import com.bank.orchestration.model.RailType;
import com.bank.orchestration.model.Transaction;
import org.springframework.stereotype.Component;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Development/test stand-in for a real BaaS partner (Setu, Decentro, Cashfree, M2P, RazorpayX).
 *
 * TODO before going live: replace this bean with a RestClient/WebClient implementation
 * that calls the partner's actual REST endpoints, e.g.:
 *   POST https://<partner>/api/v2/payouts   { "referenceId": partnerReference, ... }
 * and translates the partner's response/webhook payloads into RailResult.
 * Keep the method signatures identical so PartnerApiClient stays a clean seam.
 */
@Component
public class MockPartnerApiClient implements PartnerApiClient {

    @Override
    public RailResult submitPayment(RailType rail, String partnerReference, Transaction transaction) {
        // Simulate partner-side outcomes for local dev/testing.
        int roll = ThreadLocalRandom.current().nextInt(100);
        String utr = rail.name() + "-" + partnerReference.substring(0, Math.min(12, partnerReference.length()));

        if (roll < 85) {
            return RailResult.success(utr);
        } else if (roll < 92) {
            return RailResult.pending(utr); // e.g. UPI/IMPS awaiting beneficiary bank confirmation
        } else if (roll < 97) {
            return RailResult.failed("BENEFICIARY_BANK_UNAVAILABLE", true); // retryable
        } else {
            return RailResult.timeout();
        }
    }

    @Override
    public RailResult getPaymentStatus(RailType rail, String partnerReference) {
        // In production this hits the partner's GET /payouts/{referenceId} status endpoint.
        return RailResult.success(partnerReference);
    }
}
