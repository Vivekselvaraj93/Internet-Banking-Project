package com.bank.orchestration.repository;

import com.bank.orchestration.model.Transaction;
import com.bank.orchestration.model.TransactionStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface TransactionRepository extends JpaRepository<Transaction, UUID> {

    Optional<Transaction> findByIdempotencyKey(String idempotencyKey);

    List<Transaction> findByStatusIn(List<TransactionStatus> statuses);
}
