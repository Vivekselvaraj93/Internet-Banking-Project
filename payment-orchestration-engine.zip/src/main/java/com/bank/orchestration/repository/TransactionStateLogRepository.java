package com.bank.orchestration.repository;

import com.bank.orchestration.model.TransactionStateLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

public interface TransactionStateLogRepository extends JpaRepository<TransactionStateLog, Long> {
    List<TransactionStateLog> findByTransactionIdOrderByChangedAtAsc(UUID transactionId);
}
