package com.bank.orchestration.repository;

import com.bank.orchestration.model.ReconciliationRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface ReconciliationRecordRepository extends JpaRepository<ReconciliationRecord, UUID> {
}
