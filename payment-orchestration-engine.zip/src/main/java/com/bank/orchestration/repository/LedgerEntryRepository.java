package com.bank.orchestration.repository;

import com.bank.orchestration.model.LedgerEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

public interface LedgerEntryRepository extends JpaRepository<LedgerEntry, UUID> {

    List<LedgerEntry> findByTransactionId(UUID transactionId);

    List<LedgerEntry> findByAccountIdOrderByCreatedAtDesc(UUID accountId);

    @Query("select coalesce(sum(case when e.entryType = 'CREDIT' then e.amount else -e.amount end), 0) " +
           "from LedgerEntry e where e.accountId = :accountId")
    BigDecimal computeBalance(@Param("accountId") UUID accountId);

    /** Nightly invariant check: for every transaction, sum(debits) must equal sum(credits). */
    @Query("select e.transactionId from LedgerEntry e group by e.transactionId " +
           "having sum(case when e.entryType = 'DEBIT' then e.amount else -e.amount end) <> 0")
    List<UUID> findImbalancedTransactions();
}
