package com.bank.orchestration.service;

import com.bank.orchestration.dto.PaymentRequest;
import com.bank.orchestration.exception.NoEligibleRailException;
import com.bank.orchestration.model.RailType;
import com.bank.orchestration.model.Urgency;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalTime;
import java.util.List;

/**
 * Implements the rail-selection pseudocode from the architecture doc, section 5.
 * Limits are intentionally kept as named constants here for readability, but in
 * production these MUST be sourced from a config table (RBI revises them periodically)
 * or from the BaaS partner's own "current limits" API.
 */
@Service
public class RailSelectionService {

    private static final BigDecimal UPI_MAX = new BigDecimal("100000");
    private static final BigDecimal IMPS_MAX = new BigDecimal("500000");
    private static final BigDecimal RTGS_MIN = new BigDecimal("200000");

    private static final LocalTime RTGS_PARTNER_WINDOW_START = LocalTime.of(0, 0);
    private static final LocalTime RTGS_PARTNER_WINDOW_END = LocalTime.of(23, 30); // example partner cutoff

    /**
     * Mirrors selectRail(amount, urgency, destBank, time, isInternational) from the doc.
     * Returns an ordered fallback chain: the caller (orchestration engine) attempts rails
     * in order until one succeeds or the chain is exhausted.
     */
    public List<RailType> selectRailChain(PaymentRequest request) {

        if (request.getRailOverride() != null) {
            return List.of(request.getRailOverride());
        }

        if (request.isInternational()) {
            return List.of(RailType.INTERNATIONAL);
        }

        BigDecimal amount = request.getAmount();
        Urgency urgency = request.getUrgency();

        if (urgency == Urgency.INSTANT) {
            if (amount.compareTo(UPI_MAX) <= 0) {
                return List.of(RailType.UPI, RailType.IMPS, RailType.NEFT);
            } else if (amount.compareTo(IMPS_MAX) <= 0) {
                return List.of(RailType.IMPS, RailType.NEFT);
            } else {
                // above IMPS ceiling: only RTGS (if eligible) or NEFT can carry it
                return amount.compareTo(RTGS_MIN) >= 0
                        ? List.of(RailType.RTGS, RailType.NEFT)
                        : List.of(RailType.NEFT);
            }
        }

        if (urgency == Urgency.SAME_DAY && amount.compareTo(RTGS_MIN) >= 0) {
            if (isWithinRtgsWindow()) {
                return List.of(RailType.RTGS, RailType.NEFT);
            }
            return List.of(RailType.IMPS, RailType.NEFT);
        }

        if (urgency == Urgency.STANDARD) {
            return List.of(RailType.NEFT, RailType.IMPS);
        }

        // Default fallback chain
        List<RailType> defaultChain = List.of(RailType.UPI, RailType.IMPS, RailType.NEFT);
        if (defaultChain.isEmpty()) {
            throw new NoEligibleRailException("No eligible rail found for request");
        }
        return defaultChain;
    }

    private boolean isWithinRtgsWindow() {
        LocalTime now = LocalTime.now();
        return !now.isBefore(RTGS_PARTNER_WINDOW_START) && !now.isAfter(RTGS_PARTNER_WINDOW_END);
    }
}
