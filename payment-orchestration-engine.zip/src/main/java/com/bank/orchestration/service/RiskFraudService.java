package com.bank.orchestration.service;

import com.bank.orchestration.dto.PaymentRequest;
import org.springframework.stereotype.Service;

/**
 * Placeholder for the Risk & Fraud Engine (architecture doc section 2):
 * velocity checks, AML screening, transaction limits, OFAC/sanctions screening
 * (mandatory for INTERNATIONAL rail).
 *
 * Wire this to a real screening provider (e.g. an AML/sanctions-list API) before go-live.
 * The orchestration engine calls this synchronously and BLOCKS the payment on a reject -
 * it must run before any funds are moved or any partner API is called.
 */
@Service
public class RiskFraudService {

    public RiskDecision evaluate(PaymentRequest request) {
        // TODO: velocity check (txn count/amount per account per rolling window)
        // TODO: AML rule checks against transaction patterns
        // TODO: OFAC/UN/RBI sanctions-list screening, mandatory for request.isInternational()
        // TODO: per-account and per-KYC-tier transaction limits
        return RiskDecision.approved();
    }

    public static class RiskDecision {
        private final boolean approved;
        private final String reason;

        private RiskDecision(boolean approved, String reason) {
            this.approved = approved;
            this.reason = reason;
        }

        public static RiskDecision approved() { return new RiskDecision(true, null); }
        public static RiskDecision rejected(String reason) { return new RiskDecision(false, reason); }

        public boolean isApproved() { return approved; }
        public String getReason() { return reason; }
    }
}
