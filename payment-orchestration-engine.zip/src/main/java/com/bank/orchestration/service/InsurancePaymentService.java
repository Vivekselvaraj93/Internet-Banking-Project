package com.bank.orchestration.service;

import com.bank.orchestration.dto.PaymentRequest;
import com.bank.orchestration.dto.PaymentResponse;
import com.bank.orchestration.model.RailType;
import com.bank.orchestration.model.Urgency;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Insurance premium collection (architecture doc section 1 & 6):
 * "Usually just a payment gateway integration on top of insurer/insurtech APIs -
 *  unless you also want to distribute insurance, which needs an IRDAI license."
 *
 * This service does NOT talk to a separate settlement rail. It forces the
 * INSURANCE_PREMIUM rail override so the request bypasses NEFT/RTGS/IMPS/UPI
 * rail-selection logic and is tagged for reconciliation against the insurer's
 * premium ledger via policyNumber/insurerCode in the narration/metadata.
 */
@Service
public class InsurancePaymentService {

    private final PaymentOrchestrationService orchestrationService;

    public InsurancePaymentService(PaymentOrchestrationService orchestrationService) {
        this.orchestrationService = orchestrationService;
    }

    public PaymentResponse payPremium(UUID sourceAccountId, UUID insurerSettlementAccountId,
                                       BigDecimal amount, String insurerCode, String policyNumber,
                                       String idempotencyKey) {
        PaymentRequest request = new PaymentRequest();
        request.setSourceAccountId(sourceAccountId);
        request.setDestAccountId(insurerSettlementAccountId);
        request.setAmount(amount);
        request.setCurrency("INR");
        request.setUrgency(Urgency.STANDARD);
        request.setRailOverride(RailType.INSURANCE_PREMIUM);
        request.setIdempotencyKey(idempotencyKey);
        request.setNarration("INSURANCE_PREMIUM|insurer=" + insurerCode + "|policy=" + policyNumber);

        return orchestrationService.initiatePayment(request);
    }
}
