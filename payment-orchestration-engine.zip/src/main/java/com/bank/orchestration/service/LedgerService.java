package com.bank.orchestration.service;

import com.bank.orchestration.exception.InsufficientFundsException;
import com.bank.orchestration.exception.LedgerImbalanceException;
import com.bank.orchestration.model.Account;
import com.bank.orchestration.model.EntryType;
import com.bank.orchestration.model.LedgerEntry;
import com.bank.orchestration.repository.AccountRepository;
import com.bank.orchestration.repository.LedgerEntryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

/**
 * The single most safety-critical piece of the system (per architecture doc section 2).
 *
 * Non-negotiables enforced here:
 *  - Never UPDATE a balance directly; balances are always derived or appended.
 *  - SELECT ... FOR UPDATE (via AccountRepository#lockById) on every account touched,
 *    to prevent two concurrent debits from both passing a stale balance check.
 *  - Every transaction posts balanced entries: sum(debits) == sum(credits).
 */
@Service
public class LedgerService {

    private final AccountRepository accountRepository;
    private final LedgerEntryRepository ledgerEntryRepository;

    public LedgerService(AccountRepository accountRepository, LedgerEntryRepository ledgerEntryRepository) {
        this.accountRepository = accountRepository;
        this.ledgerEntryRepository = ledgerEntryRepository;
    }

    /**
     * Posts a simple two-leg transfer: debit sourceAccountId, credit destAccountId,
     * for the given transactionId. Both accounts are pessimistically locked in a
     * fixed order (by UUID) to avoid deadlocks between concurrent transfers that
     * touch the same pair of accounts in opposite directions.
     */
    @Transactional
    public void postTransfer(UUID transactionId, UUID sourceAccountId, UUID destAccountId,
                              BigDecimal amount, String currency, String metadataJson) {

        UUID first = sourceAccountId.compareTo(destAccountId) <= 0 ? sourceAccountId : destAccountId;
        UUID second = sourceAccountId.compareTo(destAccountId) <= 0 ? destAccountId : sourceAccountId;

        Account firstLocked = accountRepository.lockById(first)
                .orElseThrow(() -> new IllegalArgumentException("Unknown account: " + first));
        Account secondLocked = accountRepository.lockById(second)
                .orElseThrow(() -> new IllegalArgumentException("Unknown account: " + second));

        BigDecimal sourceBalance = ledgerEntryRepository.computeBalance(sourceAccountId);
        if (sourceBalance.compareTo(amount) < 0) {
            throw new InsufficientFundsException(
                    "Account " + sourceAccountId + " has insufficient funds: balance=" + sourceBalance + " required=" + amount);
        }

        BigDecimal newSourceBalance = sourceBalance.subtract(amount);
        LedgerEntry debit = buildEntry(transactionId, sourceAccountId, EntryType.DEBIT, amount, currency, newSourceBalance, metadataJson);

        BigDecimal destBalance = ledgerEntryRepository.computeBalance(destAccountId);
        BigDecimal newDestBalance = destBalance.add(amount);
        LedgerEntry credit = buildEntry(transactionId, destAccountId, EntryType.CREDIT, amount, currency, newDestBalance, metadataJson);

        ledgerEntryRepository.save(debit);
        ledgerEntryRepository.save(credit);

        assertBalanced(transactionId);
    }

    /** Reversal: credit back to source, debit from destination - mirrors postTransfer with legs swapped. */
    @Transactional
    public void postReversal(UUID originalTransactionId, UUID reversalTransactionId,
                              UUID sourceAccountId, UUID destAccountId,
                              BigDecimal amount, String currency) {
        String metadata = "{\"reversalOf\":\"" + originalTransactionId + "\"}";
        postTransfer(reversalTransactionId, destAccountId, sourceAccountId, amount, currency, metadata);
    }

    public BigDecimal getBalance(UUID accountId) {
        return ledgerEntryRepository.computeBalance(accountId);
    }

    private LedgerEntry buildEntry(UUID transactionId, UUID accountId, EntryType type, BigDecimal amount,
                                    String currency, BigDecimal balanceAfter, String metadataJson) {
        LedgerEntry entry = new LedgerEntry();
        entry.setTransactionId(transactionId);
        entry.setAccountId(accountId);
        entry.setEntryType(type);
        entry.setAmount(amount);
        entry.setCurrency(currency);
        entry.setBalanceAfter(balanceAfter);
        entry.setMetadata(metadataJson);
        return entry;
    }

    private void assertBalanced(UUID transactionId) {
        List<LedgerEntry> entries = ledgerEntryRepository.findByTransactionId(transactionId);
        BigDecimal debits = entries.stream()
                .filter(e -> e.getEntryType() == EntryType.DEBIT)
                .map(LedgerEntry::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal credits = entries.stream()
                .filter(e -> e.getEntryType() == EntryType.CREDIT)
                .map(LedgerEntry::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        if (debits.compareTo(credits) != 0) {
            // In production this should also fire a P0 alert (PagerDuty/Opsgenie), not just throw.
            throw new LedgerImbalanceException(
                    "Ledger imbalance for transaction " + transactionId + ": debits=" + debits + " credits=" + credits);
        }
    }
}
