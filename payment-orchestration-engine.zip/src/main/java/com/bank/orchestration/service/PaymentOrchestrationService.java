package com.bank.orchestration.service;

import com.bank.orchestration.connector.RailConnector;
import com.bank.orchestration.dto.PaymentRequest;
import com.bank.orchestration.dto.PaymentResponse;
import com.bank.orchestration.dto.RailResult;
import com.bank.orchestration.exception.DuplicateTransactionException;
import com.bank.orchestration.exception.NoEligibleRailException;
import com.bank.orchestration.model.RailType;
import com.bank.orchestration.model.Transaction;
import com.bank.orchestration.model.TransactionStatus;
import com.bank.orchestration.repository.TransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Central engine described in architecture doc section 2 ("Payment Orchestration Engine")
 * and section 5 ("Payment Orchestration Logic"). Responsibilities:
 *   1. Idempotency at the API boundary.
 *   2. Risk/fraud screening.
 *   3. Rail selection with an ordered fallback chain.
 *   4. Dispatch to the chosen rail's connector with bounded retries.
 *   5. Automatic failover to the next rail in the chain on non-retryable/exhausted failure.
 *   6. Ledger posting on confirmed success.
 *   7. Full state-machine + audit trail via TransactionStateService.
 *
 * Note on transaction boundaries: dispatching to an external partner must NOT happen
 * inside the same DB transaction as the ledger write, and must not hold the account locks
 * from LedgerService while waiting on a network call. This class deliberately keeps the
 * "call the partner" step outside of any @Transactional method; only the local state
 * updates (transaction row, state log, ledger entries) are transactional.
 */
@Service
public class PaymentOrchestrationService {

    private static final Logger log = LoggerFactory.getLogger(PaymentOrchestrationService.class);
    private static final int MAX_ATTEMPTS_PER_RAIL = 3;

    private final TransactionRepository transactionRepository;
    private final TransactionStateService stateService;
    private final RailSelectionService railSelectionService;
    private final RiskFraudService riskFraudService;
    private final LedgerService ledgerService;
    private final Map<RailType, RailConnector> connectorsByRail;

    public PaymentOrchestrationService(TransactionRepository transactionRepository,
                                        TransactionStateService stateService,
                                        RailSelectionService railSelectionService,
                                        RiskFraudService riskFraudService,
                                        LedgerService ledgerService,
                                        List<RailConnector> connectors) {
        this.transactionRepository = transactionRepository;
        this.stateService = stateService;
        this.railSelectionService = railSelectionService;
        this.riskFraudService = riskFraudService;
        this.ledgerService = ledgerService;
        this.connectorsByRail = connectors.stream()
                .collect(Collectors.toMap(RailConnector::getRailType, c -> c));
    }

    public PaymentResponse initiatePayment(PaymentRequest request) {

        // 1. Idempotency: a client-generated key that was already processed returns the
        //    ORIGINAL outcome rather than re-executing the payment. Network retries from the
        //    client (e.g. mobile app losing connectivity mid-request) are the norm, not the
        //    exception, on bank rails.
        var existing = transactionRepository.findByIdempotencyKey(request.getIdempotencyKey());
        if (existing.isPresent()) {
            Transaction t = existing.get();
            throw new DuplicateTransactionException(
                    "idempotency_key already processed", toResponse(t));
        }

        // 2. Risk/fraud screening BEFORE any transaction row or fund movement.
        RiskFraudService.RiskDecision decision = riskFraudService.evaluate(request);
        if (!decision.isApproved()) {
            Transaction rejected = createTransaction(request, resolveInitialRail(request));
            rejected.setStatus(TransactionStatus.FAILED);
            rejected.setFailureReason("RISK_REJECTED: " + decision.getReason());
            transactionRepository.save(rejected);
            return toResponse(rejected);
        }

        Transaction transaction = createTransaction(request, resolveInitialRail(request));
        stateService.transition(transaction, TransactionStatus.VALIDATED, "system", "request validated");

        List<RailType> railChain;
        try {
            railChain = railSelectionService.selectRailChain(request);
        } catch (NoEligibleRailException ex) {
            stateService.transition(transaction, TransactionStatus.FAILED, "system", ex.getMessage());
            transaction.setFailureReason(ex.getMessage());
            transactionRepository.save(transaction);
            return toResponse(transaction);
        }

        return executeRailChain(transaction, railChain);
    }

    /** Failover & retry strategy per architecture doc section 5. */
    private PaymentResponse executeRailChain(Transaction transaction, List<RailType> railChain) {

        for (RailType rail : railChain) {
            transaction.setType(rail);
            stateService.transition(transaction, TransactionStatus.RAIL_SELECTED, "system", "trying rail " + rail);

            RailConnector connector = connectorsByRail.get(rail);
            if (connector == null) {
                log.warn("No connector registered for rail {}, skipping in chain", rail);
                continue;
            }

            RailResult result = attemptWithRetry(connector, transaction);

            switch (result.getOutcome()) {
                case SUCCESS -> {
                    return finalizeSuccess(transaction, result);
                }
                case PENDING -> {
                    // Funds may be "authorized/held" but not yet settled (common for UPI/IMPS).
                    // Do NOT credit the ledger yet - wait for reconciliation job to confirm.
                    transaction.setRailReference(result.getRailReference());
                    stateService.transition(transaction, TransactionStatus.RECONCILIATION_PENDING,
                            "system", "rail returned pending, awaiting confirmation");
                    transactionRepository.save(transaction);
                    return toResponse(transaction);
                }
                case TIMEOUT -> {
                    // Never trust silence as failure - queue for reconciliation, don't just retry blindly
                    // across rails, since the partner may have actually accepted the payment.
                    stateService.transition(transaction, TransactionStatus.RECONCILIATION_PENDING,
                            "system", "partner timeout on rail " + rail);
                    transactionRepository.save(transaction);
                    return toResponse(transaction);
                }
                case FAILED -> {
                    log.info("Rail {} failed for transaction {}: {}", rail, transaction.getId(), result.getFailureReason());
                    transaction.setFailureReason(result.getFailureReason());
                    // fall through to next rail in chain
                }
            }
        }

        // All rails in the chain exhausted without success/pending/timeout.
        stateService.transition(transaction, TransactionStatus.PENDING_MANUAL_REVIEW, "system",
                "all rails in fallback chain exhausted: " + transaction.getFailureReason());
        transactionRepository.save(transaction);
        return toResponse(transaction);
    }

    /** Exponential backoff, max 3 attempts, idempotency key/deterministic reference reused across attempts. */
    private RailResult attemptWithRetry(RailConnector connector, Transaction transaction) {
        stateService.transition(transaction, TransactionStatus.SENT_TO_PARTNER, "system",
                "dispatching to " + connector.getRailType());

        RailResult lastResult = null;
        for (int attempt = 1; attempt <= MAX_ATTEMPTS_PER_RAIL; attempt++) {
            transaction.setRetryCount(transaction.getRetryCount() + 1);
            lastResult = connector.send(transaction);

            if (lastResult.getOutcome() != RailResult.Outcome.FAILED || !lastResult.isRetryable()) {
                return lastResult;
            }

            sleepBackoff(attempt);
        }
        return lastResult;
    }

    private void sleepBackoff(int attempt) {
        try {
            long backoffMs = (long) Math.pow(2, attempt) * 200; // 400ms, 800ms, 1600ms
            Thread.sleep(backoffMs);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    // NOTE: not annotated @Transactional here - self-invocation (called via `this.` below)
    // would bypass the Spring AOP proxy anyway. The real atomic boundary is inside
    // LedgerService#postTransfer; state transitions are persisted individually, which is
    // fine because the ledger (not transaction.status) is the source of truth for money
    // movement, and the whole flow is idempotent via idempotency_key on retry/reconciliation.
    private PaymentResponse finalizeSuccess(Transaction transaction, RailResult result) {
        transaction.setRailReference(result.getRailReference());
        stateService.transition(transaction, TransactionStatus.PARTNER_ACK, "system", "partner confirmed");
        stateService.transition(transaction, TransactionStatus.PROCESSING, "system", "posting ledger entries");

        UUID destAccountId = transaction.getDestAccountId() != null
                ? transaction.getDestAccountId()
                : resolveExternalSettlementAccount(transaction);

        String metadata = String.format(
                "{\"rail\":\"%s\",\"railReference\":\"%s\"}",
                transaction.getType(), result.getRailReference());

        ledgerService.postTransfer(transaction.getId(), transaction.getSourceAccountId(),
                destAccountId, transaction.getAmount(), transaction.getCurrency(), metadata);

        stateService.transition(transaction, TransactionStatus.SUCCESS, "system", "ledger posted, payment complete");
        transactionRepository.save(transaction);
        return toResponse(transaction);
    }

    /**
     * For external beneficiaries (NEFT/RTGS/IMPS/UPI/international to another bank),
     * the "destination" from the ledger's point of view is our own suspense/partner-nostro
     * account, since the funds are leaving the platform entirely - not another wallet on it.
     * A separate reconciliation step later matches this against the partner's settlement file.
     */
    private UUID resolveExternalSettlementAccount(Transaction transaction) {
        // TODO: look up the correct suspense/nostro account for transaction.getPartnerProvider()
        // and transaction.getType() from a config-backed account registry.
        throw new UnsupportedOperationException(
                "resolveExternalSettlementAccount must be wired to your suspense-account registry");
    }

    private Transaction createTransaction(PaymentRequest request, RailType initialRailGuess) {
        Transaction t = new Transaction();
        t.setType(initialRailGuess);
        t.setStatus(TransactionStatus.INITIATED);
        t.setSourceAccountId(request.getSourceAccountId());
        t.setDestAccountId(request.getDestAccountId());
        t.setDestBankIfsc(request.getDestBankIfsc());
        t.setDestAccountNumber(request.getDestAccountNumber());
        t.setDestVpa(request.getDestVpa());
        t.setAmount(request.getAmount());
        t.setCurrency(request.getCurrency());
        t.setUrgency(request.getUrgency());
        t.setIdempotencyKey(request.getIdempotencyKey());
        t.setNarration(request.getNarration());
        return transactionRepository.save(t);
    }

    private RailType resolveInitialRail(PaymentRequest request) {
        if (request.getRailOverride() != null) return request.getRailOverride();
        if (request.isInternational()) return RailType.INTERNATIONAL;
        return RailType.NEFT; // placeholder until selectRailChain runs; corrected in executeRailChain
    }

    private PaymentResponse toResponse(Transaction t) {
        return new PaymentResponse(t.getId(), t.getStatus(), t.getType(), t.getRailReference(),
                t.getAmount(), t.getInitiatedAt(), t.getCompletedAt(), t.getFailureReason());
    }
}
