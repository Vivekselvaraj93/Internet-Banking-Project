package com.bank.orchestration.service;

import com.bank.orchestration.model.Transaction;
import com.bank.orchestration.model.TransactionStateLog;
import com.bank.orchestration.model.TransactionStatus;
import com.bank.orchestration.repository.TransactionRepository;
import com.bank.orchestration.repository.TransactionStateLogRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
public class TransactionStateService {

    private final TransactionRepository transactionRepository;
    private final TransactionStateLogRepository stateLogRepository;

    public TransactionStateService(TransactionRepository transactionRepository,
                                    TransactionStateLogRepository stateLogRepository) {
        this.transactionRepository = transactionRepository;
        this.stateLogRepository = stateLogRepository;
    }

    @Transactional
    public void transition(Transaction transaction, TransactionStatus newStatus, String changedBy, String notes) {
        TransactionStatus old = transaction.getStatus();
        transaction.setStatus(newStatus);
        if (newStatus.isTerminal()) {
            transaction.setCompletedAt(Instant.now());
        }
        transactionRepository.save(transaction);
        stateLogRepository.save(new TransactionStateLog(transaction.getId(), old, newStatus, changedBy, notes));
    }
}
