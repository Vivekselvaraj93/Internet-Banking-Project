package com.bank.orchestration.service;

import com.bank.orchestration.connector.RailConnector;
import com.bank.orchestration.dto.RailResult;
import com.bank.orchestration.model.RailType;
import com.bank.orchestration.model.Transaction;
import com.bank.orchestration.model.TransactionStatus;
import com.bank.orchestration.repository.LedgerEntryRepository;
import com.bank.orchestration.repository.TransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * "Never trust a webhook alone." (architecture doc section 5)
 *
 * Two jobs:
 *  1. Every few minutes: poll partner status for any transaction not in a terminal state
 *     (SENT_TO_PARTNER, RECONCILIATION_PENDING, PENDING_MANUAL_REVIEW).
 *  2. Nightly: verify the ledger's core invariant (sum(debits) == sum(credits) per
 *     transaction) across the whole ledger. Any imbalance is a P0 alert.
 */
@Service
public class ReconciliationService {

    private static final Logger log = LoggerFactory.getLogger(ReconciliationService.class);

    private final TransactionRepository transactionRepository;
    private final TransactionStateService stateService;
    private final LedgerEntryRepository ledgerEntryRepository;
    private final Map<RailType, RailConnector> connectorsByRail;

    public ReconciliationService(TransactionRepository transactionRepository,
                                  TransactionStateService stateService,
                                  LedgerEntryRepository ledgerEntryRepository,
                                  List<RailConnector> connectors) {
        this.transactionRepository = transactionRepository;
        this.stateService = stateService;
        this.ledgerEntryRepository = ledgerEntryRepository;
        this.connectorsByRail = connectors.stream()
                .collect(Collectors.toMap(RailConnector::getRailType, c -> c));
    }

    /** Poll every 2 minutes for anything stuck in a non-terminal state. */
    @Scheduled(fixedDelay = 120_000)
    public void pollPendingTransactions() {
        List<Transaction> pending = transactionRepository.findByStatusIn(List.of(
                TransactionStatus.SENT_TO_PARTNER,
                TransactionStatus.RECONCILIATION_PENDING,
                TransactionStatus.PARTNER_ACK,
                TransactionStatus.PROCESSING));

        for (Transaction t : pending) {
            RailConnector connector = connectorsByRail.get(t.getType());
            if (connector == null) continue;

            RailResult status = connector.checkStatus(t);
            switch (status.getOutcome()) {
                case SUCCESS -> {
                    t.setRailReference(status.getRailReference());
                    stateService.transition(t, TransactionStatus.SUCCESS, "reconciliation_job",
                            "confirmed via status poll");
                    // NOTE: if ledger entries weren't posted yet for a PENDING->SUCCESS
                    // transition, post them here via LedgerService before marking SUCCESS.
                }
                case FAILED -> stateService.transition(t, TransactionStatus.FAILED, "reconciliation_job",
                        "confirmed failed via status poll: " + status.getFailureReason());
                case PENDING, TIMEOUT -> log.debug("Transaction {} still pending at partner", t.getId());
            }
        }
    }

    /** Nightly invariant check: every transaction_id's debits must equal its credits. */
    @Scheduled(cron = "0 0 2 * * *") // 02:00 daily
    public void verifyLedgerInvariant() {
        List<UUID> imbalanced = ledgerEntryRepository.findImbalancedTransactions();
        if (!imbalanced.isEmpty()) {
            // In production: raise a P0 page immediately, do not just log.
            log.error("P0 ALERT: ledger imbalance detected for {} transaction(s): {}",
                    imbalanced.size(), imbalanced);
        } else {
            log.info("Nightly ledger invariant check passed - no imbalances found");
        }
    }
}
