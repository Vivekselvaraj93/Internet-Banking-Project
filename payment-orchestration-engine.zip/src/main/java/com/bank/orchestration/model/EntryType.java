package com.bank.orchestration.model;

public enum EntryType {
    DEBIT,
    CREDIT
}
