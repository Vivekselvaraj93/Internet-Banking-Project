package com.bank.orchestration.model;

public enum Urgency {
    INSTANT,
    SAME_DAY,
    STANDARD
}
