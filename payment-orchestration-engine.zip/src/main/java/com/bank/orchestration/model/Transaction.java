package com.bank.orchestration.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "transactions")
@Getter
@Setter
@NoArgsConstructor
public class Transaction {

    @Id
    @GeneratedValue
    private UUID id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private RailType type;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private TransactionStatus status;

    @Column(name = "source_account_id", nullable = false)
    private UUID sourceAccountId;

    /** nullable if external, e.g. NEFT to another bank */
    @Column(name = "dest_account_id")
    private UUID destAccountId;

    @Column(name = "dest_bank_ifsc", length = 11)
    private String destBankIfsc;

    @Column(name = "dest_account_number", length = 34)
    private String destAccountNumber;

    /** For UPI payments */
    @Column(name = "dest_vpa", length = 100)
    private String destVpa;

    @Column(nullable = false, precision = 20, scale = 4)
    private BigDecimal amount;

    @Column(nullable = false, length = 3)
    private String currency = "INR";

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Urgency urgency;

    /** UTR/RRN returned by NPCI/bank once the rail confirms the payment */
    @Column(name = "rail_reference", length = 64)
    private String railReference;

    @Column(name = "idempotency_key", nullable = false, unique = true, length = 64)
    private String idempotencyKey;

    /** 'setu','decentro','cashfree', etc. */
    @Column(name = "partner_provider", length = 30)
    private String partnerProvider;

    @Column(name = "retry_count", nullable = false)
    private int retryCount = 0;

    @Column(name = "initiated_at", nullable = false)
    private Instant initiatedAt = Instant.now();

    @Column(name = "completed_at")
    private Instant completedAt;

    @Column(name = "failure_reason")
    private String failureReason;

    /** Free-form narration / purpose, e.g. insurance policy number */
    @Column(name = "narration", length = 255)
    private String narration;
}
