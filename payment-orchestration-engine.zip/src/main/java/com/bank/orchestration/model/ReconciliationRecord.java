package com.bank.orchestration.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "reconciliation_records")
@Getter
@Setter
@NoArgsConstructor
public class ReconciliationRecord {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "transaction_id")
    private UUID transactionId;

    @Column(name = "partner_statement_ref", length = 64)
    private String partnerStatementRef;

    /** MATCHED | UNMATCHED | MISMATCH_AMOUNT | ORPHAN */
    @Column(name = "match_status", length = 20)
    private String matchStatus;

    @Column(name = "reconciled_at")
    private Instant reconciledAt;

    @Lob
    @Column(name = "raw_partner_record")
    private String rawPartnerRecord;
}
