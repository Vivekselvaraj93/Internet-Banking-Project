package com.bank.orchestration.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "accounts")
@Getter
@Setter
@NoArgsConstructor
public class Account {

    @Id
    @GeneratedValue
    private UUID id;

    /** user_wallet | merchant | suspense | fee_revenue | partner_nostro */
    @Column(name = "account_type", nullable = false, length = 30)
    private String accountType;

    /** FK to users/merchants; null for system accounts */
    @Column(name = "owner_id")
    private UUID ownerId;

    @Column(nullable = false, length = 3)
    private String currency = "INR";

    @Column(nullable = false, length = 20)
    private String status = "active";

    @Column(name = "created_at", nullable = false)
    private Instant createdAt = Instant.now();

    /** Optimistic lock version; row-level pessimistic locking is also used
     *  explicitly via LedgerService#lockAccount (SELECT ... FOR UPDATE). */
    @Version
    private Long version;
}
