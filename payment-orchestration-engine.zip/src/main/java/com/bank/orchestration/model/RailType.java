package com.bank.orchestration.model;

/** Supported payment rails. */
public enum RailType {
    UPI,
    IMPS,
    NEFT,
    RTGS,
    INTERNATIONAL,
    INSURANCE_PREMIUM
}
