package com.bank.orchestration.model;

/**
 * Mirrors the state machine in the architecture doc:
 * INITIATED -> VALIDATED -> RAIL_SELECTED -> SENT_TO_PARTNER ->
 *   PARTNER_ACK -> PROCESSING -> SUCCESS
 *   PARTNER_ACK -> PROCESSING -> FAILED -> REVERSAL_INITIATED -> REVERSED
 *   TIMEOUT -> RECONCILIATION_PENDING -> SUCCESS/FAILED
 */
public enum TransactionStatus {
    INITIATED,
    VALIDATED,
    RAIL_SELECTED,
    SENT_TO_PARTNER,
    PARTNER_ACK,
    PROCESSING,
    TIMEOUT,
    RECONCILIATION_PENDING,
    PENDING_MANUAL_REVIEW,
    SUCCESS,
    FAILED,
    REVERSAL_INITIATED,
    REVERSED;

    public boolean isTerminal() {
        return this == SUCCESS || this == FAILED || this == REVERSED;
    }
}
