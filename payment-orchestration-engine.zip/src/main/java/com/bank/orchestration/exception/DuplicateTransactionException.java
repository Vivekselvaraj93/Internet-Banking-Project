package com.bank.orchestration.exception;

import com.bank.orchestration.dto.PaymentResponse;

/** Thrown when an idempotency key was already used with a different payload;
 *  callers should catch this and return the ORIGINAL response, not a new transaction. */
public class DuplicateTransactionException extends RuntimeException {
    private final PaymentResponse existingResponse;

    public DuplicateTransactionException(String message, PaymentResponse existingResponse) {
        super(message);
        this.existingResponse = existingResponse;
    }

    public PaymentResponse getExistingResponse() { return existingResponse; }
}
