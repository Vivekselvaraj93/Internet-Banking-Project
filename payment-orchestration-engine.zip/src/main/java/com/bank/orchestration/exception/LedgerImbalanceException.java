package com.bank.orchestration.exception;

/** Thrown (and treated as a P0 alert) when sum(debits) != sum(credits) for a transaction. */
public class LedgerImbalanceException extends RuntimeException {
    public LedgerImbalanceException(String message) { super(message); }
}
