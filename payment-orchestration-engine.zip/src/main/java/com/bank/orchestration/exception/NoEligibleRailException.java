package com.bank.orchestration.exception;

public class NoEligibleRailException extends RuntimeException {
    public NoEligibleRailException(String message) { super(message); }
}
