package com.bank.orchestration;

import com.bank.orchestration.dto.PaymentRequest;
import com.bank.orchestration.model.RailType;
import com.bank.orchestration.model.Urgency;
import com.bank.orchestration.service.RailSelectionService;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RailSelectionServiceTest {

    private final RailSelectionService service = new RailSelectionService();

    @Test
    void instantSmallAmount_prefersUpi() {
        PaymentRequest req = baseRequest(new BigDecimal("5000"), Urgency.INSTANT);
        List<RailType> chain = service.selectRailChain(req);
        assertEquals(RailType.UPI, chain.get(0));
    }

    @Test
    void instantAboveUpiLimit_fallsBackToImps() {
        PaymentRequest req = baseRequest(new BigDecimal("150000"), Urgency.INSTANT);
        List<RailType> chain = service.selectRailChain(req);
        assertEquals(RailType.IMPS, chain.get(0));
    }

    @Test
    void standardUrgency_usesNeft() {
        PaymentRequest req = baseRequest(new BigDecimal("50000"), Urgency.STANDARD);
        List<RailType> chain = service.selectRailChain(req);
        assertEquals(RailType.NEFT, chain.get(0));
    }

    @Test
    void internationalFlag_forcesInternationalRail() {
        PaymentRequest req = baseRequest(new BigDecimal("10000"), Urgency.STANDARD);
        req.setInternational(true);
        List<RailType> chain = service.selectRailChain(req);
        assertEquals(List.of(RailType.INTERNATIONAL), chain);
    }

    @Test
    void railOverride_bypassesSelectionLogic() {
        PaymentRequest req = baseRequest(new BigDecimal("500"), Urgency.STANDARD);
        req.setRailOverride(RailType.INSURANCE_PREMIUM);
        List<RailType> chain = service.selectRailChain(req);
        assertEquals(List.of(RailType.INSURANCE_PREMIUM), chain);
    }

    private PaymentRequest baseRequest(BigDecimal amount, Urgency urgency) {
        PaymentRequest req = new PaymentRequest();
        req.setSourceAccountId(UUID.randomUUID());
        req.setDestAccountNumber("1234567890");
        req.setDestBankIfsc("HDFC0000123");
        req.setAmount(amount);
        req.setCurrency("INR");
        req.setUrgency(urgency);
        req.setIdempotencyKey(UUID.randomUUID().toString());
        return req;
    }
}
