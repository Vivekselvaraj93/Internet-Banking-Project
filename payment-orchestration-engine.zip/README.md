# Payment Orchestration Engine (Java / Spring Boot)

A reference implementation of the **Payment Orchestration Engine** from the IB banking
architecture doc, covering **NEFT, RTGS, IMPS, UPI, and Insurance premium collection**
(an International/SWIFT connector stub is included too, since the doc treats it as a
sibling rail).

This is a working skeleton you can run locally (H2 in-memory DB, mock partner responses)
and extend into production by swapping the clearly-marked seams — it is **not** wired to
any real bank/BaaS partner, since that requires your own commercial agreements and API
credentials with a licensed partner (Setu, Decentro, Cashfree, M2P, RazorpayX, etc.).

## Run it

```bash
cd payment-orchestration-engine
mvn spring-boot:run
```

Boots on `http://localhost:8080` against an in-memory H2 database (console at
`/h2-console`). No external services required — `MockPartnerApiClient` simulates a BaaS
partner's responses (85% success, 7% pending, 5% retryable failure, 3% timeout) so you can
see the full retry/failover/state-machine flow end-to-end immediately.

```bash
mvn test   # runs RailSelectionServiceTest
```

> I couldn't compile/run this myself in this environment — no `javac`/`mvn` and no
> network access to Maven Central here — so please run `mvn spring-boot:run` /
> `mvn test` on your side as a first sanity check before building on top of it.

## API

```bash
POST /api/v1/payments
{
  "sourceAccountId": "「uuid」",
  "destAccountNumber": "1234567890",
  "destBankIfsc": "HDFC0000123",
  "amount": 15000,
  "currency": "INR",
  "urgency": "INSTANT",
  "idempotencyKey": "client-generated-unique-key-001"
}
```

```bash
POST /api/v1/insurance-payments/premium
{
  "sourceAccountId": "「uuid」",
  "insurerSettlementAccountId": "「uuid」",
  "amount": 4999,
  "insurerCode": "HDFCLIFE",
  "policyNumber": "POL-2026-00123",
  "idempotencyKey": "premium-jul-2026-POL-2026-00123"
}
```

## How the doc's design maps to the code

| Architecture doc concept | Class |
|---|---|
| Payment Orchestration Engine | `PaymentOrchestrationService` |
| Rail selection pseudocode (§5) | `RailSelectionService` |
| NEFT/RTGS/IMPS/UPI/Intl/Insurance connectors | `connector/*Connector.java` |
| Sponsor Bank / BaaS Partner API | `PartnerApiClient` (mocked; swap for real client) |
| Ledger Service, double-entry | `LedgerService` + `LedgerEntry`/`Account` entities |
| Transaction state machine (§5) | `TransactionStatus` + `TransactionStateService` |
| "Never trust a webhook alone" reconciliation | `ReconciliationService` (`@Scheduled`) |
| Risk & Fraud Engine | `RiskFraudService` (stub — wire to a real screening provider) |
| Idempotency everywhere | `Transaction.idempotencyKey` (unique) + `AbstractPartnerConnector.deriveDeterministicReference` |
| Row-level locking on accounts | `AccountRepository.lockById` (`SELECT ... FOR UPDATE`) |
| Nightly ledger invariant check | `ReconciliationService.verifyLedgerInvariant` (cron `0 0 2 * * *`) |

## What's genuinely implemented vs. what's a marked stub

**Implemented:**
- Full request → validate → risk-check → rail-selection → dispatch → retry → failover →
  ledger-post → state-machine flow
- Idempotency at both the API boundary (`idempotency_key` uniqueness) and the partner
  boundary (deterministic SHA-256 partner reference per rail+key)
- Double-entry ledger with pessimistic row locks and a per-transaction balance invariant
  check, matching the doc's non-negotiable design rules in §4
- Rail-specific validation (RTGS min ₹2L, IMPS max ₹5L, UPI max ₹1L + VPA requirement)
- Reconciliation polling job + nightly ledger-integrity job

**Deliberately stubbed — these need real integration work before production:**
- `PartnerApiClient` → real HTTP calls to your chosen BaaS partner's API (`MockPartnerApiClient` has a `TODO` marking exactly where)
- `RiskFraudService` → real AML/velocity/OFAC-sanctions screening provider
- `resolveExternalSettlementAccount` in `PaymentOrchestrationService` → your suspense/nostro account registry
- `application.yml`'s `postgres` profile → real credentials/secrets management (don't hardcode)
- DB schema migrations → use Flyway/Liquibase instead of `ddl-auto` once you're past local dev

## Known simplifications worth flagging

- `Thread.sleep` is used for retry backoff for readability; swap for Spring Retry's
  `@Retryable`/`RetryTemplate` (already a declared dependency) or a non-blocking scheduler
  in a real service so retries don't tie up request threads.
- The reconciliation poll loop calls partner APIs synchronously in a single thread; at
  volume, parallelize per-partner with rate limiting.
- PA (Payment Aggregator) licensing, PCI-DSS scope, and data-localization requirements
  from the doc's compliance checklist are **organizational/legal** requirements, not code
  — nothing in this repo satisfies them by itself.
