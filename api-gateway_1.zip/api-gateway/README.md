# API Gateway — Fintech Platform

Spring Cloud Gateway service: single entry point for all client traffic,
handling JWT auth, idempotency enforcement, rate limiting (via Redis), routing,
and circuit breaking to downstream microservices (ledger, payment orchestration,
UPI, international payments, insurance, KYC).

## Project Structure

```
api-gateway/
├── pom.xml
├── Dockerfile
├── cloudbuild.yaml
├── src/main/java/com/fintech/gateway/
│   ├── ApiGatewayApplication.java
│   ├── config/
│   │   ├── RouteConfig.java          # downstream service routes
│   │   ├── ResilienceConfig.java     # circuit breaker tuning
│   │   └── FallbackController.java   # responses when a service is down
│   ├── filter/
│   │   ├── JwtAuthenticationFilter.java
│   │   ├── IdempotencyFilter.java
│   │   └── RequestLoggingFilter.java
│   ├── security/JwtValidator.java
│   └── exception/GlobalErrorHandler.java
├── src/main/resources/application.yml
└── k8s/
    ├── 00-namespace.yaml
    ├── 01-configmap.yaml
    ├── 02-secret-template.yaml
    ├── 03-deployment.yaml
    ├── 04-service.yaml
    ├── 05-hpa.yaml
    ├── 06-pdb.yaml
    └── 07-ingress.yaml
```

## Prerequisites

- A GKE cluster (Autopilot or Standard) running
- Artifact Registry repository created:
  ```bash
  gcloud artifacts repositories create fintech-images \
    --repository-format=docker \
    --location=us-central1
  ```
- A Redis instance reachable from the cluster (e.g. Memorystore for Redis)
- A real JWT signing secret stored in GCP Secret Manager

## 1. Build & push the image manually (first time / local testing)

```bash
export PROJECT_ID=$(gcloud config get-value project)
export REGION=us-central1

docker build -t ${REGION}-docker.pkg.dev/${PROJECT_ID}/fintech-images/api-gateway:1.0.0 .

gcloud auth configure-docker ${REGION}-docker.pkg.dev

docker push ${REGION}-docker.pkg.dev/${PROJECT_ID}/fintech-images/api-gateway:1.0.0
```

Update the `image:` field in `k8s/03-deployment.yaml` to match your project/region.

## 2. Set up secrets

**Recommended:** install the External Secrets Operator and apply
`k8s/02-secret-template.yaml` as-is — it will sync `JWT_SIGNING_SECRET` from
GCP Secret Manager automatically.

**For local/dev testing only:**
```bash
kubectl create namespace fintech
kubectl create secret generic api-gateway-secret \
  --namespace=fintech \
  --from-literal=JWT_SIGNING_SECRET="$(openssl rand -base64 32)"
```

## 3. Deploy to GKE

```bash
kubectl apply -f k8s/00-namespace.yaml
kubectl apply -f k8s/01-configmap.yaml
kubectl apply -f k8s/02-secret-template.yaml   # or your manual secret
kubectl apply -f k8s/03-deployment.yaml
kubectl apply -f k8s/04-service.yaml
kubectl apply -f k8s/05-hpa.yaml
kubectl apply -f k8s/06-pdb.yaml

# Reserve the static IP referenced by the Ingress first:
gcloud compute addresses create api-gateway-ip --global
kubectl apply -f k8s/07-ingress.yaml
```

Check rollout:
```bash
kubectl rollout status deployment/api-gateway -n fintech
kubectl get pods -n fintech -l app=api-gateway
```

DNS: point `api.yourfintech.com` at the static IP shown by:
```bash
gcloud compute addresses describe api-gateway-ip --global
```
The Google-managed certificate will auto-provision once DNS resolves correctly
(can take 15–60 minutes).

## 4. Continuous deployment

`cloudbuild.yaml` is wired for Cloud Build: connect this repo as a Cloud Build
trigger (on push to `main`), and every commit will build, push, and roll out
automatically. Substitution variables (`_REGION`, `_REPOSITORY`, `_ZONE`,
`_CLUSTER`) can be overridden per-trigger.

## Notes on extending this to the rest of the platform

This gateway routes to downstream services that **don't exist yet** — they're
referenced by Kubernetes DNS name (e.g. `payment-orchestration-service.fintech.svc.cluster.local`)
in `RouteConfig.java`. Build each one as its own Spring Boot service, each with
its own Deployment/Service manifest following this same pattern, and deploy
them into the same `fintech` namespace so the DNS names resolve.

Suggested build order: **Ledger Service** next (it's the system of record
everything else depends on), then **Payment Orchestration Service**, then the
individual rail connectors (UPI, NEFT/RTGS/IMPS via BaaS partner, international,
insurance).
