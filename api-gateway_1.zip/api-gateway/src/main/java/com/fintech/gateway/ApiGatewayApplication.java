package com.fintech.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point for the Fintech Platform API Gateway.
 *
 * Responsibilities of this service:
 *  - Single ingress point for all client traffic (web/mobile/partner API)
 *  - JWT authentication enforcement
 *  - Per-client rate limiting (Redis token bucket)
 *  - Idempotency key enforcement on mutating payment requests
 *  - Routing to downstream microservices (ledger, orchestration, UPI, KYC, etc.)
 *  - Circuit breaking against unhealthy downstream services
 */
@SpringBootApplication
public class ApiGatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayApplication.class, args);
    }
}
