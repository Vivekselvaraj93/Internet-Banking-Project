package com.fintech.gateway.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;

/**
 * Validates and parses JWTs issued by the platform's Auth Service.
 * Uses HMAC-SHA signing; in production the signing key should come from
 * GCP Secret Manager (mounted as an env var / volume), never hardcoded.
 */
@Component
public class JwtValidator {

    private final SecretKey signingKey;

    public JwtValidator(@Value("${security.jwt.secret}") String secret) {
        this.signingKey = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    public Mono<TokenClaims> validate(String token) {
        return Mono.fromCallable(() -> {
            Claims claims = Jwts.parser()
                    .verifyWith(signingKey)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();

            String userId = claims.getSubject();
            String role = claims.get("role", String.class);

            if (userId == null || role == null) {
                throw new IllegalArgumentException("Token missing required claims");
            }
            return new TokenClaims(userId, role);
        }).subscribeOn(Schedulers.boundedElastic());
    }

    public record TokenClaims(String userId, String role) {}
}
