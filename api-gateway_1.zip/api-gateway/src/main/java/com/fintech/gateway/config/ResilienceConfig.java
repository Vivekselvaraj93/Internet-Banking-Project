package com.fintech.gateway.config;

import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.timelimiter.TimeLimiterConfig;
import org.springframework.cloud.circuitbreaker.resilience4j.ReactiveResilience4JCircuitBreakerFactory;
import org.springframework.cloud.circuitbreaker.resilience4j.Resilience4JConfigBuilder;
import org.springframework.cloud.client.circuitbreaker.Customizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

/**
 * Default circuit breaker tuning applied to every route. Tripped after a
 * sustained failure rate; downstream services get breathing room to recover
 * (e.g. during a deploy, pod restart, or DB failover) instead of being
 * hammered with traffic from a backlog of retried requests.
 */
@Configuration
public class ResilienceConfig {

    @Bean
    public Customizer<ReactiveResilience4JCircuitBreakerFactory> defaultCustomizer() {
        return factory -> factory.configureDefault(id -> new Resilience4JConfigBuilder(id)
                .circuitBreakerConfig(CircuitBreakerConfig.custom()
                        .failureRateThreshold(50)               // open circuit if >=50% of calls fail
                        .waitDurationInOpenState(Duration.ofSeconds(15))
                        .slidingWindowSize(20)
                        .minimumNumberOfCalls(10)
                        .permittedNumberOfCallsInHalfOpenState(5)
                        .build())
                .timeLimiterConfig(TimeLimiterConfig.custom()
                        .timeoutDuration(Duration.ofSeconds(6))  // downstream call timeout
                        .build())
                .build());
    }
}
