package com.fintech.gateway.config;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.Map;

/**
 * Invoked by Resilience4j when a downstream service's circuit breaker is
 * open (i.e. it has been failing repeatedly). Returns a clear 503 rather
 * than letting the client hang or see a raw connection error.
 */
@RestController
@RequestMapping("/fallback")
public class FallbackController {

    @RequestMapping("/payments")
    public Mono<ResponseEntity<Map<String, Object>>> paymentsFallback() {
        return fallbackResponse("Payment service is temporarily unavailable. Your request was not processed — please retry in a moment.");
    }

    @RequestMapping("/ledger")
    public Mono<ResponseEntity<Map<String, Object>>> ledgerFallback() {
        return fallbackResponse("Ledger service is temporarily unavailable.");
    }

    @RequestMapping("/upi")
    public Mono<ResponseEntity<Map<String, Object>>> upiFallback() {
        return fallbackResponse("UPI service is temporarily unavailable. Your request was not processed — please retry.");
    }

    @RequestMapping("/international-payments")
    public Mono<ResponseEntity<Map<String, Object>>> intlPaymentsFallback() {
        return fallbackResponse("International payments service is temporarily unavailable.");
    }

    @RequestMapping("/insurance")
    public Mono<ResponseEntity<Map<String, Object>>> insuranceFallback() {
        return fallbackResponse("Insurance payments service is temporarily unavailable.");
    }

    @RequestMapping("/kyc")
    public Mono<ResponseEntity<Map<String, Object>>> kycFallback() {
        return fallbackResponse("KYC/onboarding service is temporarily unavailable.");
    }

    private Mono<ResponseEntity<Map<String, Object>>> fallbackResponse(String message) {
        Map<String, Object> body = Map.of(
                "error", "service_unavailable",
                "message", message,
                "timestamp", Instant.now().toString()
        );
        return Mono.just(ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(body));
    }
}
