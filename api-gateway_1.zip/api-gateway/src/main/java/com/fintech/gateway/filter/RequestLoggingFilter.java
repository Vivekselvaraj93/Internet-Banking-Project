package com.fintech.gateway.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.UUID;

/**
 * Stamps every request with a correlation ID (X-Correlation-Id) that is
 * propagated to all downstream microservices. This is essential for tracing
 * a single payment across gateway -> orchestration -> ledger -> bank connector
 * in centralized logging (GCP Cloud Logging / Cloud Trace).
 */
@Component
public class RequestLoggingFilter implements GlobalFilter, Ordered {

    private static final Logger log = LoggerFactory.getLogger(RequestLoggingFilter.class);
    private static final String CORRELATION_HEADER = "X-Correlation-Id";

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();

        String correlationId = request.getHeaders().getFirst(CORRELATION_HEADER);
        if (correlationId == null || correlationId.isBlank()) {
            correlationId = UUID.randomUUID().toString();
        }
        final String finalCorrelationId = correlationId;

        ServerHttpRequest mutatedRequest = request.mutate()
                .header(CORRELATION_HEADER, finalCorrelationId)
                .build();

        long startTime = System.currentTimeMillis();

        log.info("Incoming request method={} path={} correlationId={}",
                request.getMethod(), request.getURI().getPath(), finalCorrelationId);

        return chain.filter(exchange.mutate().request(mutatedRequest).build())
                .doFinally(signal -> {
                    long duration = System.currentTimeMillis() - startTime;
                    log.info("Completed request path={} correlationId={} durationMs={} status={}",
                            request.getURI().getPath(), finalCorrelationId, duration,
                            exchange.getResponse().getStatusCode());
                });
    }

    @Override
    public int getOrder() {
        // Run first, before auth, so even rejected requests are logged with a correlation ID
        return -200;
    }
}
