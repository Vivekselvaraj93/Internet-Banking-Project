package com.fintech.gateway.config;

import org.springframework.cloud.client.circuitbreaker.ReactiveCircuitBreakerFactory;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.net.URI;
import java.time.Duration;

/**
 * Defines routing rules from the gateway to each backend microservice.
 *
 * In Kubernetes, downstream URIs use Kubernetes Service DNS names
 * (e.g. http://ledger-service.fintech.svc.cluster.local) rather than
 * hardcoded IPs, so routing keeps working across pod restarts/rescheduling.
 *
 * Each route is wrapped with a circuit breaker: if a downstream service is
 * unhealthy, the gateway fails fast instead of piling up timed-out requests.
 */
@Configuration
public class RouteConfig {

    @Bean
    public RouteLocator routes(RouteLocatorBuilder builder) {
        return builder.routes()

                // Payment Orchestration Service - handles NEFT/RTGS/IMPS/UPI rail selection
                .route("payment-orchestration", r -> r
                        .path("/payments/**")
                        .filters(f -> f
                                .circuitBreaker(c -> c
                                        .setName("paymentOrchestrationCB")
                                        .setFallbackUri("forward:/fallback/payments"))
                                .retry(retryConfig -> retryConfig.setRetries(2)))
                        .uri("http://payment-orchestration-service.fintech.svc.cluster.local:8080"))

                // Ledger Service - balance, transaction history, statements
                .route("ledger-service", r -> r
                        .path("/ledger/**", "/accounts/**")
                        .filters(f -> f.circuitBreaker(c -> c
                                .setName("ledgerCB")
                                .setFallbackUri("forward:/fallback/ledger")))
                        .uri("http://ledger-service.fintech.svc.cluster.local:8080"))

                // UPI Connector Service
                .route("upi-service", r -> r
                        .path("/upi/**")
                        .filters(f -> f.circuitBreaker(c -> c
                                .setName("upiCB")
                                .setFallbackUri("forward:/fallback/upi")))
                        .uri("http://upi-connector-service.fintech.svc.cluster.local:8080"))

                // International Payments Service
                .route("intl-payments-service", r -> r
                        .path("/international-payments/**")
                        .filters(f -> f.circuitBreaker(c -> c
                                .setName("intlPaymentsCB")
                                .setFallbackUri("forward:/fallback/international-payments")))
                        .uri("http://intl-payments-service.fintech.svc.cluster.local:8080"))

                // Insurance Payments Service
                .route("insurance-service", r -> r
                        .path("/insurance/**")
                        .filters(f -> f.circuitBreaker(c -> c
                                .setName("insuranceCB")
                                .setFallbackUri("forward:/fallback/insurance")))
                        .uri("http://insurance-service.fintech.svc.cluster.local:8080"))

                // KYC / Onboarding Service
                .route("kyc-service", r -> r
                        .path("/kyc/**", "/onboarding/**")
                        .filters(f -> f.circuitBreaker(c -> c
                                .setName("kycCB")
                                .setFallbackUri("forward:/fallback/kyc")))
                        .uri("http://kyc-service.fintech.svc.cluster.local:8080"))

                // Auth Service - login/token issuance (public, no JWT required by definition)
                .route("auth-service", r -> r
                        .path("/auth/**")
                        .uri("http://auth-service.fintech.svc.cluster.local:8080"))

                .build();
    }
}
