package com.fintech.gateway.filter;

import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.data.redis.core.ReactiveStringRedisTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.Set;

/**
 * Enforces idempotency-key usage on all mutating calls under /payments/**.
 *
 * Banking/payment rails are retried constantly (client timeouts, mobile
 * network drops, partner timeouts). Without idempotency enforcement at the
 * edge, retries can cause duplicate debits. This filter:
 *   1. Requires an "Idempotency-Key" header on POST/PUT/PATCH to /payments/**
 *   2. Checks Redis for a key that was already seen
 *   3. If seen and still "in-flight" -> reject as 409 (let the original complete)
 *   4. If new -> reserve the key with a short TTL so concurrent duplicate
 *      requests are blocked while the first request is processed.
 *
 * The downstream Payment Orchestration Service still owns full idempotent
 * processing (this is a fast-fail edge guard, not a replacement for it).
 */
@Component
public class IdempotencyFilter implements GlobalFilter, Ordered {

    private static final Set<HttpMethod> MUTATING_METHODS = Set.of(
            HttpMethod.POST, HttpMethod.PUT, HttpMethod.PATCH
    );
    private static final Duration RESERVATION_TTL = Duration.ofSeconds(30);
    private static final String REDIS_KEY_PREFIX = "idem:";

    private final ReactiveStringRedisTemplate redisTemplate;

    public IdempotencyFilter(ReactiveStringRedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();

        boolean requiresIdempotency = request.getURI().getPath().startsWith("/payments")
                && MUTATING_METHODS.contains(request.getMethod());

        if (!requiresIdempotency) {
            return chain.filter(exchange);
        }

        String idempotencyKey = request.getHeaders().getFirst("Idempotency-Key");
        if (idempotencyKey == null || idempotencyKey.isBlank()) {
            return reject(exchange, HttpStatus.BAD_REQUEST,
                    "Idempotency-Key header is required for payment-initiating requests");
        }

        String redisKey = REDIS_KEY_PREFIX + idempotencyKey;

        // setIfAbsent == atomic "reserve" operation
        return redisTemplate.opsForValue()
                .setIfAbsent(redisKey, "IN_FLIGHT", RESERVATION_TTL)
                .flatMap(wasReserved -> {
                    if (Boolean.TRUE.equals(wasReserved)) {
                        return chain.filter(exchange);
                    }
                    return reject(exchange, HttpStatus.CONFLICT,
                            "Duplicate request: this idempotency key is already being processed");
                });
    }

    private Mono<Void> reject(ServerWebExchange exchange, HttpStatus status, String message) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(status);
        response.getHeaders().add("Content-Type", "application/json");
        String body = String.format("{\"error\":\"%s\",\"message\":\"%s\"}",
                status.getReasonPhrase().toLowerCase().replace(" ", "_"), message);
        var buffer = response.bufferFactory().wrap(body.getBytes());
        return response.writeWith(Mono.just(buffer));
    }

    @Override
    public int getOrder() {
        // Run after auth, before routing
        return -50;
    }
}
