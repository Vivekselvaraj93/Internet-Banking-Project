CREATE TABLE bank_transfer_transactions (
    id                              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    orchestration_transaction_id    UUID NOT NULL UNIQUE,
    rail                            VARCHAR(10) NOT NULL CHECK (rail IN ('NEFT','RTGS','IMPS')),
    beneficiary_account_number      VARCHAR(34) NOT NULL,
    beneficiary_ifsc                VARCHAR(11) NOT NULL,
    beneficiary_name                VARCHAR(140) NOT NULL,
    amount                          NUMERIC(20,4) NOT NULL CHECK (amount > 0),
    currency                        CHAR(3) NOT NULL,
    status                          VARCHAR(20) NOT NULL DEFAULT 'INITIATED',
    utr                             VARCHAR(30),
    partner_reference               VARCHAR(64),
    partner_provider                VARCHAR(30),
    failure_reason                  TEXT,
    fallback_from_rail              VARCHAR(10),
    initiated_at                    TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at                    TIMESTAMPTZ,
    version                         BIGINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_btt_orchestration_ref ON bank_transfer_transactions(orchestration_transaction_id);
CREATE INDEX idx_btt_partner_ref ON bank_transfer_transactions(partner_reference);
CREATE INDEX idx_btt_status_initiated ON bank_transfer_transactions(status, initiated_at);
