package com.fintech.bankrails.client;

import com.fintech.bankrails.model.BankTransferTransaction.Rail;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Abstraction over the sponsor bank / BaaS partner's API Banking product
 * (Setu, Decentro, M2P, Cashfree Payouts, RazorpayX...). Keeps the platform
 * swappable between partners without touching business logic.
 */
public interface BankRailsPartnerClient {

    Mono<PartnerInitiationResult> initiateTransfer(
            UUID orchestrationTransactionId,
            Rail rail,
            String beneficiaryAccountNumber,
            String beneficiaryIfsc,
            String beneficiaryName,
            BigDecimal amount,
            String currency,
            String narration
    );

    Mono<PartnerStatusResult> checkStatus(String partnerReference);

    record PartnerInitiationResult(
            String partnerReference,
            String status,
            String utr
    ) {}

    record PartnerStatusResult(
            String status,
            String utr,
            String failureReason
    ) {}
}
