package com.fintech.bankrails.controller;

import com.fintech.bankrails.dto.BankTransferWebhookPayload;
import com.fintech.bankrails.service.BankTransferService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.HexFormat;
import java.util.Map;

@RestController
public class BankTransferWebhookController {

    private static final Logger log = LoggerFactory.getLogger(BankTransferWebhookController.class);

    private final BankTransferService bankTransferService;
    private final String webhookSigningSecret;

    public BankTransferWebhookController(BankTransferService bankTransferService,
                                          @Value("${bankrails.partner.setu.webhook-secret}") String webhookSigningSecret) {
        this.bankTransferService = bankTransferService;
        this.webhookSigningSecret = webhookSigningSecret;
    }

    @PostMapping("/bank-transfers/webhooks/setu")
    public ResponseEntity<Map<String, String>> handleWebhook(
            @RequestHeader(value = "X-Setu-Signature", required = false) String signature,
            @RequestBody String rawBody) {

        if (!isValidSignature(rawBody, signature)) {
            log.warn("Rejected bank transfer webhook with invalid signature");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "invalid_signature"));
        }

        BankTransferWebhookPayload payload = parsePayload(rawBody);
        bankTransferService.handleWebhook(payload);

        return ResponseEntity.ok(Map.of("status", "received"));
    }

    private boolean isValidSignature(String rawBody, String providedSignature) {
        if (providedSignature == null) return false;
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(webhookSigningSecret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] computedHash = mac.doFinal(rawBody.getBytes(StandardCharsets.UTF_8));
            String computedSignature = HexFormat.of().formatHex(computedHash);
            return constantTimeEquals(computedSignature, providedSignature);
        } catch (Exception ex) {
            log.error("Webhook signature verification failed: {}", ex.getMessage());
            return false;
        }
    }

    private boolean constantTimeEquals(String a, String b) {
        if (a.length() != b.length()) return false;
        int result = 0;
        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }
        return result == 0;
    }

    private BankTransferWebhookPayload parsePayload(String rawBody) {
        try {
            com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
            return mapper.readValue(rawBody, BankTransferWebhookPayload.class);
        } catch (Exception ex) {
            throw new IllegalArgumentException("Malformed webhook payload", ex);
        }
    }
}
