package com.fintech.bankrails.dto;

import com.fintech.bankrails.model.BankTransferTransaction;

import java.time.Instant;
import java.util.UUID;

public record BankTransferResponse(
        UUID orchestrationTransactionId,
        BankTransferTransaction.Rail rail,
        BankTransferTransaction.BankTransferStatus status,
        String utr,
        String partnerReference,
        String failureReason,
        String fallbackFromRail,
        Instant initiatedAt,
        Instant completedAt
) {
    public static BankTransferResponse from(BankTransferTransaction txn) {
        return new BankTransferResponse(
                txn.getOrchestrationTransactionId(),
                txn.getRail(),
                txn.getStatus(),
                txn.getUtr(),
                txn.getPartnerReference(),
                txn.getFailureReason(),
                txn.getFallbackFromRail(),
                txn.getInitiatedAt(),
                txn.getCompletedAt()
        );
    }
}
