package com.fintech.bankrails.config;

import com.fintech.bankrails.service.BankTransferService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ReconciliationScheduler {

    private static final Logger log = LoggerFactory.getLogger(ReconciliationScheduler.class);

    private final BankTransferService bankTransferService;

    public ReconciliationScheduler(BankTransferService bankTransferService) {
        this.bankTransferService = bankTransferService;
    }

    /**
     * Runs every 2 minutes — a longer interval than the UPI connector's,
     * since NEFT settles in batches and isn't expected to resolve instantly.
     */
    @Scheduled(fixedDelay = 120_000)
    public void reconcile() {
        try {
            bankTransferService.reconcilePendingTransactions();
        } catch (Exception ex) {
            log.error("Reconciliation job failed: {}", ex.getMessage(), ex);
        }
    }
}
