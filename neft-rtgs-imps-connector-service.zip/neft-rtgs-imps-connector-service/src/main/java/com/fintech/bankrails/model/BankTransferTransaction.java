package com.fintech.bankrails.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "bank_transfer_transactions", indexes = {
        @Index(name = "idx_btt_orchestration_ref", columnList = "orchestration_transaction_id", unique = true),
        @Index(name = "idx_btt_partner_ref", columnList = "partner_reference")
})
public class BankTransferTransaction {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "orchestration_transaction_id", nullable = false, unique = true)
    private UUID orchestrationTransactionId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Rail rail;

    @Column(name = "beneficiary_account_number", nullable = false, length = 34)
    private String beneficiaryAccountNumber;

    @Column(name = "beneficiary_ifsc", nullable = false, length = 11)
    private String beneficiaryIfsc;

    @Column(name = "beneficiary_name", nullable = false)
    private String beneficiaryName;

    @Column(nullable = false, precision = 20, scale = 4)
    private BigDecimal amount;

    @Column(nullable = false, length = 3)
    private String currency;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private BankTransferStatus status;

    // UTR (Unique Transaction Reference) — the definitive proof of an NEFT/RTGS/IMPS
    // transaction, issued by the banking system, required for reconciliation and disputes
    @Column(name = "utr", length = 30)
    private String utr;

    @Column(name = "partner_reference", length = 64)
    private String partnerReference;

    @Column(name = "partner_provider", length = 30)
    private String partnerProvider;

    @Column(name = "failure_reason")
    private String failureReason;

    // Set when a rail failure triggers automatic fallback to a slower-but-more-reliable rail
    @Column(name = "fallback_from_rail", length = 10)
    private String fallbackFromRail;

    @Column(name = "initiated_at", nullable = false)
    private Instant initiatedAt;

    @Column(name = "completed_at")
    private Instant completedAt;

    @Version
    private Long version;

    @PrePersist
    void onCreate() {
        if (initiatedAt == null) initiatedAt = Instant.now();
        if (status == null) status = BankTransferStatus.INITIATED;
    }

    public UUID getId() { return id; }
    public UUID getOrchestrationTransactionId() { return orchestrationTransactionId; }
    public void setOrchestrationTransactionId(UUID orchestrationTransactionId) { this.orchestrationTransactionId = orchestrationTransactionId; }
    public Rail getRail() { return rail; }
    public void setRail(Rail rail) { this.rail = rail; }
    public String getBeneficiaryAccountNumber() { return beneficiaryAccountNumber; }
    public void setBeneficiaryAccountNumber(String beneficiaryAccountNumber) { this.beneficiaryAccountNumber = beneficiaryAccountNumber; }
    public String getBeneficiaryIfsc() { return beneficiaryIfsc; }
    public void setBeneficiaryIfsc(String beneficiaryIfsc) { this.beneficiaryIfsc = beneficiaryIfsc; }
    public String getBeneficiaryName() { return beneficiaryName; }
    public void setBeneficiaryName(String beneficiaryName) { this.beneficiaryName = beneficiaryName; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public BankTransferStatus getStatus() { return status; }
    public void setStatus(BankTransferStatus status) { this.status = status; }
    public String getUtr() { return utr; }
    public void setUtr(String utr) { this.utr = utr; }
    public String getPartnerReference() { return partnerReference; }
    public void setPartnerReference(String partnerReference) { this.partnerReference = partnerReference; }
    public String getPartnerProvider() { return partnerProvider; }
    public void setPartnerProvider(String partnerProvider) { this.partnerProvider = partnerProvider; }
    public String getFailureReason() { return failureReason; }
    public void setFailureReason(String failureReason) { this.failureReason = failureReason; }
    public String getFallbackFromRail() { return fallbackFromRail; }
    public void setFallbackFromRail(String fallbackFromRail) { this.fallbackFromRail = fallbackFromRail; }
    public Instant getInitiatedAt() { return initiatedAt; }
    public Instant getCompletedAt() { return completedAt; }
    public void setCompletedAt(Instant completedAt) { this.completedAt = completedAt; }

    public enum Rail { NEFT, RTGS, IMPS }

    public enum BankTransferStatus {
        INITIATED, SENT_TO_PARTNER, PROCESSING, SUCCESS, FAILED, TIMED_OUT
    }
}
