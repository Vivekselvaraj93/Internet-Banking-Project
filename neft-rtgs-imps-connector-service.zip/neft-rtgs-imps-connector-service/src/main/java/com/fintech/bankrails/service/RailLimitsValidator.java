package com.fintech.bankrails.service;

import com.fintech.bankrails.exception.InvalidRailAmountException;
import com.fintech.bankrails.model.BankTransferTransaction.Rail;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * Encodes each rail's regulatory/practical amount constraints. These figures
 * are set via config (not hardcoded as final constants) because RBI/NPCI
 * revise them periodically via circulars — update the ConfigMap, not the code,
 * when limits change. Values below reflect typical limits as of early 2026
 * and MUST be reverified against current RBI guidance and your specific
 * partner bank's own limits (which are sometimes tighter than the regulatory
 * ceiling) before going live.
 */
@Component
public class RailLimitsValidator {

    private final BigDecimal rtgsMinimum;
    private final BigDecimal impsMaximum;

    public RailLimitsValidator(
            @Value("${bankrails.limits.rtgs-minimum:200000}") BigDecimal rtgsMinimum,
            @Value("${bankrails.limits.imps-maximum:500000}") BigDecimal impsMaximum) {
        this.rtgsMinimum = rtgsMinimum;
        this.impsMaximum = impsMaximum;
    }

    public void validate(Rail rail, BigDecimal amount) {
        switch (rail) {
            case RTGS -> {
                if (amount.compareTo(rtgsMinimum) < 0) {
                    throw new InvalidRailAmountException(
                            "RTGS requires a minimum amount of " + rtgsMinimum + "; got " + amount
                                    + ". Use NEFT or IMPS for smaller amounts.");
                }
                // RTGS has no regulatory maximum
            }
            case IMPS -> {
                if (amount.compareTo(impsMaximum) > 0) {
                    throw new InvalidRailAmountException(
                            "IMPS supports a maximum of " + impsMaximum + " per transaction; got " + amount
                                    + ". Use NEFT or RTGS for larger amounts.");
                }
            }
            case NEFT -> {
                // No regulatory min/max for NEFT
            }
        }
    }
}
