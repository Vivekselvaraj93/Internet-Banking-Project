package com.fintech.bankrails.exception;

public class BankTransferNotFoundException extends RuntimeException {
    public BankTransferNotFoundException(String message) {
        super(message);
    }
}
