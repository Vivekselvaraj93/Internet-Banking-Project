package com.fintech.bankrails.repository;

import com.fintech.bankrails.model.BankTransferTransaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface BankTransferTransactionRepository extends JpaRepository<BankTransferTransaction, UUID> {

    Optional<BankTransferTransaction> findByOrchestrationTransactionId(UUID orchestrationTransactionId);

    Optional<BankTransferTransaction> findByPartnerReference(String partnerReference);

    List<BankTransferTransaction> findByStatusInAndInitiatedAtBefore(
            List<BankTransferTransaction.BankTransferStatus> statuses, Instant cutoff);
}
