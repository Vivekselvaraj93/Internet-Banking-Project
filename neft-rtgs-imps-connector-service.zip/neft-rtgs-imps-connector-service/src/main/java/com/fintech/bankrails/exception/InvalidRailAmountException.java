package com.fintech.bankrails.exception;

public class InvalidRailAmountException extends RuntimeException {
    public InvalidRailAmountException(String message) {
        super(message);
    }
}
