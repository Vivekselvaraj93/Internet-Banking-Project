package com.fintech.bankrails.client;

import com.fintech.bankrails.model.BankTransferTransaction.Rail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;

/**
 * Example implementation wired for a Setu-style API Banking payouts product.
 *
 * IMPORTANT: as with the UPI connector's SetuUpiPartnerClient, field names,
 * endpoint paths, and auth headers below are illustrative placeholders.
 * Verify and adjust against the partner's current API documentation before
 * going live — this is a structural template, not a finished integration.
 */
@Component
public class SetuBankRailsPartnerClient implements BankRailsPartnerClient {

    private static final Logger log = LoggerFactory.getLogger(SetuBankRailsPartnerClient.class);

    private final WebClient webClient;

    public SetuBankRailsPartnerClient(
            WebClient.Builder webClientBuilder,
            @Value("${bankrails.partner.setu.base-url}") String baseUrl,
            @Value("${bankrails.partner.setu.api-key}") String apiKey,
            @Value("${bankrails.partner.setu.account-id}") String accountId) {

        this.webClient = webClientBuilder
                .baseUrl(baseUrl)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader("x-api-key", apiKey)
                .defaultHeader("x-account-id", accountId)
                .build();
    }

    @Override
    public Mono<PartnerInitiationResult> initiateTransfer(
            UUID orchestrationTransactionId,
            Rail rail,
            String beneficiaryAccountNumber,
            String beneficiaryIfsc,
            String beneficiaryName,
            BigDecimal amount,
            String currency,
            String narration) {

        Map<String, Object> body = Map.of(
                "clientReferenceId", orchestrationTransactionId.toString(),
                "mode", rail.name(),   // NEFT | RTGS | IMPS
                "beneficiary", Map.of(
                        "accountNumber", beneficiaryAccountNumber,
                        "ifsc", beneficiaryIfsc,
                        "name", beneficiaryName
                ),
                "amount", amount,
                "currency", currency,
                "narration", narration == null ? "" : narration
        );

        return webClient.post()
                .uri("/payouts")
                .bodyValue(body)
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(15)) // bank rails can be slower to ack than UPI
                .retryWhen(Retry.backoff(2, Duration.ofMillis(750))
                        .filter(this::isRetryable))
                .map(this::mapInitiationResponse)
                .doOnError(ex -> log.error("Partner initiateTransfer failed for txn {} rail {}: {}",
                        orchestrationTransactionId, rail, ex.getMessage()));
    }

    @Override
    public Mono<PartnerStatusResult> checkStatus(String partnerReference) {
        return webClient.get()
                .uri("/payouts/{ref}", partnerReference)
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(10))
                .map(this::mapStatusResponse);
    }

    @SuppressWarnings("unchecked")
    private PartnerInitiationResult mapInitiationResponse(Map<String, Object> response) {
        return new PartnerInitiationResult(
                (String) response.get("id"),
                (String) response.get("status"),
                (String) response.get("utr")
        );
    }

    @SuppressWarnings("unchecked")
    private PartnerStatusResult mapStatusResponse(Map<String, Object> response) {
        return new PartnerStatusResult(
                (String) response.get("status"),
                (String) response.get("utr"),
                (String) response.get("errorReason")
        );
    }

    private boolean isRetryable(Throwable ex) {
        String message = ex.getMessage();
        return message != null && (message.contains("timeout") || message.contains("5"));
    }
}
