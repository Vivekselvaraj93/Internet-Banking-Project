package com.fintech.bankrails.dto;

public class BankTransferWebhookPayload {

    private String partnerReference;
    private String status;
    private String utr;
    private String failureReason;

    public String getPartnerReference() { return partnerReference; }
    public void setPartnerReference(String partnerReference) { this.partnerReference = partnerReference; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getUtr() { return utr; }
    public void setUtr(String utr) { this.utr = utr; }
    public String getFailureReason() { return failureReason; }
    public void setFailureReason(String failureReason) { this.failureReason = failureReason; }
}
