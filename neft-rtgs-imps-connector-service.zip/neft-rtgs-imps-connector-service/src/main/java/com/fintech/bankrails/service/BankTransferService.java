package com.fintech.bankrails.service;

import com.fintech.bankrails.client.BankRailsPartnerClient;
import com.fintech.bankrails.dto.BankTransferRequest;
import com.fintech.bankrails.dto.BankTransferResponse;
import com.fintech.bankrails.dto.BankTransferWebhookPayload;
import com.fintech.bankrails.exception.BankTransferNotFoundException;
import com.fintech.bankrails.model.BankTransferTransaction;
import com.fintech.bankrails.model.BankTransferTransaction.Rail;
import com.fintech.bankrails.repository.BankTransferTransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;

@Service
public class BankTransferService {

    private static final Logger log = LoggerFactory.getLogger(BankTransferService.class);

    private final BankTransferTransactionRepository repository;
    private final BankRailsPartnerClient partnerClient;
    private final RailLimitsValidator railLimitsValidator;

    public BankTransferService(BankTransferTransactionRepository repository,
                                BankRailsPartnerClient partnerClient,
                                RailLimitsValidator railLimitsValidator) {
        this.repository = repository;
        this.partnerClient = partnerClient;
        this.railLimitsValidator = railLimitsValidator;
    }

    /**
     * Initiates a bank transfer over the requested rail. Validates rail
     * amount constraints locally before ever calling the partner (fails
     * fast, no wasted partner API call for an obviously invalid request).
     *
     * Idempotent by orchestrationTransactionId — safe to retry from the
     * Payment Orchestration Service.
     */
    @Transactional
    public BankTransferResponse initiateTransfer(BankTransferRequest request) {
        var existing = repository.findByOrchestrationTransactionId(request.getOrchestrationTransactionId());
        if (existing.isPresent()) {
            log.info("Bank transfer for orchestration txn {} already exists, returning existing state",
                    request.getOrchestrationTransactionId());
            return BankTransferResponse.from(existing.get());
        }

        railLimitsValidator.validate(request.getRail(), request.getAmount());

        BankTransferTransaction txn = buildTransaction(request, request.getRail(), null);
        txn = repository.save(txn);

        txn = attemptPartnerCall(txn, request);

        // Auto-fallback: if IMPS or RTGS failed outright (not just pending)
        // and the caller allows it, retry once via NEFT — slower but far
        // more reliable, and NEFT has no amount ceiling.
        if (txn.getStatus() == BankTransferTransaction.BankTransferStatus.FAILED
                && request.isAllowFallback()
                && request.getRail() != Rail.NEFT) {

            log.warn("Rail {} failed for txn {}, falling back to NEFT",
                    request.getRail(), request.getOrchestrationTransactionId());

            String originalRail = txn.getRail().name();
            txn.setRail(Rail.NEFT);
            txn.setFallbackFromRail(originalRail);
            txn.setStatus(BankTransferTransaction.BankTransferStatus.INITIATED);
            txn.setFailureReason(null);
            txn.setPartnerReference(null);

            txn = attemptPartnerCall(txn, request);
        }

        return BankTransferResponse.from(txn);
    }

    @Transactional(readOnly = true)
    public BankTransferResponse getStatus(UUID orchestrationTransactionId) {
        BankTransferTransaction txn = repository.findByOrchestrationTransactionId(orchestrationTransactionId)
                .orElseThrow(() -> new BankTransferNotFoundException(
                        "No bank transfer found for orchestration txn " + orchestrationTransactionId));
        return BankTransferResponse.from(txn);
    }

    @Transactional
    public void handleWebhook(BankTransferWebhookPayload payload) {
        BankTransferTransaction txn = repository.findByPartnerReference(payload.getPartnerReference())
                .orElseThrow(() -> new BankTransferNotFoundException(
                        "No bank transfer found for partner reference " + payload.getPartnerReference()));

        if (isTerminal(txn.getStatus())) {
            log.info("Webhook received for already-terminal txn {} — ignoring duplicate", txn.getId());
            return;
        }

        txn.setStatus(mapPartnerStatus(payload.getStatus()));
        txn.setUtr(payload.getUtr());
        txn.setFailureReason(payload.getFailureReason());
        if (isTerminal(txn.getStatus())) {
            txn.setCompletedAt(Instant.now());
        }

        repository.save(txn);
        log.info("Updated bank transfer txn {} to status {} via webhook", txn.getId(), txn.getStatus());
    }

    /**
     * Reconciliation backstop, same rationale as the UPI connector: bank
     * partner webhooks can be delayed or missed, especially for NEFT which
     * settles in batches rather than instantly.
     */
    @Transactional
    public void reconcilePendingTransactions() {
        Instant cutoff = Instant.now().minus(5, ChronoUnit.MINUTES);
        List<BankTransferTransaction> stuck = repository.findByStatusInAndInitiatedAtBefore(
                List.of(BankTransferTransaction.BankTransferStatus.SENT_TO_PARTNER,
                        BankTransferTransaction.BankTransferStatus.PROCESSING),
                cutoff
        );

        for (BankTransferTransaction txn : stuck) {
            if (txn.getPartnerReference() == null) continue;
            try {
                BankRailsPartnerClient.PartnerStatusResult result =
                        partnerClient.checkStatus(txn.getPartnerReference()).block();

                BankTransferTransaction.BankTransferStatus newStatus = mapPartnerStatus(result.status());
                if (newStatus != txn.getStatus()) {
                    txn.setStatus(newStatus);
                    txn.setUtr(result.utr());
                    txn.setFailureReason(result.failureReason());
                    if (isTerminal(newStatus)) txn.setCompletedAt(Instant.now());
                    repository.save(txn);
                    log.info("Reconciliation updated bank transfer txn {} to {}", txn.getId(), newStatus);
                }
            } catch (Exception ex) {
                log.warn("Reconciliation status check failed for txn {}: {}", txn.getId(), ex.getMessage());
            }
        }

        // NEFT batches can legitimately take longer, so give a wider hard
        // cutoff than UPI before flagging for manual review.
        Instant hardCutoff = Instant.now().minus(2, ChronoUnit.HOURS);
        List<BankTransferTransaction> timedOut = repository.findByStatusInAndInitiatedAtBefore(
                List.of(BankTransferTransaction.BankTransferStatus.SENT_TO_PARTNER,
                        BankTransferTransaction.BankTransferStatus.PROCESSING),
                hardCutoff
        );
        for (BankTransferTransaction txn : timedOut) {
            txn.setStatus(BankTransferTransaction.BankTransferStatus.TIMED_OUT);
            repository.save(txn);
            log.error("Bank transfer txn {} marked TIMED_OUT after 2 hours unresolved — needs manual review", txn.getId());
        }
    }

    private BankTransferTransaction attemptPartnerCall(BankTransferTransaction txn, BankTransferRequest request) {
        try {
            BankRailsPartnerClient.PartnerInitiationResult result = partnerClient.initiateTransfer(
                    request.getOrchestrationTransactionId(),
                    txn.getRail(),
                    request.getBeneficiaryAccountNumber(),
                    request.getBeneficiaryIfsc(),
                    request.getBeneficiaryName(),
                    request.getAmount(),
                    request.getCurrency(),
                    request.getNarration()
            ).block();

            txn.setPartnerReference(result.partnerReference());
            txn.setUtr(result.utr());
            txn.setStatus(mapPartnerStatus(result.status()));

            if (isTerminal(txn.getStatus())) {
                txn.setCompletedAt(Instant.now());
            }
        } catch (Exception ex) {
            log.error("Failed to initiate {} transfer with partner for txn {}: {}",
                    txn.getRail(), request.getOrchestrationTransactionId(), ex.getMessage());
            txn.setStatus(BankTransferTransaction.BankTransferStatus.FAILED);
            txn.setFailureReason("Partner call failed: " + ex.getMessage());
        }

        return repository.save(txn);
    }

    private BankTransferTransaction buildTransaction(BankTransferRequest request, Rail rail, String fallbackFrom) {
        BankTransferTransaction txn = new BankTransferTransaction();
        txn.setOrchestrationTransactionId(request.getOrchestrationTransactionId());
        txn.setRail(rail);
        txn.setBeneficiaryAccountNumber(request.getBeneficiaryAccountNumber());
        txn.setBeneficiaryIfsc(request.getBeneficiaryIfsc());
        txn.setBeneficiaryName(request.getBeneficiaryName());
        txn.setAmount(request.getAmount());
        txn.setCurrency(request.getCurrency());
        txn.setPartnerProvider("setu");
        txn.setFallbackFromRail(fallbackFrom);
        return txn;
    }

    private boolean isTerminal(BankTransferTransaction.BankTransferStatus status) {
        return status == BankTransferTransaction.BankTransferStatus.SUCCESS
                || status == BankTransferTransaction.BankTransferStatus.FAILED
                || status == BankTransferTransaction.BankTransferStatus.TIMED_OUT;
    }

    private BankTransferTransaction.BankTransferStatus mapPartnerStatus(String partnerStatus) {
        if (partnerStatus == null) return BankTransferTransaction.BankTransferStatus.SENT_TO_PARTNER;
        return switch (partnerStatus.toUpperCase()) {
            case "SUCCESS", "COMPLETED", "CREDITED" -> BankTransferTransaction.BankTransferStatus.SUCCESS;
            case "FAILED", "REJECTED", "REVERSED" -> BankTransferTransaction.BankTransferStatus.FAILED;
            case "PROCESSING", "IN_PROGRESS", "PENDING" -> BankTransferTransaction.BankTransferStatus.PROCESSING;
            default -> BankTransferTransaction.BankTransferStatus.SENT_TO_PARTNER;
        };
    }
}
