package com.fintech.bankrails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * NEFT/RTGS/IMPS Connector Service — integrates with a sponsor bank's API
 * Banking product or a BaaS provider (Setu/Decentro/M2P/Cashfree) to move
 * money over the three core account-to-account bank rails.
 *
 * Unlike UPI, these rails are IFSC + account-number based (not VPA-based),
 * and each rail has distinct amount limits and settlement windows that this
 * service enforces before ever calling the partner, so obviously-invalid
 * requests (e.g. RTGS below the regulatory minimum) fail fast locally.
 */
@SpringBootApplication
@EnableRetry
@EnableScheduling
public class BankRailsConnectorServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(BankRailsConnectorServiceApplication.class, args);
    }
}
