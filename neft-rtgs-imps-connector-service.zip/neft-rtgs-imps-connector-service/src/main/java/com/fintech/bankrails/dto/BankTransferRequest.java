package com.fintech.bankrails.dto;

import com.fintech.bankrails.model.BankTransferTransaction;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.util.UUID;

public class BankTransferRequest {

    @NotNull
    private UUID orchestrationTransactionId;

    @NotNull
    private BankTransferTransaction.Rail rail;

    @NotBlank
    @Pattern(regexp = "^[0-9A-Za-z]{5,34}$", message = "invalid account number format")
    private String beneficiaryAccountNumber;

    @NotBlank
    @Pattern(regexp = "^[A-Z]{4}0[A-Z0-9]{6}$", message = "invalid IFSC code format")
    private String beneficiaryIfsc;

    @NotBlank
    private String beneficiaryName;

    @NotNull
    @DecimalMin(value = "1.00", message = "amount must be positive")
    private BigDecimal amount;

    @NotBlank
    private String currency;

    private String narration;

    /** If true and the requested rail fails, the connector will automatically
     *  retry via NEFT as a fallback (per platform orchestration policy). */
    private boolean allowFallback = true;

    public UUID getOrchestrationTransactionId() { return orchestrationTransactionId; }
    public void setOrchestrationTransactionId(UUID orchestrationTransactionId) { this.orchestrationTransactionId = orchestrationTransactionId; }
    public BankTransferTransaction.Rail getRail() { return rail; }
    public void setRail(BankTransferTransaction.Rail rail) { this.rail = rail; }
    public String getBeneficiaryAccountNumber() { return beneficiaryAccountNumber; }
    public void setBeneficiaryAccountNumber(String beneficiaryAccountNumber) { this.beneficiaryAccountNumber = beneficiaryAccountNumber; }
    public String getBeneficiaryIfsc() { return beneficiaryIfsc; }
    public void setBeneficiaryIfsc(String beneficiaryIfsc) { this.beneficiaryIfsc = beneficiaryIfsc; }
    public String getBeneficiaryName() { return beneficiaryName; }
    public void setBeneficiaryName(String beneficiaryName) { this.beneficiaryName = beneficiaryName; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public String getNarration() { return narration; }
    public void setNarration(String narration) { this.narration = narration; }
    public boolean isAllowFallback() { return allowFallback; }
    public void setAllowFallback(boolean allowFallback) { this.allowFallback = allowFallback; }
}
