package com.fintech.bankrails.controller;

import com.fintech.bankrails.dto.BankTransferRequest;
import com.fintech.bankrails.dto.BankTransferResponse;
import com.fintech.bankrails.service.BankTransferService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/bank-transfers")
public class BankTransferController {

    private final BankTransferService bankTransferService;

    public BankTransferController(BankTransferService bankTransferService) {
        this.bankTransferService = bankTransferService;
    }

    /**
     * Called exclusively by the Payment Orchestration Service, which has
     * already decided which rail (NEFT/RTGS/IMPS) fits the request and
     * reserved the corresponding ledger movement.
     */
    @PostMapping
    public ResponseEntity<BankTransferResponse> initiateTransfer(@Valid @RequestBody BankTransferRequest request) {
        return ResponseEntity.ok(bankTransferService.initiateTransfer(request));
    }

    @GetMapping("/{orchestrationTransactionId}")
    public ResponseEntity<BankTransferResponse> getStatus(@PathVariable UUID orchestrationTransactionId) {
        return ResponseEntity.ok(bankTransferService.getStatus(orchestrationTransactionId));
    }
}
