# NEFT / RTGS / IMPS Connector Service

Integrates with a sponsor bank's API Banking product or a BaaS partner
(Setu, Decentro, M2P, Cashfree Payouts) to move money over India's three
core account-to-account bank rails.

## Key design points

- **Local rail validation before any partner call** (`RailLimitsValidator`):
  RTGS minimum, IMPS maximum are enforced immediately — an invalid request
  fails fast without wasting a partner API call. Limits are configurable
  (not hardcoded), since RBI revises them via periodic circulars.
- **Automatic fallback to NEFT**: if IMPS or RTGS fails outright, the
  service automatically retries once via NEFT (slower, batched, but far more
  reliable and with no amount ceiling) when the caller allows it
  (`allowFallback: true`, the default). The original rail and fallback
  lineage are recorded on the transaction for audit purposes.
- **Idempotent by `orchestrationTransactionId`** — safe for the Payment
  Orchestration Service to retry.
- **UTR tracked explicitly** — the definitive reference for NEFT/RTGS/IMPS
  reconciliation and disputes.
- **Webhook + polling reconciliation**: NEFT settles in batches, so the
  reconciliation window is wider (2 min soft check, 2 hour hard timeout)
  than the UPI connector's.
- **HMAC-signed webhook verification** (constant-time comparison).

## API

| Method | Path | Purpose |
|---|---|---|
| POST | `/bank-transfers` | Initiate an NEFT/RTGS/IMPS transfer |
| GET | `/bank-transfers/{orchestrationTransactionId}` | Check status |
| POST | `/bank-transfers/webhooks/setu` | Partner webhook receiver (HMAC-verified) |

### Example: initiate an IMPS transfer

```bash
curl -X POST http://neft-rtgs-imps-connector-service:8080/bank-transfers \
  -H "Content-Type: application/json" \
  -d '{
    "orchestrationTransactionId": "44444444-4444-4444-4444-444444444444",
    "rail": "IMPS",
    "beneficiaryAccountNumber": "123456789012",
    "beneficiaryIfsc": "HDFC0000123",
    "beneficiaryName": "Jane Doe",
    "amount": 25000.00,
    "currency": "INR",
    "narration": "Rent payment",
    "allowFallback": true
  }'
```

If IMPS fails and `allowFallback` is true, the response will show
`"rail": "NEFT"` with `"fallbackFromRail": "IMPS"`.

## Important: partner API details are illustrative

As with the UPI connector, `SetuBankRailsPartnerClient` uses placeholder
field names and endpoints based on typical BaaS conventions. **Verify every
field against your chosen partner's current API documentation before going
live.**

## Also verify before production

- RTGS minimum (₹2,00,000 default here) and IMPS maximum (₹5,00,000 default
  here) against current RBI circulars and your specific partner/sponsor
  bank's own limits, which are sometimes tighter than the regulatory ceiling.

## Build & Deploy

```bash
export PROJECT_ID=$(gcloud config get-value project)
export REGION=us-central1

docker build -t ${REGION}-docker.pkg.dev/${PROJECT_ID}/fintech-images/neft-rtgs-imps-connector-service:1.0.0 .
gcloud auth configure-docker ${REGION}-docker.pkg.dev
docker push ${REGION}-docker.pkg.dev/${PROJECT_ID}/fintech-images/neft-rtgs-imps-connector-service:1.0.0
```

```bash
kubectl apply -f k8s/01-config-and-secret.yaml
kubectl apply -f k8s/02-deployment-service-hpa.yaml
```
