package com.fintech.insurance.repository;

import com.fintech.insurance.model.PremiumSchedule;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

public interface PremiumScheduleRepository extends JpaRepository<PremiumSchedule, UUID> {

    /** Used by the scheduled job that triggers due-today premium collections. */
    List<PremiumSchedule> findByStatusAndNextDueDateLessThanEqual(
            PremiumSchedule.ScheduleStatus status, LocalDate date);

    List<PremiumSchedule> findByPolicyHolderUserId(UUID policyHolderUserId);
}
