package com.fintech.insurance.client;

import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * This service does not talk to UPI/NEFT/IMPS directly — insurance premium
 * collection is just a payment use-case layered on top of the platform's
 * existing rail infrastructure. Actual money movement (choosing a rail,
 * calling the UPI or bank rail connector, posting the ledger transfer) is
 * delegated to the Payment Orchestration Service.
 */
public interface PaymentOrchestrationClient {

    Mono<OrchestrationResult> collectPayment(
            UUID orchestrationTransactionId,
            UUID payerUserId,
            BigDecimal amount,
            String currency,
            String narration
    );

    Mono<OrchestrationResult> disbursePayment(
            UUID orchestrationTransactionId,
            UUID payeeUserId,
            BigDecimal amount,
            String currency,
            String narration
    );

    record OrchestrationResult(
            String status,       // e.g. "SUCCESS", "PENDING", "FAILED"
            String rail,         // which rail was actually used
            String settlementReference
    ) {}
}
