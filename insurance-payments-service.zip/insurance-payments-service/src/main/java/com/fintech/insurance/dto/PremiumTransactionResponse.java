package com.fintech.insurance.dto;

import com.fintech.insurance.model.InsurancePremiumTransaction;

import java.time.Instant;
import java.util.UUID;

public record PremiumTransactionResponse(
        UUID orchestrationTransactionId,
        String policyNumber,
        String insurerCode,
        InsurancePremiumTransaction.TransactionType transactionType,
        InsurancePremiumTransaction.PremiumStatus status,
        String settlementRail,
        String settlementReference,
        String insurerReference,
        String failureReason,
        Instant initiatedAt,
        Instant completedAt
) {
    public static PremiumTransactionResponse from(InsurancePremiumTransaction txn) {
        return new PremiumTransactionResponse(
                txn.getOrchestrationTransactionId(), txn.getPolicyNumber(), txn.getInsurerCode(),
                txn.getTransactionType(), txn.getStatus(), txn.getSettlementRail(),
                txn.getSettlementReference(), txn.getInsurerReference(), txn.getFailureReason(),
                txn.getInitiatedAt(), txn.getCompletedAt()
        );
    }
}
