package com.fintech.insurance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Insurance Payments Service — collects insurance premiums (one-time and
 * recurring) on behalf of insurers/insurtechs and processes premium refunds
 * (e.g. free-look cancellation, policy surrender).
 *
 * Scope note: this service handles PAYMENT COLLECTION only — it does not
 * distribute or sell insurance products. Distributing insurance (advising
 * on policies, comparing products, earning commission on sales) requires an
 * IRDAI Web Aggregator or Corporate Agent license, which is a separate
 * regulatory track from what this service implements. This service is the
 * equivalent of "how do we charge the customer and send the money to the
 * insurer", nothing more.
 *
 * Underlying rails: this service does not talk to UPI/NEFT/etc. directly —
 * it delegates actual money movement to the existing rail connectors (UPI,
 * NEFT/RTGS/IMPS) via the Payment Orchestration Service, and focuses on
 * insurance-domain concerns: policy reference tracking, premium schedules,
 * insurer settlement reconciliation, and refund/cancellation workflows.
 */
@SpringBootApplication
@EnableRetry
@EnableScheduling
public class InsurancePaymentsServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(InsurancePaymentsServiceApplication.class, args);
    }
}
