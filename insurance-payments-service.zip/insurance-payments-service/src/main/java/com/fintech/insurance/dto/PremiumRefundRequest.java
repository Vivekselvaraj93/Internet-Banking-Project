package com.fintech.insurance.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;
import java.util.UUID;

public class PremiumRefundRequest {

    @NotNull
    private UUID orchestrationTransactionId;

    // The original premium collection this refund relates to (e.g. free-look
    // cancellation refund, policy surrender)
    @NotNull
    private UUID originalCollectionOrchestrationTransactionId;

    @NotNull
    @DecimalMin(value = "0.01")
    private BigDecimal amount;

    @NotBlank
    private String currency;

    @NotBlank
    private String reason;

    public UUID getOrchestrationTransactionId() { return orchestrationTransactionId; }
    public void setOrchestrationTransactionId(UUID orchestrationTransactionId) { this.orchestrationTransactionId = orchestrationTransactionId; }
    public UUID getOriginalCollectionOrchestrationTransactionId() { return originalCollectionOrchestrationTransactionId; }
    public void setOriginalCollectionOrchestrationTransactionId(UUID originalCollectionOrchestrationTransactionId) { this.originalCollectionOrchestrationTransactionId = originalCollectionOrchestrationTransactionId; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
}
