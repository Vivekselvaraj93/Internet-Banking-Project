package com.fintech.insurance.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.Map;

/**
 * Illustrative generic implementation — in practice, each insurer/insurtech
 * partner (Digit, Acko, HDFC Ergo, etc.) has its own API contract, so a real
 * platform typically has one implementation per insurer, selected by
 * insurerCode, or a shared adapter layer if working through an insurance
 * BaaS aggregator. This class shows the structural shape only.
 */
@Component
public class GenericInsurerNotificationClient implements InsurerNotificationClient {

    private static final Logger log = LoggerFactory.getLogger(GenericInsurerNotificationClient.class);

    private final WebClient webClient;

    public GenericInsurerNotificationClient(
            WebClient.Builder webClientBuilder,
            @Value("${insurance.insurer-api.base-url}") String baseUrl,
            @Value("${insurance.insurer-api.api-key}") String apiKey) {
        this.webClient = webClientBuilder
                .baseUrl(baseUrl)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader("Authorization", "Bearer " + apiKey)
                .build();
    }

    @Override
    public Mono<InsurerNotificationResult> notifyPremiumReceived(
            String insurerCode, String policyNumber, BigDecimal amount, String currency,
            String internalTransactionReference) {

        Map<String, Object> body = Map.of(
                "policyNumber", policyNumber,
                "amount", amount,
                "currency", currency,
                "reference", internalTransactionReference
        );

        return webClient.post()
                .uri("/insurers/{insurerCode}/premium-notifications", insurerCode)
                .bodyValue(body)
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(10))
                .map(this::mapResult)
                .onErrorResume(ex -> {
                    // A failure here should NOT roll back the premium collection —
                    // the customer's money has already moved. Instead, mark as
                    // pending confirmation and retry via reconciliation.
                    log.warn("Insurer notification failed for policy {}: {} — will retry via reconciliation",
                            policyNumber, ex.getMessage());
                    return Mono.just(new InsurerNotificationResult(false, null));
                });
    }

    @Override
    public Mono<InsurerNotificationResult> notifyRefundIssued(
            String insurerCode, String policyNumber, BigDecimal amount, String currency,
            String reason, String internalTransactionReference) {

        Map<String, Object> body = Map.of(
                "policyNumber", policyNumber,
                "amount", amount,
                "currency", currency,
                "reason", reason,
                "reference", internalTransactionReference
        );

        return webClient.post()
                .uri("/insurers/{insurerCode}/refund-notifications", insurerCode)
                .bodyValue(body)
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(10))
                .map(this::mapResult)
                .onErrorResume(ex -> {
                    log.warn("Insurer refund notification failed for policy {}: {}", policyNumber, ex.getMessage());
                    return Mono.just(new InsurerNotificationResult(false, null));
                });
    }

    @SuppressWarnings("unchecked")
    private InsurerNotificationResult mapResult(Map<String, Object> response) {
        return new InsurerNotificationResult(
                Boolean.TRUE.equals(response.get("acknowledged")),
                (String) response.get("insurerReference")
        );
    }
}
