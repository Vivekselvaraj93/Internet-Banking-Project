package com.fintech.insurance.config;

import com.fintech.insurance.service.PremiumCollectionService;
import com.fintech.insurance.service.PremiumScheduleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class InsuranceScheduledJobs {

    private static final Logger log = LoggerFactory.getLogger(InsuranceScheduledJobs.class);

    private final PremiumScheduleService scheduleService;
    private final PremiumCollectionService collectionService;

    public InsuranceScheduledJobs(PremiumScheduleService scheduleService,
                                   PremiumCollectionService collectionService) {
        this.scheduleService = scheduleService;
        this.collectionService = collectionService;
    }

    /**
     * Runs once daily at 6 AM IST-equivalent UTC offset — adjust cron for
     * your actual deployment timezone. Collects any recurring premium
     * installment whose due date has arrived.
     */
    @Scheduled(cron = "${insurance.scheduler.due-premiums-cron:0 0 0 * * *}")
    public void collectDuePremiums() {
        try {
            scheduleService.collectDuePremiums();
        } catch (Exception ex) {
            log.error("Due-premium collection job failed: {}", ex.getMessage(), ex);
        }
    }

    /** Runs every 15 minutes — retries insurer notifications that haven't been acknowledged yet. */
    @Scheduled(fixedDelay = 900_000)
    public void reconcileInsurerConfirmations() {
        try {
            collectionService.reconcilePendingInsurerConfirmations();
        } catch (Exception ex) {
            log.error("Insurer confirmation reconciliation job failed: {}", ex.getMessage(), ex);
        }
    }
}
