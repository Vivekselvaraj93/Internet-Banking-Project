package com.fintech.insurance.client;

import reactor.core.publisher.Mono;

import java.math.BigDecimal;

/**
 * Notifies the insurer's system of a confirmed premium collection or refund,
 * so the insurer can update its own policy ledger (e.g. mark the policy as
 * "premium paid, coverage active" or record a refund against the policy).
 * Each insurer/insurtech typically exposes its own API for this — this
 * interface abstracts that so a new insurer partner can be onboarded by
 * implementing it again.
 */
public interface InsurerNotificationClient {

    Mono<InsurerNotificationResult> notifyPremiumReceived(
            String insurerCode,
            String policyNumber,
            BigDecimal amount,
            String currency,
            String internalTransactionReference
    );

    Mono<InsurerNotificationResult> notifyRefundIssued(
            String insurerCode,
            String policyNumber,
            BigDecimal amount,
            String currency,
            String reason,
            String internalTransactionReference
    );

    record InsurerNotificationResult(
            boolean acknowledged,
            String insurerReference
    ) {}
}
