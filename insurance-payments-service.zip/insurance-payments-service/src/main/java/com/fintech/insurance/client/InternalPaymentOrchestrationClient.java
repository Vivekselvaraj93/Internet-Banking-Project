package com.fintech.insurance.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;

/**
 * Calls the internal Payment Orchestration Service over the cluster network
 * (K8s DNS: payment-orchestration-service.fintech.svc.cluster.local) — this
 * is an internal service-to-service call, not a third-party BaaS
 * integration like the other client implementations in this platform.
 */
@Component
public class InternalPaymentOrchestrationClient implements PaymentOrchestrationClient {

    private final WebClient webClient;

    public InternalPaymentOrchestrationClient(
            WebClient.Builder webClientBuilder,
            @Value("${insurance.orchestration.base-url}") String baseUrl) {
        this.webClient = webClientBuilder
                .baseUrl(baseUrl)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .build();
    }

    @Override
    public Mono<OrchestrationResult> collectPayment(
            UUID orchestrationTransactionId, UUID payerUserId, BigDecimal amount, String currency, String narration) {

        Map<String, Object> body = Map.of(
                "transactionId", orchestrationTransactionId.toString(),
                "direction", "COLLECT",
                "counterpartyUserId", payerUserId.toString(),
                "amount", amount,
                "currency", currency,
                "narration", narration
        );

        return webClient.post()
                .uri("/payments")
                .bodyValue(body)
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(15))
                .map(this::mapResult);
    }

    @Override
    public Mono<OrchestrationResult> disbursePayment(
            UUID orchestrationTransactionId, UUID payeeUserId, BigDecimal amount, String currency, String narration) {

        Map<String, Object> body = Map.of(
                "transactionId", orchestrationTransactionId.toString(),
                "direction", "PAYOUT",
                "counterpartyUserId", payeeUserId.toString(),
                "amount", amount,
                "currency", currency,
                "narration", narration
        );

        return webClient.post()
                .uri("/payments")
                .bodyValue(body)
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(15))
                .map(this::mapResult);
    }

    @SuppressWarnings("unchecked")
    private OrchestrationResult mapResult(Map<String, Object> response) {
        return new OrchestrationResult(
                (String) response.get("status"),
                (String) response.get("rail"),
                (String) response.get("settlementReference")
        );
    }
}
