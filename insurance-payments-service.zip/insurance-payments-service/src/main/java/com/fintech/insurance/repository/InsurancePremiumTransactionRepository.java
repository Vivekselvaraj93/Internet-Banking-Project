package com.fintech.insurance.repository;

import com.fintech.insurance.model.InsurancePremiumTransaction;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface InsurancePremiumTransactionRepository extends JpaRepository<InsurancePremiumTransaction, UUID> {

    Optional<InsurancePremiumTransaction> findByOrchestrationTransactionId(UUID orchestrationTransactionId);

    Page<InsurancePremiumTransaction> findByPolicyNumberOrderByInitiatedAtDesc(String policyNumber, Pageable pageable);

    List<InsurancePremiumTransaction> findByPremiumScheduleIdOrderByInstallmentNumberAsc(UUID premiumScheduleId);

    List<InsurancePremiumTransaction> findByStatusInAndInitiatedAtBefore(
            List<InsurancePremiumTransaction.PremiumStatus> statuses, Instant cutoff);
}
