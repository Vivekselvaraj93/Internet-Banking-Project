package com.fintech.insurance.controller;

import com.fintech.insurance.dto.CreateScheduleRequest;
import com.fintech.insurance.dto.ScheduleResponse;
import com.fintech.insurance.service.PremiumScheduleService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/insurance/schedules")
public class PremiumScheduleController {

    private final PremiumScheduleService scheduleService;

    public PremiumScheduleController(PremiumScheduleService scheduleService) {
        this.scheduleService = scheduleService;
    }

    @PostMapping
    public ResponseEntity<ScheduleResponse> createSchedule(@Valid @RequestBody CreateScheduleRequest request) {
        return ResponseEntity.ok(scheduleService.createSchedule(request));
    }

    @GetMapping("/{scheduleId}")
    public ResponseEntity<ScheduleResponse> getSchedule(@PathVariable UUID scheduleId) {
        return ResponseEntity.ok(scheduleService.getScheduleStatus(scheduleId));
    }

    @PostMapping("/{scheduleId}/pause")
    public ResponseEntity<ScheduleResponse> pauseSchedule(@PathVariable UUID scheduleId) {
        return ResponseEntity.ok(scheduleService.pauseSchedule(scheduleId));
    }

    @PostMapping("/{scheduleId}/cancel")
    public ResponseEntity<ScheduleResponse> cancelSchedule(@PathVariable UUID scheduleId) {
        return ResponseEntity.ok(scheduleService.cancelSchedule(scheduleId));
    }
}
