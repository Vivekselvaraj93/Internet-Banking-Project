package com.fintech.insurance.exception;

public class PremiumTransactionNotFoundException extends RuntimeException {
    public PremiumTransactionNotFoundException(String message) {
        super(message);
    }
}
