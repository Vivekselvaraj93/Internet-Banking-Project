package com.fintech.insurance.dto;

import com.fintech.insurance.model.PremiumSchedule;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

public record ScheduleResponse(
        UUID scheduleId,
        String policyNumber,
        String insurerCode,
        BigDecimal installmentAmount,
        String currency,
        PremiumSchedule.Frequency frequency,
        LocalDate nextDueDate,
        PremiumSchedule.ScheduleStatus status
) {
    public static ScheduleResponse from(PremiumSchedule schedule) {
        return new ScheduleResponse(
                schedule.getId(), schedule.getPolicyNumber(), schedule.getInsurerCode(),
                schedule.getInstallmentAmount(), schedule.getCurrency(), schedule.getFrequency(),
                schedule.getNextDueDate(), schedule.getStatus()
        );
    }
}
