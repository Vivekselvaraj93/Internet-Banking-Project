package com.fintech.insurance.service;

import com.fintech.insurance.client.InsurerNotificationClient;
import com.fintech.insurance.client.PaymentOrchestrationClient;
import com.fintech.insurance.dto.PremiumCollectionRequest;
import com.fintech.insurance.dto.PremiumRefundRequest;
import com.fintech.insurance.dto.PremiumTransactionResponse;
import com.fintech.insurance.exception.InvalidRefundException;
import com.fintech.insurance.exception.PremiumTransactionNotFoundException;
import com.fintech.insurance.model.InsurancePremiumTransaction;
import com.fintech.insurance.model.InsurancePremiumTransaction.PremiumStatus;
import com.fintech.insurance.model.InsurancePremiumTransaction.TransactionType;
import com.fintech.insurance.repository.InsurancePremiumTransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;

@Service
public class PremiumCollectionService {

    private static final Logger log = LoggerFactory.getLogger(PremiumCollectionService.class);

    private final InsurancePremiumTransactionRepository repository;
    private final PaymentOrchestrationClient orchestrationClient;
    private final InsurerNotificationClient insurerClient;

    public PremiumCollectionService(InsurancePremiumTransactionRepository repository,
                                     PaymentOrchestrationClient orchestrationClient,
                                     InsurerNotificationClient insurerClient) {
        this.repository = repository;
        this.orchestrationClient = orchestrationClient;
        this.insurerClient = insurerClient;
    }

    /**
     * Collects a premium: delegates actual money movement to the Payment
     * Orchestration Service (which picks UPI/NEFT/IMPS as appropriate), then
     * notifies the insurer of receipt. Idempotent by orchestrationTransactionId.
     *
     * Important: an insurer-notification failure does NOT roll back the
     * premium collection. The customer's money has already moved and the
     * ledger already reflects it — failing to tell the insurer is a
     * separate, recoverable problem handled by reconciliation, not a reason
     * to (incorrectly) report the payment itself as failed.
     */
    @Transactional
    public PremiumTransactionResponse collectPremium(PremiumCollectionRequest request) {
        var existing = repository.findByOrchestrationTransactionId(request.getOrchestrationTransactionId());
        if (existing.isPresent()) {
            log.info("Premium collection for orchestration txn {} already exists, returning existing state",
                    request.getOrchestrationTransactionId());
            return PremiumTransactionResponse.from(existing.get());
        }

        InsurancePremiumTransaction txn = new InsurancePremiumTransaction();
        txn.setOrchestrationTransactionId(request.getOrchestrationTransactionId());
        txn.setPolicyHolderUserId(request.getPolicyHolderUserId());
        txn.setPolicyNumber(request.getPolicyNumber());
        txn.setInsurerCode(request.getInsurerCode());
        txn.setAmount(request.getAmount());
        txn.setCurrency(request.getCurrency());
        txn.setTransactionType(TransactionType.PREMIUM_COLLECTION);
        txn.setPremiumType(request.getPremiumScheduleId() != null
                ? InsurancePremiumTransaction.PremiumType.RECURRING
                : InsurancePremiumTransaction.PremiumType.ONE_TIME);
        txn.setPremiumScheduleId(request.getPremiumScheduleId());
        txn.setInstallmentNumber(request.getInstallmentNumber());
        txn.setStatus(PremiumStatus.PROCESSING);
        txn = repository.save(txn);

        try {
            PaymentOrchestrationClient.OrchestrationResult result = orchestrationClient.collectPayment(
                    request.getOrchestrationTransactionId(),
                    request.getPolicyHolderUserId(),
                    request.getAmount(),
                    request.getCurrency(),
                    "Premium payment - policy " + request.getPolicyNumber()
            ).block();

            txn.setSettlementRail(result.rail());
            txn.setSettlementReference(result.settlementReference());

            if (!"SUCCESS".equalsIgnoreCase(result.status())) {
                txn.setStatus(PremiumStatus.FAILED);
                txn.setFailureReason("Payment collection did not succeed: " + result.status());
                txn.setCompletedAt(Instant.now());
                return PremiumTransactionResponse.from(repository.save(txn));
            }
        } catch (Exception ex) {
            log.error("Payment collection failed for premium txn {}: {}",
                    request.getOrchestrationTransactionId(), ex.getMessage());
            txn.setStatus(PremiumStatus.FAILED);
            txn.setFailureReason("Payment collection call failed: " + ex.getMessage());
            txn.setCompletedAt(Instant.now());
            return PremiumTransactionResponse.from(repository.save(txn));
        }

        // Money has moved successfully — now notify the insurer. This step's
        // failure does not undo the payment; see class-level Javadoc.
        txn.setStatus(PremiumStatus.INSURER_CONFIRMATION_PENDING);
        txn = repository.save(txn);

        try {
            InsurerNotificationClient.InsurerNotificationResult notifyResult = insurerClient.notifyPremiumReceived(
                    request.getInsurerCode(), request.getPolicyNumber(),
                    request.getAmount(), request.getCurrency(),
                    request.getOrchestrationTransactionId().toString()
            ).block();

            if (notifyResult.acknowledged()) {
                txn.setInsurerReference(notifyResult.insurerReference());
                txn.setStatus(PremiumStatus.SUCCESS);
                txn.setCompletedAt(Instant.now());
            }
            // else: stays INSURER_CONFIRMATION_PENDING, picked up by reconciliation
        } catch (Exception ex) {
            log.warn("Insurer notification threw for premium txn {}: {} — will retry via reconciliation",
                    request.getOrchestrationTransactionId(), ex.getMessage());
        }

        return PremiumTransactionResponse.from(repository.save(txn));
    }

    /**
     * Issues a premium refund (free-look cancellation, policy surrender,
     * overpayment correction). Delegates the actual payout to the Payment
     * Orchestration Service.
     */
    @Transactional
    public PremiumTransactionResponse refundPremium(PremiumRefundRequest request) {
        var existing = repository.findByOrchestrationTransactionId(request.getOrchestrationTransactionId());
        if (existing.isPresent()) {
            return PremiumTransactionResponse.from(existing.get());
        }

        InsurancePremiumTransaction originalTxn = repository
                .findByOrchestrationTransactionId(request.getOriginalCollectionOrchestrationTransactionId())
                .orElseThrow(() -> new InvalidRefundException(
                        "Original premium collection not found: "
                                + request.getOriginalCollectionOrchestrationTransactionId()));

        if (originalTxn.getStatus() != PremiumStatus.SUCCESS) {
            throw new InvalidRefundException(
                    "Cannot refund a premium collection that was not successful (status: "
                            + originalTxn.getStatus() + ")");
        }

        if (request.getAmount().compareTo(originalTxn.getAmount()) > 0) {
            throw new InvalidRefundException("Refund amount cannot exceed the original premium amount");
        }

        InsurancePremiumTransaction refundTxn = new InsurancePremiumTransaction();
        refundTxn.setOrchestrationTransactionId(request.getOrchestrationTransactionId());
        refundTxn.setPolicyHolderUserId(originalTxn.getPolicyHolderUserId());
        refundTxn.setPolicyNumber(originalTxn.getPolicyNumber());
        refundTxn.setInsurerCode(originalTxn.getInsurerCode());
        refundTxn.setAmount(request.getAmount());
        refundTxn.setCurrency(request.getCurrency());
        refundTxn.setTransactionType(TransactionType.REFUND);
        refundTxn.setPremiumType(originalTxn.getPremiumType());
        refundTxn.setStatus(PremiumStatus.PROCESSING);
        refundTxn = repository.save(refundTxn);

        try {
            PaymentOrchestrationClient.OrchestrationResult result = orchestrationClient.disbursePayment(
                    request.getOrchestrationTransactionId(),
                    originalTxn.getPolicyHolderUserId(),
                    request.getAmount(),
                    request.getCurrency(),
                    "Premium refund - policy " + originalTxn.getPolicyNumber() + " - " + request.getReason()
            ).block();

            refundTxn.setSettlementRail(result.rail());
            refundTxn.setSettlementReference(result.settlementReference());

            refundTxn.setStatus("SUCCESS".equalsIgnoreCase(result.status())
                    ? PremiumStatus.SUCCESS : PremiumStatus.FAILED);
            refundTxn.setCompletedAt(Instant.now());

        } catch (Exception ex) {
            log.error("Refund disbursement failed for txn {}: {}",
                    request.getOrchestrationTransactionId(), ex.getMessage());
            refundTxn.setStatus(PremiumStatus.FAILED);
            refundTxn.setFailureReason("Refund disbursement call failed: " + ex.getMessage());
            refundTxn.setCompletedAt(Instant.now());
        }

        refundTxn = repository.save(refundTxn);

        if (refundTxn.getStatus() == PremiumStatus.SUCCESS) {
            try {
                insurerClient.notifyRefundIssued(
                        originalTxn.getInsurerCode(), originalTxn.getPolicyNumber(),
                        request.getAmount(), request.getCurrency(), request.getReason(),
                        request.getOrchestrationTransactionId().toString()
                ).block();
            } catch (Exception ex) {
                log.warn("Insurer refund notification failed for txn {}: {}", refundTxn.getId(), ex.getMessage());
            }
        }

        return PremiumTransactionResponse.from(refundTxn);
    }

    @Transactional(readOnly = true)
    public PremiumTransactionResponse getStatus(UUID orchestrationTransactionId) {
        InsurancePremiumTransaction txn = repository.findByOrchestrationTransactionId(orchestrationTransactionId)
                .orElseThrow(() -> new PremiumTransactionNotFoundException(
                        "No premium transaction found for orchestration txn " + orchestrationTransactionId));
        return PremiumTransactionResponse.from(txn);
    }

    /**
     * Retries insurer notification for transactions where the payment
     * succeeded but the insurer never acknowledged receipt — the money
     * moving correctly must never depend on the insurer's API being up.
     */
    @Transactional
    public void reconcilePendingInsurerConfirmations() {
        Instant cutoff = Instant.now().minus(15, ChronoUnit.MINUTES);
        List<InsurancePremiumTransaction> pending = repository.findByStatusInAndInitiatedAtBefore(
                List.of(PremiumStatus.INSURER_CONFIRMATION_PENDING), cutoff);

        for (InsurancePremiumTransaction txn : pending) {
            try {
                InsurerNotificationClient.InsurerNotificationResult result = insurerClient.notifyPremiumReceived(
                        txn.getInsurerCode(), txn.getPolicyNumber(), txn.getAmount(), txn.getCurrency(),
                        txn.getOrchestrationTransactionId().toString()
                ).block();

                if (result.acknowledged()) {
                    txn.setInsurerReference(result.insurerReference());
                    txn.setStatus(PremiumStatus.SUCCESS);
                    txn.setCompletedAt(Instant.now());
                    repository.save(txn);
                    log.info("Reconciliation confirmed insurer receipt for txn {}", txn.getId());
                }
            } catch (Exception ex) {
                log.warn("Reconciliation retry of insurer notification failed for txn {}: {}",
                        txn.getId(), ex.getMessage());
            }
        }

        // Payment succeeded but insurer never confirmed after 24h — flag for
        // manual ops/insurer-relations follow-up. The customer's payment is
        // NOT at risk (it already succeeded); this is a back-office reconciliation gap.
        Instant hardCutoff = Instant.now().minus(24, ChronoUnit.HOURS);
        List<InsurancePremiumTransaction> stale = repository.findByStatusInAndInitiatedAtBefore(
                List.of(PremiumStatus.INSURER_CONFIRMATION_PENDING), hardCutoff);
        for (InsurancePremiumTransaction txn : stale) {
            txn.setStatus(PremiumStatus.TIMED_OUT);
            repository.save(txn);
            log.error("Premium txn {} insurer confirmation TIMED_OUT after 24h — payment succeeded, " +
                    "needs manual insurer reconciliation", txn.getId());
        }
    }
}
