package com.fintech.insurance.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "insurance_premium_transactions", indexes = {
        @Index(name = "idx_ipt_orchestration_ref", columnList = "orchestration_transaction_id", unique = true),
        @Index(name = "idx_ipt_policy_number", columnList = "policy_number"),
        @Index(name = "idx_ipt_insurer", columnList = "insurer_code")
})
public class InsurancePremiumTransaction {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "orchestration_transaction_id", nullable = false, unique = true)
    private UUID orchestrationTransactionId;

    @Column(name = "policy_holder_user_id", nullable = false)
    private UUID policyHolderUserId;

    @Column(name = "policy_number", nullable = false, length = 64)
    private String policyNumber;

    // Insurer identifier — e.g. "DIGIT", "ACKO", "HDFCERGO" — used to route
    // settlement to the correct insurer and for reconciliation reporting
    @Column(name = "insurer_code", nullable = false, length = 30)
    private String insurerCode;

    @Enumerated(EnumType.STRING)
    @Column(name = "premium_type", nullable = false, length = 20)
    private PremiumType premiumType;

    @Enumerated(EnumType.STRING)
    @Column(name = "transaction_type", nullable = false, length = 20)
    private TransactionType transactionType; // PREMIUM_COLLECTION or REFUND

    @Column(nullable = false, precision = 20, scale = 4)
    private BigDecimal amount;

    @Column(nullable = false, length = 3)
    private String currency;

    // For recurring premiums, links installments to the same schedule
    @Column(name = "premium_schedule_id")
    private UUID premiumScheduleId;

    @Column(name = "installment_number")
    private Integer installmentNumber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private PremiumStatus status;

    // The rail (UPI/NEFT/IMPS) actually used to move the money — the
    // Payment Orchestration Service picks this; this service just records it
    @Column(name = "settlement_rail", length = 10)
    private String settlementRail;

    @Column(name = "settlement_reference", length = 64)
    private String settlementReference; // UTR / NPCI RRN from the underlying rail

    // Reference from the insurer's own system confirming premium receipt —
    // required for insurer-side reconciliation
    @Column(name = "insurer_reference", length = 64)
    private String insurerReference;

    @Column(name = "failure_reason")
    private String failureReason;

    @Column(name = "initiated_at", nullable = false)
    private Instant initiatedAt;

    @Column(name = "completed_at")
    private Instant completedAt;

    @Version
    private Long version;

    @PrePersist
    void onCreate() {
        if (initiatedAt == null) initiatedAt = Instant.now();
        if (status == null) status = PremiumStatus.INITIATED;
    }

    public UUID getId() { return id; }
    public UUID getOrchestrationTransactionId() { return orchestrationTransactionId; }
    public void setOrchestrationTransactionId(UUID orchestrationTransactionId) { this.orchestrationTransactionId = orchestrationTransactionId; }
    public UUID getPolicyHolderUserId() { return policyHolderUserId; }
    public void setPolicyHolderUserId(UUID policyHolderUserId) { this.policyHolderUserId = policyHolderUserId; }
    public String getPolicyNumber() { return policyNumber; }
    public void setPolicyNumber(String policyNumber) { this.policyNumber = policyNumber; }
    public String getInsurerCode() { return insurerCode; }
    public void setInsurerCode(String insurerCode) { this.insurerCode = insurerCode; }
    public PremiumType getPremiumType() { return premiumType; }
    public void setPremiumType(PremiumType premiumType) { this.premiumType = premiumType; }
    public TransactionType getTransactionType() { return transactionType; }
    public void setTransactionType(TransactionType transactionType) { this.transactionType = transactionType; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public UUID getPremiumScheduleId() { return premiumScheduleId; }
    public void setPremiumScheduleId(UUID premiumScheduleId) { this.premiumScheduleId = premiumScheduleId; }
    public Integer getInstallmentNumber() { return installmentNumber; }
    public void setInstallmentNumber(Integer installmentNumber) { this.installmentNumber = installmentNumber; }
    public PremiumStatus getStatus() { return status; }
    public void setStatus(PremiumStatus status) { this.status = status; }
    public String getSettlementRail() { return settlementRail; }
    public void setSettlementRail(String settlementRail) { this.settlementRail = settlementRail; }
    public String getSettlementReference() { return settlementReference; }
    public void setSettlementReference(String settlementReference) { this.settlementReference = settlementReference; }
    public String getInsurerReference() { return insurerReference; }
    public void setInsurerReference(String insurerReference) { this.insurerReference = insurerReference; }
    public String getFailureReason() { return failureReason; }
    public void setFailureReason(String failureReason) { this.failureReason = failureReason; }
    public Instant getInitiatedAt() { return initiatedAt; }
    public Instant getCompletedAt() { return completedAt; }
    public void setCompletedAt(Instant completedAt) { this.completedAt = completedAt; }

    public enum PremiumType { ONE_TIME, RECURRING }

    public enum TransactionType { PREMIUM_COLLECTION, REFUND }

    public enum PremiumStatus {
        INITIATED, PROCESSING, SUCCESS, FAILED, INSURER_CONFIRMATION_PENDING, TIMED_OUT
    }
}
