package com.fintech.insurance.service;

import com.fintech.insurance.dto.CreateScheduleRequest;
import com.fintech.insurance.dto.PremiumCollectionRequest;
import com.fintech.insurance.dto.ScheduleResponse;
import com.fintech.insurance.exception.ScheduleNotFoundException;
import com.fintech.insurance.model.PremiumSchedule;
import com.fintech.insurance.repository.PremiumScheduleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
public class PremiumScheduleService {

    private static final Logger log = LoggerFactory.getLogger(PremiumScheduleService.class);

    private final PremiumScheduleRepository scheduleRepository;
    private final PremiumCollectionService collectionService;

    public PremiumScheduleService(PremiumScheduleRepository scheduleRepository,
                                   PremiumCollectionService collectionService) {
        this.scheduleRepository = scheduleRepository;
        this.collectionService = collectionService;
    }

    @Transactional
    public ScheduleResponse createSchedule(CreateScheduleRequest request) {
        PremiumSchedule schedule = new PremiumSchedule();
        schedule.setPolicyHolderUserId(request.getPolicyHolderUserId());
        schedule.setPolicyNumber(request.getPolicyNumber());
        schedule.setInsurerCode(request.getInsurerCode());
        schedule.setInstallmentAmount(request.getInstallmentAmount());
        schedule.setCurrency(request.getCurrency());
        schedule.setFrequency(request.getFrequency());
        schedule.setNextDueDate(request.getFirstDueDate());
        schedule.setMandateReference(request.getMandateReference());
        schedule = scheduleRepository.save(schedule);
        return ScheduleResponse.from(schedule);
    }

    @Transactional
    public ScheduleResponse pauseSchedule(UUID scheduleId) {
        PremiumSchedule schedule = getSchedule(scheduleId);
        schedule.setStatus(PremiumSchedule.ScheduleStatus.PAUSED);
        return ScheduleResponse.from(scheduleRepository.save(schedule));
    }

    @Transactional
    public ScheduleResponse cancelSchedule(UUID scheduleId) {
        PremiumSchedule schedule = getSchedule(scheduleId);
        schedule.setStatus(PremiumSchedule.ScheduleStatus.CANCELLED);
        return ScheduleResponse.from(scheduleRepository.save(schedule));
    }

    @Transactional(readOnly = true)
    public ScheduleResponse getScheduleStatus(UUID scheduleId) {
        return ScheduleResponse.from(getSchedule(scheduleId));
    }

    /**
     * Called by a scheduled job (see PremiumDueScheduler) once daily. For
     * every ACTIVE schedule whose nextDueDate has arrived, triggers a
     * premium collection and advances the schedule to the next due date.
     *
     * Each collection uses a deterministic transactionId derived from the
     * schedule + due date, so a scheduler retry (e.g. after a pod restart
     * mid-run) never double-charges the same installment.
     */
    @Transactional
    public void collectDuePremiums() {
        List<PremiumSchedule> due = scheduleRepository.findByStatusAndNextDueDateLessThanEqual(
                PremiumSchedule.ScheduleStatus.ACTIVE, LocalDate.now());

        for (PremiumSchedule schedule : due) {
            UUID deterministicTxnId = UUID.nameUUIDFromBytes(
                    (schedule.getId().toString() + ":" + schedule.getNextDueDate()).getBytes());

            PremiumCollectionRequest request = new PremiumCollectionRequest();
            request.setOrchestrationTransactionId(deterministicTxnId);
            request.setPolicyHolderUserId(schedule.getPolicyHolderUserId());
            request.setPolicyNumber(schedule.getPolicyNumber());
            request.setInsurerCode(schedule.getInsurerCode());
            request.setAmount(schedule.getInstallmentAmount());
            request.setCurrency(schedule.getCurrency());
            request.setPremiumScheduleId(schedule.getId());

            try {
                collectionService.collectPremium(request);
                schedule.setNextDueDate(advance(schedule.getNextDueDate(), schedule.getFrequency()));
                scheduleRepository.save(schedule);
                log.info("Collected due premium for schedule {}, next due date advanced to {}",
                        schedule.getId(), schedule.getNextDueDate());
            } catch (Exception ex) {
                // Do NOT advance nextDueDate on failure — leave it due so the
                // next day's run retries automatically. A dedicated dunning/
                // retry policy (grace period, policy lapse notice) belongs
                // in a real implementation but is outside this service's scope.
                log.error("Failed to collect due premium for schedule {}: {}", schedule.getId(), ex.getMessage());
            }
        }
    }

    private LocalDate advance(LocalDate date, PremiumSchedule.Frequency frequency) {
        return switch (frequency) {
            case MONTHLY -> date.plusMonths(1);
            case QUARTERLY -> date.plusMonths(3);
            case HALF_YEARLY -> date.plusMonths(6);
            case ANNUAL -> date.plusYears(1);
        };
    }

    private PremiumSchedule getSchedule(UUID scheduleId) {
        return scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new ScheduleNotFoundException("Schedule not found: " + scheduleId));
    }
}
