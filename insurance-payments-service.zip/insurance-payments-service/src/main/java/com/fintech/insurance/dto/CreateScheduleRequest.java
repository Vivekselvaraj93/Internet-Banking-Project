package com.fintech.insurance.dto;

import com.fintech.insurance.model.PremiumSchedule;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

public class CreateScheduleRequest {

    @NotNull
    private UUID policyHolderUserId;

    @NotBlank
    private String policyNumber;

    @NotBlank
    private String insurerCode;

    @NotNull
    @DecimalMin(value = "1.00")
    private BigDecimal installmentAmount;

    @NotBlank
    private String currency;

    @NotNull
    private PremiumSchedule.Frequency frequency;

    @NotNull
    @FutureOrPresent
    private LocalDate firstDueDate;

    private String mandateReference;

    public UUID getPolicyHolderUserId() { return policyHolderUserId; }
    public void setPolicyHolderUserId(UUID policyHolderUserId) { this.policyHolderUserId = policyHolderUserId; }
    public String getPolicyNumber() { return policyNumber; }
    public void setPolicyNumber(String policyNumber) { this.policyNumber = policyNumber; }
    public String getInsurerCode() { return insurerCode; }
    public void setInsurerCode(String insurerCode) { this.insurerCode = insurerCode; }
    public BigDecimal getInstallmentAmount() { return installmentAmount; }
    public void setInstallmentAmount(BigDecimal installmentAmount) { this.installmentAmount = installmentAmount; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public PremiumSchedule.Frequency getFrequency() { return frequency; }
    public void setFrequency(PremiumSchedule.Frequency frequency) { this.frequency = frequency; }
    public LocalDate getFirstDueDate() { return firstDueDate; }
    public void setFirstDueDate(LocalDate firstDueDate) { this.firstDueDate = firstDueDate; }
    public String getMandateReference() { return mandateReference; }
    public void setMandateReference(String mandateReference) { this.mandateReference = mandateReference; }
}
