package com.fintech.insurance.dto;

import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.util.UUID;

public class PremiumCollectionRequest {

    @NotNull
    private UUID orchestrationTransactionId;

    @NotNull
    private UUID policyHolderUserId;

    @NotBlank
    private String policyNumber;

    @NotBlank
    private String insurerCode;

    @NotNull
    @DecimalMin(value = "1.00", message = "amount must be positive")
    private BigDecimal amount;

    @NotBlank
    private String currency;

    // Optional — set when this collection is one installment of a recurring schedule
    private UUID premiumScheduleId;
    private Integer installmentNumber;

    public UUID getOrchestrationTransactionId() { return orchestrationTransactionId; }
    public void setOrchestrationTransactionId(UUID orchestrationTransactionId) { this.orchestrationTransactionId = orchestrationTransactionId; }
    public UUID getPolicyHolderUserId() { return policyHolderUserId; }
    public void setPolicyHolderUserId(UUID policyHolderUserId) { this.policyHolderUserId = policyHolderUserId; }
    public String getPolicyNumber() { return policyNumber; }
    public void setPolicyNumber(String policyNumber) { this.policyNumber = policyNumber; }
    public String getInsurerCode() { return insurerCode; }
    public void setInsurerCode(String insurerCode) { this.insurerCode = insurerCode; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public UUID getPremiumScheduleId() { return premiumScheduleId; }
    public void setPremiumScheduleId(UUID premiumScheduleId) { this.premiumScheduleId = premiumScheduleId; }
    public Integer getInstallmentNumber() { return installmentNumber; }
    public void setInstallmentNumber(Integer installmentNumber) { this.installmentNumber = installmentNumber; }
}
