package com.fintech.insurance.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;

/**
 * Represents a recurring premium commitment (e.g. monthly/quarterly/annual
 * health or life insurance premium). Actual collection of each installment
 * is typically triggered via an e-mandate/standing instruction on the
 * underlying rail (UPI Autopay, NACH) — this schedule is the source of
 * truth for "when is the next premium due" and links each collected
 * InsurancePremiumTransaction back to it.
 */
@Entity
@Table(name = "premium_schedules")
public class PremiumSchedule {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "policy_holder_user_id", nullable = false)
    private UUID policyHolderUserId;

    @Column(name = "policy_number", nullable = false, length = 64)
    private String policyNumber;

    @Column(name = "insurer_code", nullable = false, length = 30)
    private String insurerCode;

    @Column(nullable = false, precision = 20, scale = 4)
    private BigDecimal installmentAmount;

    @Column(nullable = false, length = 3)
    private String currency;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Frequency frequency;

    @Column(name = "next_due_date", nullable = false)
    private LocalDate nextDueDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ScheduleStatus status;

    // Reference to the e-mandate/UPI Autopay/NACH registration that
    // authorizes automatic collection — actual mandate execution happens via
    // the UPI or bank rail connector, not this service
    @Column(name = "mandate_reference", length = 64)
    private String mandateReference;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @PrePersist
    void onCreate() {
        if (createdAt == null) createdAt = Instant.now();
        if (status == null) status = ScheduleStatus.ACTIVE;
    }

    public UUID getId() { return id; }
    public UUID getPolicyHolderUserId() { return policyHolderUserId; }
    public void setPolicyHolderUserId(UUID policyHolderUserId) { this.policyHolderUserId = policyHolderUserId; }
    public String getPolicyNumber() { return policyNumber; }
    public void setPolicyNumber(String policyNumber) { this.policyNumber = policyNumber; }
    public String getInsurerCode() { return insurerCode; }
    public void setInsurerCode(String insurerCode) { this.insurerCode = insurerCode; }
    public BigDecimal getInstallmentAmount() { return installmentAmount; }
    public void setInstallmentAmount(BigDecimal installmentAmount) { this.installmentAmount = installmentAmount; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public Frequency getFrequency() { return frequency; }
    public void setFrequency(Frequency frequency) { this.frequency = frequency; }
    public LocalDate getNextDueDate() { return nextDueDate; }
    public void setNextDueDate(LocalDate nextDueDate) { this.nextDueDate = nextDueDate; }
    public ScheduleStatus getStatus() { return status; }
    public void setStatus(ScheduleStatus status) { this.status = status; }
    public String getMandateReference() { return mandateReference; }
    public void setMandateReference(String mandateReference) { this.mandateReference = mandateReference; }
    public Instant getCreatedAt() { return createdAt; }

    public enum Frequency { MONTHLY, QUARTERLY, HALF_YEARLY, ANNUAL }

    public enum ScheduleStatus { ACTIVE, PAUSED, CANCELLED, COMPLETED }
}
