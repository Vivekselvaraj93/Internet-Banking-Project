package com.fintech.insurance.controller;

import com.fintech.insurance.dto.PremiumCollectionRequest;
import com.fintech.insurance.dto.PremiumRefundRequest;
import com.fintech.insurance.dto.PremiumTransactionResponse;
import com.fintech.insurance.service.PremiumCollectionService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/insurance")
public class InsurancePaymentController {

    private final PremiumCollectionService collectionService;

    public InsurancePaymentController(PremiumCollectionService collectionService) {
        this.collectionService = collectionService;
    }

    @PostMapping("/premiums")
    public ResponseEntity<PremiumTransactionResponse> collectPremium(
            @Valid @RequestBody PremiumCollectionRequest request) {
        return ResponseEntity.ok(collectionService.collectPremium(request));
    }

    @PostMapping("/refunds")
    public ResponseEntity<PremiumTransactionResponse> refundPremium(
            @Valid @RequestBody PremiumRefundRequest request) {
        return ResponseEntity.ok(collectionService.refundPremium(request));
    }

    @GetMapping("/transactions/{orchestrationTransactionId}")
    public ResponseEntity<PremiumTransactionResponse> getStatus(@PathVariable UUID orchestrationTransactionId) {
        return ResponseEntity.ok(collectionService.getStatus(orchestrationTransactionId));
    }
}
