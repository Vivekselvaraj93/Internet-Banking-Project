CREATE TABLE premium_schedules (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_holder_user_id   UUID NOT NULL,
    policy_number           VARCHAR(64) NOT NULL,
    insurer_code            VARCHAR(30) NOT NULL,
    installment_amount      NUMERIC(20,4) NOT NULL CHECK (installment_amount > 0),
    currency                CHAR(3) NOT NULL,
    frequency               VARCHAR(20) NOT NULL CHECK (frequency IN ('MONTHLY','QUARTERLY','HALF_YEARLY','ANNUAL')),
    next_due_date           DATE NOT NULL,
    status                  VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    mandate_reference       VARCHAR(64),
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_schedule_due ON premium_schedules(status, next_due_date);
CREATE INDEX idx_schedule_policyholder ON premium_schedules(policy_holder_user_id);

CREATE TABLE insurance_premium_transactions (
    id                              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    orchestration_transaction_id    UUID NOT NULL UNIQUE,
    policy_holder_user_id           UUID NOT NULL,
    policy_number                   VARCHAR(64) NOT NULL,
    insurer_code                    VARCHAR(30) NOT NULL,
    premium_type                    VARCHAR(20) NOT NULL CHECK (premium_type IN ('ONE_TIME','RECURRING')),
    transaction_type                VARCHAR(20) NOT NULL CHECK (transaction_type IN ('PREMIUM_COLLECTION','REFUND')),
    amount                          NUMERIC(20,4) NOT NULL CHECK (amount > 0),
    currency                        CHAR(3) NOT NULL,
    premium_schedule_id             UUID REFERENCES premium_schedules(id),
    installment_number              INT,
    status                          VARCHAR(30) NOT NULL DEFAULT 'INITIATED',
    settlement_rail                 VARCHAR(10),
    settlement_reference            VARCHAR(64),
    insurer_reference               VARCHAR(64),
    failure_reason                  TEXT,
    initiated_at                    TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at                    TIMESTAMPTZ,
    version                         BIGINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_ipt_orchestration_ref ON insurance_premium_transactions(orchestration_transaction_id);
CREATE INDEX idx_ipt_policy_number ON insurance_premium_transactions(policy_number, initiated_at DESC);
CREATE INDEX idx_ipt_insurer ON insurance_premium_transactions(insurer_code);
CREATE INDEX idx_ipt_schedule ON insurance_premium_transactions(premium_schedule_id, installment_number);
CREATE INDEX idx_ipt_status_initiated ON insurance_premium_transactions(status, initiated_at);
