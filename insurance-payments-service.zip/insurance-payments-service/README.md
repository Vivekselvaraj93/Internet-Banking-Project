# Insurance Payments Service

Collects insurance premiums (one-time and recurring) and processes premium
refunds. This service handles **payment collection only** — it does not
distribute or sell insurance. Distributing insurance (advising on policies,
comparing products, earning commission) requires a separate IRDAI Web
Aggregator or Corporate Agent license; this service is scoped to "charge the
customer and get the money to the insurer," nothing more.

## Key design points

- **Delegates actual money movement.** This service does not talk to
  UPI/NEFT/IMPS directly — it calls the internal Payment Orchestration
  Service (`PaymentOrchestrationClient`), which picks the appropriate rail.
  Insurance premium collection is a use-case layered on the platform's
  existing payment infrastructure, not a new rail.
- **Insurer notification failure never rolls back a successful payment.**
  Once the customer's money has moved, that's final — telling the insurer
  about it is a separate, retryable concern (`INSURER_CONFIRMATION_PENDING`
  status + 15-minute reconciliation retry + 24-hour manual-review escalation).
  A flaky insurer API must never cause a customer to be told their payment
  failed when it actually succeeded.
- **Recurring premiums use deterministic transaction IDs** derived from
  `scheduleId + dueDate` (`UUID.nameUUIDFromBytes`), so a scheduler retry
  (e.g. pod restart mid-run) can never double-charge the same installment.
- **Failed due-premium collections don't advance the schedule** — the
  installment stays due so the next day's run retries automatically. A real
  implementation should add a proper dunning/grace-period/policy-lapse
  workflow on top of this; this service only guarantees "don't silently skip
  a failed premium."
- **Refund validation**: a refund must reference a `SUCCESS`ful original
  collection and cannot exceed the original amount.

## API

| Method | Path | Purpose |
|---|---|---|
| POST | `/insurance/premiums` | Collect a one-time or scheduled-installment premium |
| POST | `/insurance/refunds` | Refund a premium (free-look, surrender, correction) |
| GET | `/insurance/transactions/{orchestrationTransactionId}` | Check transaction status |
| POST | `/insurance/schedules` | Create a recurring premium schedule |
| GET | `/insurance/schedules/{scheduleId}` | Get schedule status |
| POST | `/insurance/schedules/{scheduleId}/pause` | Pause a schedule |
| POST | `/insurance/schedules/{scheduleId}/cancel` | Cancel a schedule |

### Example: one-time premium collection

```bash
curl -X POST http://insurance-payments-service:8080/insurance/premiums \
  -H "Content-Type: application/json" \
  -d '{
    "orchestrationTransactionId": "66666666-6666-6666-6666-666666666666",
    "policyHolderUserId": "11111111-1111-1111-1111-111111111111",
    "policyNumber": "DIGIT-HEALTH-2026-88213",
    "insurerCode": "DIGIT",
    "amount": 12500.00,
    "currency": "INR"
  }'
```

### Example: create a monthly recurring schedule

```bash
curl -X POST http://insurance-payments-service:8080/insurance/schedules \
  -H "Content-Type: application/json" \
  -d '{
    "policyHolderUserId": "11111111-1111-1111-1111-111111111111",
    "policyNumber": "ACKO-LIFE-2026-11029",
    "insurerCode": "ACKO",
    "installmentAmount": 2100.00,
    "currency": "INR",
    "frequency": "MONTHLY",
    "firstDueDate": "2026-08-01",
    "mandateReference": "UPI-AUTOPAY-MANDATE-XYZ"
  }'
```

## Important: insurer API details are illustrative

`GenericInsurerNotificationClient` is a structural placeholder. In practice,
each insurer/insurtech partner (Digit, Acko, HDFC Ergo) exposes its own API
— a production build typically has one implementation per insurer, or a
shared adapter if working through an insurance BaaS aggregator.

## Build & Deploy

```bash
export PROJECT_ID=$(gcloud config get-value project)
export REGION=us-central1

docker build -t ${REGION}-docker.pkg.dev/${PROJECT_ID}/fintech-images/insurance-payments-service:1.0.0 .
gcloud auth configure-docker ${REGION}-docker.pkg.dev
docker push ${REGION}-docker.pkg.dev/${PROJECT_ID}/fintech-images/insurance-payments-service:1.0.0
```

```bash
kubectl apply -f k8s/01-config-and-secret.yaml
kubectl apply -f k8s/02-deployment-service-hpa.yaml
```
