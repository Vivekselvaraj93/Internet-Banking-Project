# International Payments (Cross-Border) Service

The most compliance-heavy service in the platform. Integrates with a
cross-border payments partner (Nium, Thunes, Wise Platform) or an
Authorized Dealer (AD) bank's SWIFT gateway, since this platform does not
itself hold AD bank status.

## Strict processing order (this is the core design)

Every outward remittance goes through these steps **in this exact order**,
and can terminate at any step with a distinct, clearly labeled status:

1. **Idempotency check** — safe retries from the Payment Orchestration Service
2. **Sanctions/AML screening** — `SanctionsScreeningClient`. `BLOCKED` and
   `FLAGGED` both hard-stop the transaction (`SCREENING_FAILED`); only
   `CLEAR` allows the flow to continue.
3. **RBI LRS annual limit check** — `LrsLimitValidator` sums the remitter's
   successful remittances since the start of the current Indian financial
   year (April 1) and blocks (`LRS_LIMIT_EXCEEDED`) if this transfer would
   exceed the limit.
4. **FX quote lock** — obtained from the partner, rate and destination
   amount recorded on the transaction.
5. **Partner transfer initiation** — SWIFT UETR captured for tracking.

## Critical compliance notes — read before going live

- **Sanctions screening fails CLOSED.** If the screening provider call
  itself errors out, the result is `FLAGGED` (requiring manual review),
  never `CLEAR`. An outage in the screening system must never be treated
  as permission to proceed.
- **This platform does not implement sanctions-list matching logic.** It
  calls out to a licensed provider (ComplyAdvantage, Refinitiv World-Check,
  Dow Jones, or your cross-border partner's bundled screening). You must
  contract with a real provider — `ThirdPartySanctionsScreeningClient` is a
  structural placeholder only.
- **The LRS limit check here is a simplified approximation.** It assumes
  this platform's own transaction history is the complete picture of a
  customer's LRS usage in the financial year — in reality, customers can
  remit through other banks/platforms too, and USD-equivalent conversion at
  historical rates matters for an accurate cumulative total. Real-world LRS
  enforcement typically leans on the AD bank's own centralized tracking
  (banks report to RBI). Treat the local check here as a first line of
  defense, not the sole control.
- **Purpose codes are mandatory, not optional** — every remittance requires
  an RBI Purpose Code (e.g. `P0802` education, `S0301` travel) for FEMA
  reporting. This is enforced at the DTO validation layer (`@NotBlank`).
- **The LRS annual limit figure (USD 250,000 default) and every other
  regulatory figure in this service must be reverified against the current
  RBI Master Direction on LRS before going live** — these change periodically.

## API

| Method | Path | Purpose |
|---|---|---|
| POST | `/international-payments` | Initiate an outward remittance |
| GET | `/international-payments/{orchestrationTransactionId}` | Check status |
| POST | `/international-payments/webhooks/nium` | Partner webhook (HMAC-verified) |

### Example: initiate a remittance

```bash
curl -X POST http://international-payments-service:8080/international-payments \
  -H "Content-Type: application/json" \
  -d '{
    "orchestrationTransactionId": "55555555-5555-5555-5555-555555555555",
    "remitterUserId": "11111111-1111-1111-1111-111111111111",
    "remitterFullName": "Ravi Kumar",
    "beneficiaryName": "John Smith",
    "beneficiaryCountry": "US",
    "beneficiaryBankSwift": "BOFAUS3N",
    "beneficiaryAccountOrIban": "1234567890",
    "sourceAmount": 5000.00,
    "sourceCurrency": "INR",
    "destinationCurrency": "USD",
    "purposeCode": "P0802",
    "purposeDescription": "Tuition fee payment"
  }'
```

## Build & Deploy

```bash
export PROJECT_ID=$(gcloud config get-value project)
export REGION=us-central1

docker build -t ${REGION}-docker.pkg.dev/${PROJECT_ID}/fintech-images/international-payments-service:1.0.0 .
gcloud auth configure-docker ${REGION}-docker.pkg.dev
docker push ${REGION}-docker.pkg.dev/${PROJECT_ID}/fintech-images/international-payments-service:1.0.0
```

```bash
kubectl apply -f k8s/01-config-and-secret.yaml
kubectl apply -f k8s/02-deployment-service-hpa.yaml
```
