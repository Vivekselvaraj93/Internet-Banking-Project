package com.fintech.intlpayments.dto;

public class InternationalPaymentWebhookPayload {

    private String partnerReference;
    private String status;
    private String swiftUetr;
    private String failureReason;

    public String getPartnerReference() { return partnerReference; }
    public void setPartnerReference(String partnerReference) { this.partnerReference = partnerReference; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getSwiftUetr() { return swiftUetr; }
    public void setSwiftUetr(String swiftUetr) { this.swiftUetr = swiftUetr; }
    public String getFailureReason() { return failureReason; }
    public void setFailureReason(String failureReason) { this.failureReason = failureReason; }
}
