package com.fintech.intlpayments.exception;

public class InternationalPaymentNotFoundException extends RuntimeException {
    public InternationalPaymentNotFoundException(String message) {
        super(message);
    }
}
