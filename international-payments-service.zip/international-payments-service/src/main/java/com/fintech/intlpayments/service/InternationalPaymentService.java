package com.fintech.intlpayments.service;

import com.fintech.intlpayments.client.CrossBorderPartnerClient;
import com.fintech.intlpayments.client.SanctionsScreeningClient;
import com.fintech.intlpayments.dto.InternationalPaymentRequest;
import com.fintech.intlpayments.dto.InternationalPaymentResponse;
import com.fintech.intlpayments.dto.InternationalPaymentWebhookPayload;
import com.fintech.intlpayments.exception.InternationalPaymentNotFoundException;
import com.fintech.intlpayments.model.InternationalPaymentTransaction;
import com.fintech.intlpayments.model.InternationalPaymentTransaction.IntlPaymentStatus;
import com.fintech.intlpayments.model.InternationalPaymentTransaction.ScreeningStatus;
import com.fintech.intlpayments.repository.InternationalPaymentTransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;

@Service
public class InternationalPaymentService {

    private static final Logger log = LoggerFactory.getLogger(InternationalPaymentService.class);

    private final InternationalPaymentTransactionRepository repository;
    private final CrossBorderPartnerClient partnerClient;
    private final SanctionsScreeningClient screeningClient;
    private final LrsLimitValidator lrsLimitValidator;

    public InternationalPaymentService(InternationalPaymentTransactionRepository repository,
                                        CrossBorderPartnerClient partnerClient,
                                        SanctionsScreeningClient screeningClient,
                                        LrsLimitValidator lrsLimitValidator) {
        this.repository = repository;
        this.partnerClient = partnerClient;
        this.screeningClient = screeningClient;
        this.lrsLimitValidator = lrsLimitValidator;
    }

    /**
     * Strict order of operations for every outward remittance:
     *   1. Idempotency check
     *   2. Sanctions/AML screening (BLOCKED -> hard stop, FLAGGED -> hard
     *      stop pending manual compliance review, CLEAR -> proceed)
     *   3. RBI LRS annual limit check
     *   4. FX quote lock
     *   5. Partner transfer initiation
     *
     * Each step can terminate the transaction in a distinct, clearly
     * labeled status — compliance and support teams need to know exactly
     * which control stopped a payment, not just "FAILED".
     */
    @Transactional
    public InternationalPaymentResponse initiatePayment(InternationalPaymentRequest request) {
        var existing = repository.findByOrchestrationTransactionId(request.getOrchestrationTransactionId());
        if (existing.isPresent()) {
            log.info("International payment for orchestration txn {} already exists, returning existing state",
                    request.getOrchestrationTransactionId());
            return InternationalPaymentResponse.from(existing.get());
        }

        InternationalPaymentTransaction txn = buildTransaction(request);
        txn = repository.save(txn);

        // --- Step 1: Sanctions screening ---
        txn.setStatus(IntlPaymentStatus.SCREENING);
        repository.save(txn);

        SanctionsScreeningClient.ScreeningResult screeningResult = screeningClient.screen(
                new SanctionsScreeningClient.ScreeningRequest(
                        request.getRemitterFullName(),
                        request.getBeneficiaryName(),
                        request.getBeneficiaryCountry(),
                        request.getBeneficiaryBankSwift()
                )
        ).block();

        txn.setScreeningReference(screeningResult.screeningReference());

        if (screeningResult.outcome() == SanctionsScreeningClient.ScreeningOutcome.BLOCKED) {
            txn.setScreeningStatus(ScreeningStatus.BLOCKED);
            txn.setStatus(IntlPaymentStatus.SCREENING_FAILED);
            txn.setFailureReason("Sanctions screening match — transaction blocked");
            txn.setCompletedAt(Instant.now());
            txn = repository.save(txn);
            log.error("International payment {} BLOCKED by sanctions screening", txn.getId());
            return InternationalPaymentResponse.from(txn);
        }

        if (screeningResult.outcome() == SanctionsScreeningClient.ScreeningOutcome.FLAGGED) {
            txn.setScreeningStatus(ScreeningStatus.FLAGGED);
            txn.setStatus(IntlPaymentStatus.SCREENING_FAILED);
            txn.setFailureReason("Sanctions screening flagged this transaction for manual compliance review");
            txn = repository.save(txn);
            log.warn("International payment {} FLAGGED for manual compliance review", txn.getId());
            // NOTE: a real implementation would route this to a compliance
            // review queue rather than terminating outright — simplified
            // here to a hard stop; a cleared manual review would need a
            // separate endpoint/workflow to resume the transaction.
            return InternationalPaymentResponse.from(txn);
        }

        txn.setScreeningStatus(ScreeningStatus.CLEARED);

        // --- Step 2: RBI LRS annual limit check ---
        try {
            lrsLimitValidator.validate(request.getRemitterUserId(), request.getSourceAmount());
        } catch (Exception ex) {
            txn.setStatus(IntlPaymentStatus.LRS_LIMIT_EXCEEDED);
            txn.setFailureReason(ex.getMessage());
            txn.setCompletedAt(Instant.now());
            txn = repository.save(txn);
            log.warn("International payment {} blocked: LRS limit exceeded", txn.getId());
            return InternationalPaymentResponse.from(txn);
        }

        // --- Step 3: FX quote ---
        CrossBorderPartnerClient.FxQuote fxQuote;
        try {
            fxQuote = partnerClient.getFxQuote(
                    request.getSourceCurrency(), request.getDestinationCurrency(), request.getSourceAmount()
            ).block();
        } catch (Exception ex) {
            txn.setStatus(IntlPaymentStatus.FAILED);
            txn.setFailureReason("Failed to obtain FX quote: " + ex.getMessage());
            txn = repository.save(txn);
            return InternationalPaymentResponse.from(txn);
        }

        txn.setFxRate(fxQuote.rate());
        txn.setDestinationAmount(fxQuote.destinationAmount());

        // --- Step 4: Initiate transfer with partner ---
        try {
            CrossBorderPartnerClient.PartnerInitiationResult result = partnerClient.initiateTransfer(
                    request.getOrchestrationTransactionId(),
                    request.getBeneficiaryName(),
                    request.getBeneficiaryCountry(),
                    request.getBeneficiaryBankSwift(),
                    request.getBeneficiaryAccountOrIban(),
                    request.getSourceAmount(),
                    request.getSourceCurrency(),
                    request.getDestinationCurrency(),
                    request.getPurposeCode(),
                    fxQuote.quoteId()
            ).block();

            txn.setPartnerReference(result.partnerReference());
            txn.setSwiftUetr(result.swiftUetr());
            txn.setStatus(mapPartnerStatus(result.status()));

            if (isTerminal(txn.getStatus())) {
                txn.setCompletedAt(Instant.now());
            }
        } catch (Exception ex) {
            log.error("Failed to initiate international transfer with partner for txn {}: {}",
                    request.getOrchestrationTransactionId(), ex.getMessage());
            txn.setStatus(IntlPaymentStatus.FAILED);
            txn.setFailureReason("Partner call failed: " + ex.getMessage());
        }

        txn = repository.save(txn);
        return InternationalPaymentResponse.from(txn);
    }

    @Transactional(readOnly = true)
    public InternationalPaymentResponse getStatus(UUID orchestrationTransactionId) {
        InternationalPaymentTransaction txn = repository.findByOrchestrationTransactionId(orchestrationTransactionId)
                .orElseThrow(() -> new InternationalPaymentNotFoundException(
                        "No international payment found for orchestration txn " + orchestrationTransactionId));
        return InternationalPaymentResponse.from(txn);
    }

    @Transactional
    public void handleWebhook(InternationalPaymentWebhookPayload payload) {
        InternationalPaymentTransaction txn = repository.findByPartnerReference(payload.getPartnerReference())
                .orElseThrow(() -> new InternationalPaymentNotFoundException(
                        "No international payment found for partner reference " + payload.getPartnerReference()));

        if (isTerminal(txn.getStatus())) {
            log.info("Webhook received for already-terminal txn {} — ignoring duplicate", txn.getId());
            return;
        }

        txn.setStatus(mapPartnerStatus(payload.getStatus()));
        txn.setSwiftUetr(payload.getSwiftUetr());
        txn.setFailureReason(payload.getFailureReason());
        if (isTerminal(txn.getStatus())) {
            txn.setCompletedAt(Instant.now());
        }

        repository.save(txn);
        log.info("Updated international payment txn {} to status {} via webhook", txn.getId(), txn.getStatus());
    }

    /**
     * Reconciliation: SWIFT gpi tracking means most cross-border payments
     * report status changes, but network hops across correspondent banks
     * can introduce delays measured in hours or (rarely) days — wider
     * windows than domestic rails.
     */
    @Transactional
    public void reconcilePendingTransactions() {
        Instant cutoff = Instant.now().minus(30, ChronoUnit.MINUTES);
        List<InternationalPaymentTransaction> stuck = repository.findByStatusInAndInitiatedAtBefore(
                List.of(IntlPaymentStatus.SENT_TO_PARTNER, IntlPaymentStatus.PROCESSING), cutoff);

        for (InternationalPaymentTransaction txn : stuck) {
            if (txn.getPartnerReference() == null) continue;
            try {
                CrossBorderPartnerClient.PartnerStatusResult result =
                        partnerClient.checkStatus(txn.getPartnerReference()).block();

                IntlPaymentStatus newStatus = mapPartnerStatus(result.status());
                if (newStatus != txn.getStatus()) {
                    txn.setStatus(newStatus);
                    txn.setSwiftUetr(result.swiftUetr());
                    txn.setFailureReason(result.failureReason());
                    if (isTerminal(newStatus)) txn.setCompletedAt(Instant.now());
                    repository.save(txn);
                    log.info("Reconciliation updated international payment txn {} to {}", txn.getId(), newStatus);
                }
            } catch (Exception ex) {
                log.warn("Reconciliation status check failed for txn {}: {}", txn.getId(), ex.getMessage());
            }
        }

        Instant hardCutoff = Instant.now().minus(5, ChronoUnit.DAYS);
        List<InternationalPaymentTransaction> timedOut = repository.findByStatusInAndInitiatedAtBefore(
                List.of(IntlPaymentStatus.SENT_TO_PARTNER, IntlPaymentStatus.PROCESSING), hardCutoff);
        for (InternationalPaymentTransaction txn : timedOut) {
            txn.setStatus(IntlPaymentStatus.TIMED_OUT);
            repository.save(txn);
            log.error("International payment txn {} marked TIMED_OUT after 5 days unresolved — needs manual review",
                    txn.getId());
        }
    }

    private InternationalPaymentTransaction buildTransaction(InternationalPaymentRequest request) {
        InternationalPaymentTransaction txn = new InternationalPaymentTransaction();
        txn.setOrchestrationTransactionId(request.getOrchestrationTransactionId());
        txn.setRemitterUserId(request.getRemitterUserId());
        txn.setBeneficiaryName(request.getBeneficiaryName());
        txn.setBeneficiaryCountry(request.getBeneficiaryCountry());
        txn.setBeneficiaryBankSwift(request.getBeneficiaryBankSwift());
        txn.setBeneficiaryAccountOrIban(request.getBeneficiaryAccountOrIban());
        txn.setSourceAmount(request.getSourceAmount());
        txn.setSourceCurrency(request.getSourceCurrency());
        txn.setDestinationCurrency(request.getDestinationCurrency());
        txn.setPurposeCode(request.getPurposeCode());
        txn.setPurposeDescription(request.getPurposeDescription());
        txn.setPartnerProvider("nium");
        return txn;
    }

    private boolean isTerminal(IntlPaymentStatus status) {
        return status == IntlPaymentStatus.SUCCESS
                || status == IntlPaymentStatus.FAILED
                || status == IntlPaymentStatus.TIMED_OUT
                || status == IntlPaymentStatus.SCREENING_FAILED
                || status == IntlPaymentStatus.LRS_LIMIT_EXCEEDED;
    }

    private IntlPaymentStatus mapPartnerStatus(String partnerStatus) {
        if (partnerStatus == null) return IntlPaymentStatus.SENT_TO_PARTNER;
        return switch (partnerStatus.toUpperCase()) {
            case "SUCCESS", "COMPLETED", "CREDITED" -> IntlPaymentStatus.SUCCESS;
            case "FAILED", "REJECTED", "RETURNED" -> IntlPaymentStatus.FAILED;
            case "PROCESSING", "IN_PROGRESS", "PENDING" -> IntlPaymentStatus.PROCESSING;
            default -> IntlPaymentStatus.SENT_TO_PARTNER;
        };
    }
}
