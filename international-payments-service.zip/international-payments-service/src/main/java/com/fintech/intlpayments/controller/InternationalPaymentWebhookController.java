package com.fintech.intlpayments.controller;

import com.fintech.intlpayments.dto.InternationalPaymentWebhookPayload;
import com.fintech.intlpayments.service.InternationalPaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.HexFormat;
import java.util.Map;

@RestController
public class InternationalPaymentWebhookController {

    private static final Logger log = LoggerFactory.getLogger(InternationalPaymentWebhookController.class);

    private final InternationalPaymentService service;
    private final String webhookSigningSecret;

    public InternationalPaymentWebhookController(
            InternationalPaymentService service,
            @Value("${intlpayments.partner.nium.webhook-secret}") String webhookSigningSecret) {
        this.service = service;
        this.webhookSigningSecret = webhookSigningSecret;
    }

    @PostMapping("/international-payments/webhooks/nium")
    public ResponseEntity<Map<String, String>> handleWebhook(
            @RequestHeader(value = "X-Nium-Signature", required = false) String signature,
            @RequestBody String rawBody) {

        if (!isValidSignature(rawBody, signature)) {
            log.warn("Rejected international payment webhook with invalid signature");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "invalid_signature"));
        }

        InternationalPaymentWebhookPayload payload = parsePayload(rawBody);
        service.handleWebhook(payload);

        return ResponseEntity.ok(Map.of("status", "received"));
    }

    private boolean isValidSignature(String rawBody, String providedSignature) {
        if (providedSignature == null) return false;
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(webhookSigningSecret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] computedHash = mac.doFinal(rawBody.getBytes(StandardCharsets.UTF_8));
            String computedSignature = HexFormat.of().formatHex(computedHash);
            return constantTimeEquals(computedSignature, providedSignature);
        } catch (Exception ex) {
            log.error("Webhook signature verification failed: {}", ex.getMessage());
            return false;
        }
    }

    private boolean constantTimeEquals(String a, String b) {
        if (a.length() != b.length()) return false;
        int result = 0;
        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }
        return result == 0;
    }

    private InternationalPaymentWebhookPayload parsePayload(String rawBody) {
        try {
            com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
            return mapper.readValue(rawBody, InternationalPaymentWebhookPayload.class);
        } catch (Exception ex) {
            throw new IllegalArgumentException("Malformed webhook payload", ex);
        }
    }
}
