package com.fintech.intlpayments.dto;

import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.util.UUID;

public class InternationalPaymentRequest {

    @NotNull
    private UUID orchestrationTransactionId;

    @NotNull
    private UUID remitterUserId;

    @NotBlank
    private String remitterFullName; // required for sanctions screening

    @NotBlank
    private String beneficiaryName;

    @NotBlank
    @Pattern(regexp = "^[A-Z]{2}$", message = "beneficiaryCountry must be an ISO 3166-1 alpha-2 code")
    private String beneficiaryCountry;

    @NotBlank
    @Pattern(regexp = "^[A-Z0-9]{8,11}$", message = "invalid SWIFT/BIC code format")
    private String beneficiaryBankSwift;

    @NotBlank
    private String beneficiaryAccountOrIban;

    @NotNull
    @DecimalMin(value = "1.00", message = "amount must be positive")
    private BigDecimal sourceAmount;

    @NotBlank
    private String sourceCurrency;

    @NotBlank
    private String destinationCurrency;

    // RBI Purpose Code — mandatory for FEMA reporting, e.g. "P0802" (education), "S0301" (travel)
    @NotBlank
    private String purposeCode;

    private String purposeDescription;

    public UUID getOrchestrationTransactionId() { return orchestrationTransactionId; }
    public void setOrchestrationTransactionId(UUID orchestrationTransactionId) { this.orchestrationTransactionId = orchestrationTransactionId; }
    public UUID getRemitterUserId() { return remitterUserId; }
    public void setRemitterUserId(UUID remitterUserId) { this.remitterUserId = remitterUserId; }
    public String getRemitterFullName() { return remitterFullName; }
    public void setRemitterFullName(String remitterFullName) { this.remitterFullName = remitterFullName; }
    public String getBeneficiaryName() { return beneficiaryName; }
    public void setBeneficiaryName(String beneficiaryName) { this.beneficiaryName = beneficiaryName; }
    public String getBeneficiaryCountry() { return beneficiaryCountry; }
    public void setBeneficiaryCountry(String beneficiaryCountry) { this.beneficiaryCountry = beneficiaryCountry; }
    public String getBeneficiaryBankSwift() { return beneficiaryBankSwift; }
    public void setBeneficiaryBankSwift(String beneficiaryBankSwift) { this.beneficiaryBankSwift = beneficiaryBankSwift; }
    public String getBeneficiaryAccountOrIban() { return beneficiaryAccountOrIban; }
    public void setBeneficiaryAccountOrIban(String beneficiaryAccountOrIban) { this.beneficiaryAccountOrIban = beneficiaryAccountOrIban; }
    public BigDecimal getSourceAmount() { return sourceAmount; }
    public void setSourceAmount(BigDecimal sourceAmount) { this.sourceAmount = sourceAmount; }
    public String getSourceCurrency() { return sourceCurrency; }
    public void setSourceCurrency(String sourceCurrency) { this.sourceCurrency = sourceCurrency; }
    public String getDestinationCurrency() { return destinationCurrency; }
    public void setDestinationCurrency(String destinationCurrency) { this.destinationCurrency = destinationCurrency; }
    public String getPurposeCode() { return purposeCode; }
    public void setPurposeCode(String purposeCode) { this.purposeCode = purposeCode; }
    public String getPurposeDescription() { return purposeDescription; }
    public void setPurposeDescription(String purposeDescription) { this.purposeDescription = purposeDescription; }
}
