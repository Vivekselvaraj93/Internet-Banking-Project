package com.fintech.intlpayments.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;

/**
 * Example implementation wired for a Nium-style cross-border payout API.
 *
 * IMPORTANT: as with the other partner clients in this platform, field
 * names, endpoint paths, and auth headers below are illustrative
 * placeholders — verify against the partner's current API documentation
 * before going live.
 */
@Component
public class NiumCrossBorderPartnerClient implements CrossBorderPartnerClient {

    private static final Logger log = LoggerFactory.getLogger(NiumCrossBorderPartnerClient.class);

    private final WebClient webClient;

    public NiumCrossBorderPartnerClient(
            WebClient.Builder webClientBuilder,
            @Value("${intlpayments.partner.nium.base-url}") String baseUrl,
            @Value("${intlpayments.partner.nium.api-key}") String apiKey,
            @Value("${intlpayments.partner.nium.client-id}") String clientId) {

        this.webClient = webClientBuilder
                .baseUrl(baseUrl)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader("x-api-key", apiKey)
                .defaultHeader("x-client-id", clientId)
                .build();
    }

    @Override
    public Mono<FxQuote> getFxQuote(String sourceCurrency, String destinationCurrency, BigDecimal sourceAmount) {
        Map<String, Object> body = Map.of(
                "sourceCurrency", sourceCurrency,
                "destinationCurrency", destinationCurrency,
                "sourceAmount", sourceAmount
        );

        return webClient.post()
                .uri("/fx/quotes")
                .bodyValue(body)
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(8))
                .map(this::mapFxQuote);
    }

    @Override
    public Mono<PartnerInitiationResult> initiateTransfer(
            UUID orchestrationTransactionId,
            String beneficiaryName,
            String beneficiaryCountry,
            String beneficiaryBankSwift,
            String beneficiaryAccountOrIban,
            BigDecimal sourceAmount,
            String sourceCurrency,
            String destinationCurrency,
            String purposeCode,
            String fxQuoteId) {

        Map<String, Object> body = Map.of(
                "clientReferenceId", orchestrationTransactionId.toString(),
                "beneficiary", Map.of(
                        "name", beneficiaryName,
                        "country", beneficiaryCountry,
                        "swiftCode", beneficiaryBankSwift,
                        "accountOrIban", beneficiaryAccountOrIban
                ),
                "sourceAmount", sourceAmount,
                "sourceCurrency", sourceCurrency,
                "destinationCurrency", destinationCurrency,
                "purposeCode", purposeCode,
                "fxQuoteId", fxQuoteId
        );

        return webClient.post()
                .uri("/remittances")
                .bodyValue(body)
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(20)) // cross-border calls can be slower than domestic rails
                .retryWhen(Retry.backoff(2, Duration.ofSeconds(1))
                        .filter(this::isRetryable))
                .map(this::mapInitiationResponse)
                .doOnError(ex -> log.error("Nium initiateTransfer failed for txn {}: {}",
                        orchestrationTransactionId, ex.getMessage()));
    }

    @Override
    public Mono<PartnerStatusResult> checkStatus(String partnerReference) {
        return webClient.get()
                .uri("/remittances/{ref}", partnerReference)
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(10))
                .map(this::mapStatusResponse);
    }

    @SuppressWarnings("unchecked")
    private FxQuote mapFxQuote(Map<String, Object> response) {
        return new FxQuote(
                (String) response.get("quoteId"),
                new BigDecimal(response.get("rate").toString()),
                new BigDecimal(response.get("destinationAmount").toString()),
                Instant.parse((String) response.get("expiresAt"))
        );
    }

    @SuppressWarnings("unchecked")
    private PartnerInitiationResult mapInitiationResponse(Map<String, Object> response) {
        return new PartnerInitiationResult(
                (String) response.get("id"),
                (String) response.get("status"),
                (String) response.get("swiftUetr")
        );
    }

    @SuppressWarnings("unchecked")
    private PartnerStatusResult mapStatusResponse(Map<String, Object> response) {
        return new PartnerStatusResult(
                (String) response.get("status"),
                (String) response.get("swiftUetr"),
                (String) response.get("failureReason")
        );
    }

    private boolean isRetryable(Throwable ex) {
        String message = ex.getMessage();
        return message != null && (message.contains("timeout") || message.contains("5"));
    }
}
