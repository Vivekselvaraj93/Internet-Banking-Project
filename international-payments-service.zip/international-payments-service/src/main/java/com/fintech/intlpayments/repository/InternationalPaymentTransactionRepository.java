package com.fintech.intlpayments.repository;

import com.fintech.intlpayments.model.InternationalPaymentTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface InternationalPaymentTransactionRepository extends JpaRepository<InternationalPaymentTransaction, UUID> {

    Optional<InternationalPaymentTransaction> findByOrchestrationTransactionId(UUID orchestrationTransactionId);

    Optional<InternationalPaymentTransaction> findByPartnerReference(String partnerReference);

    List<InternationalPaymentTransaction> findByStatusInAndInitiatedAtBefore(
            List<InternationalPaymentTransaction.IntlPaymentStatus> statuses, Instant cutoff);

    /**
     * Sums successful outward remittances for a remitter within the current
     * RBI financial year (April 1 – March 31), in USD-equivalent, for LRS
     * annual limit enforcement. The orchestration/ledger layer is expected
     * to store amounts pre-converted to USD equivalent for this comparison,
     * OR this query result should be combined with an FX conversion step —
     * simplified here assuming sourceCurrency is consistently tracked in a
     * reporting currency for LRS purposes.
     */
    @Query("""
        SELECT COALESCE(SUM(t.sourceAmount), 0) FROM InternationalPaymentTransaction t
        WHERE t.remitterUserId = :remitterUserId
        AND t.status = 'SUCCESS'
        AND t.initiatedAt >= :financialYearStart
    """)
    BigDecimal sumSuccessfulRemittancesSinceFinancialYearStart(
            @Param("remitterUserId") UUID remitterUserId,
            @Param("financialYearStart") Instant financialYearStart);
}
