package com.fintech.intlpayments.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.Map;

/**
 * Illustrative integration shape for a third-party sanctions screening
 * provider (e.g. ComplyAdvantage). Field names and endpoint are placeholders
 * — replace with your actual contracted provider's API contract.
 *
 * CRITICAL: fail CLOSED, not open. If the screening call itself errors out
 * (timeout, 5xx, network failure), this returns FLAGGED rather than CLEAR —
 * an international payment should never proceed on the assumption that "no
 * response" means "no match." A human compliance reviewer should clear any
 * FLAGGED result before funds move.
 */
@Component
public class ThirdPartySanctionsScreeningClient implements SanctionsScreeningClient {

    private static final Logger log = LoggerFactory.getLogger(ThirdPartySanctionsScreeningClient.class);

    private final WebClient webClient;

    public ThirdPartySanctionsScreeningClient(
            WebClient.Builder webClientBuilder,
            @Value("${intlpayments.screening.base-url}") String baseUrl,
            @Value("${intlpayments.screening.api-key}") String apiKey) {

        this.webClient = webClientBuilder
                .baseUrl(baseUrl)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader("Authorization", "Bearer " + apiKey)
                .build();
    }

    @Override
    public Mono<ScreeningResult> screen(ScreeningRequest request) {
        Map<String, Object> body = Map.of(
                "search_term", request.beneficiaryFullName(),
                "fuzziness", 0.6,
                "filters", Map.of(
                        "country_codes", request.beneficiaryCountry(),
                        "types", new String[]{"sanction", "warning", "fitness-probity"}
                )
        );

        return webClient.post()
                .uri("/searches")
                .bodyValue(body)
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(8))
                .map(this::mapResponse)
                .onErrorResume(ex -> {
                    // Fail CLOSED: a screening system outage must never be
                    // silently treated as "clear to proceed."
                    log.error("Sanctions screening call failed — failing closed (FLAGGED for manual review): {}",
                            ex.getMessage());
                    return Mono.just(new ScreeningResult(
                            ScreeningOutcome.FLAGGED, null,
                            "Screening provider unavailable: " + ex.getMessage()));
                });
    }

    @SuppressWarnings("unchecked")
    private ScreeningResult mapResponse(Map<String, Object> response) {
        // Placeholder mapping logic — adjust to your provider's actual
        // response schema and match-confidence thresholds.
        String searchId = (String) response.get("id");
        boolean hasMatches = Boolean.TRUE.equals(response.get("has_matches"));

        if (!hasMatches) {
            return new ScreeningResult(ScreeningOutcome.CLEAR, searchId, null);
        }
        // Any match requires human review — this platform never
        // auto-clears a match, only auto-flags for compliance review.
        return new ScreeningResult(ScreeningOutcome.FLAGGED, searchId, "Potential match found — review required");
    }
}
