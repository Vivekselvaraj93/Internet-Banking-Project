package com.fintech.intlpayments.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "international_payment_transactions", indexes = {
        @Index(name = "idx_ipt_orchestration_ref", columnList = "orchestration_transaction_id", unique = true),
        @Index(name = "idx_ipt_partner_ref", columnList = "partner_reference"),
        @Index(name = "idx_ipt_remitter", columnList = "remitter_user_id")
})
public class InternationalPaymentTransaction {

    @Id
    @GeneratedValue
    private UUID id;

    @Column(name = "orchestration_transaction_id", nullable = false, unique = true)
    private UUID orchestrationTransactionId;

    // Needed to track cumulative usage against the RBI LRS annual limit
    // (currently USD 250,000 per financial year per individual — must be
    // reverified against current RBI guidance, as this changes periodically)
    @Column(name = "remitter_user_id", nullable = false)
    private UUID remitterUserId;

    // --- Beneficiary details ---
    @Column(name = "beneficiary_name", nullable = false)
    private String beneficiaryName;

    @Column(name = "beneficiary_country", nullable = false, length = 2)
    private String beneficiaryCountry; // ISO 3166-1 alpha-2

    @Column(name = "beneficiary_bank_swift", nullable = false, length = 11)
    private String beneficiaryBankSwift;

    @Column(name = "beneficiary_account_or_iban", nullable = false)
    private String beneficiaryAccountOrIban;

    // --- Amount & FX ---
    @Column(name = "source_amount", nullable = false, precision = 20, scale = 4)
    private BigDecimal sourceAmount;

    @Column(name = "source_currency", nullable = false, length = 3)
    private String sourceCurrency;

    @Column(name = "destination_amount", precision = 20, scale = 4)
    private BigDecimal destinationAmount; // populated once the partner locks an FX rate

    @Column(name = "destination_currency", nullable = false, length = 3)
    private String destinationCurrency;

    @Column(name = "fx_rate", precision = 20, scale = 8)
    private BigDecimal fxRate;

    // --- FEMA / RBI compliance ---
    // RBI Purpose Code, e.g. "P0802" (education), "S0301" (travel) — mandatory
    // on every outward remittance for FEMA reporting via the AD bank
    @Column(name = "purpose_code", nullable = false, length = 10)
    private String purposeCode;

    @Column(name = "purpose_description")
    private String purposeDescription;

    // --- Sanctions/compliance screening ---
    @Enumerated(EnumType.STRING)
    @Column(name = "screening_status", nullable = false, length = 20)
    private ScreeningStatus screeningStatus;

    @Column(name = "screening_reference")
    private String screeningReference;

    // --- Transaction lifecycle ---
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private IntlPaymentStatus status;

    @Column(name = "partner_reference", length = 64)
    private String partnerReference;

    @Column(name = "partner_provider", length = 30)
    private String partnerProvider;

    // SWIFT UETR (Unique End-to-end Transaction Reference) — mandatory on
    // all SWIFT gpi payments since 2019, the definitive cross-border tracking ID
    @Column(name = "swift_uetr", length = 36)
    private String swiftUetr;

    @Column(name = "failure_reason")
    private String failureReason;

    @Column(name = "initiated_at", nullable = false)
    private Instant initiatedAt;

    @Column(name = "completed_at")
    private Instant completedAt;

    @Version
    private Long version;

    @PrePersist
    void onCreate() {
        if (initiatedAt == null) initiatedAt = Instant.now();
        if (status == null) status = IntlPaymentStatus.INITIATED;
        if (screeningStatus == null) screeningStatus = ScreeningStatus.PENDING;
    }

    public UUID getId() { return id; }
    public UUID getOrchestrationTransactionId() { return orchestrationTransactionId; }
    public void setOrchestrationTransactionId(UUID orchestrationTransactionId) { this.orchestrationTransactionId = orchestrationTransactionId; }
    public UUID getRemitterUserId() { return remitterUserId; }
    public void setRemitterUserId(UUID remitterUserId) { this.remitterUserId = remitterUserId; }
    public String getBeneficiaryName() { return beneficiaryName; }
    public void setBeneficiaryName(String beneficiaryName) { this.beneficiaryName = beneficiaryName; }
    public String getBeneficiaryCountry() { return beneficiaryCountry; }
    public void setBeneficiaryCountry(String beneficiaryCountry) { this.beneficiaryCountry = beneficiaryCountry; }
    public String getBeneficiaryBankSwift() { return beneficiaryBankSwift; }
    public void setBeneficiaryBankSwift(String beneficiaryBankSwift) { this.beneficiaryBankSwift = beneficiaryBankSwift; }
    public String getBeneficiaryAccountOrIban() { return beneficiaryAccountOrIban; }
    public void setBeneficiaryAccountOrIban(String beneficiaryAccountOrIban) { this.beneficiaryAccountOrIban = beneficiaryAccountOrIban; }
    public BigDecimal getSourceAmount() { return sourceAmount; }
    public void setSourceAmount(BigDecimal sourceAmount) { this.sourceAmount = sourceAmount; }
    public String getSourceCurrency() { return sourceCurrency; }
    public void setSourceCurrency(String sourceCurrency) { this.sourceCurrency = sourceCurrency; }
    public BigDecimal getDestinationAmount() { return destinationAmount; }
    public void setDestinationAmount(BigDecimal destinationAmount) { this.destinationAmount = destinationAmount; }
    public String getDestinationCurrency() { return destinationCurrency; }
    public void setDestinationCurrency(String destinationCurrency) { this.destinationCurrency = destinationCurrency; }
    public BigDecimal getFxRate() { return fxRate; }
    public void setFxRate(BigDecimal fxRate) { this.fxRate = fxRate; }
    public String getPurposeCode() { return purposeCode; }
    public void setPurposeCode(String purposeCode) { this.purposeCode = purposeCode; }
    public String getPurposeDescription() { return purposeDescription; }
    public void setPurposeDescription(String purposeDescription) { this.purposeDescription = purposeDescription; }
    public ScreeningStatus getScreeningStatus() { return screeningStatus; }
    public void setScreeningStatus(ScreeningStatus screeningStatus) { this.screeningStatus = screeningStatus; }
    public String getScreeningReference() { return screeningReference; }
    public void setScreeningReference(String screeningReference) { this.screeningReference = screeningReference; }
    public IntlPaymentStatus getStatus() { return status; }
    public void setStatus(IntlPaymentStatus status) { this.status = status; }
    public String getPartnerReference() { return partnerReference; }
    public void setPartnerReference(String partnerReference) { this.partnerReference = partnerReference; }
    public String getPartnerProvider() { return partnerProvider; }
    public void setPartnerProvider(String partnerProvider) { this.partnerProvider = partnerProvider; }
    public String getSwiftUetr() { return swiftUetr; }
    public void setSwiftUetr(String swiftUetr) { this.swiftUetr = swiftUetr; }
    public String getFailureReason() { return failureReason; }
    public void setFailureReason(String failureReason) { this.failureReason = failureReason; }
    public Instant getInitiatedAt() { return initiatedAt; }
    public Instant getCompletedAt() { return completedAt; }
    public void setCompletedAt(Instant completedAt) { this.completedAt = completedAt; }

    public enum ScreeningStatus { PENDING, CLEARED, FLAGGED, BLOCKED }

    public enum IntlPaymentStatus {
        INITIATED,          // record created, screening not yet run
        SCREENING,          // sanctions/AML screening in progress
        SCREENING_FAILED,   // blocked by sanctions/compliance screening — terminal
        LRS_LIMIT_EXCEEDED, // blocked by RBI LRS annual limit check — terminal
        SENT_TO_PARTNER,
        PROCESSING,
        SUCCESS,
        FAILED,
        TIMED_OUT
    }
}
