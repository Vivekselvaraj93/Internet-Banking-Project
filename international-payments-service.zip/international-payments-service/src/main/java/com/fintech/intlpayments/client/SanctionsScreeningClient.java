package com.fintech.intlpayments.client;

import reactor.core.publisher.Mono;

/**
 * Abstraction over a sanctions/watchlist screening provider. This platform
 * does NOT implement sanctions list matching logic itself — that requires
 * a licensed, continuously-updated data source (OFAC SDN, UN, EU, UK HMT
 * consolidated lists, plus PEP databases). Typical providers: ComplyAdvantage,
 * Refinitiv World-Check, Dow Jones Risk & Compliance, or the screening
 * module bundled with your cross-border payments partner (Nium/Thunes often
 * include this as part of their compliance layer).
 *
 * Every outward international payment MUST pass through this check before
 * funds are ever sent — this is a hard legal requirement, not a business
 * decision this platform can choose to skip.
 */
public interface SanctionsScreeningClient {

    Mono<ScreeningResult> screen(ScreeningRequest request);

    record ScreeningRequest(
            String remitterFullName,
            String beneficiaryFullName,
            String beneficiaryCountry,
            String beneficiaryBankSwift
    ) {}

    record ScreeningResult(
            ScreeningOutcome outcome,
            String screeningReference,
            String matchDetails // populated only if outcome is FLAGGED, for compliance team review
    ) {}

    enum ScreeningOutcome {
        CLEAR,     // no matches — safe to proceed
        FLAGGED,   // potential match — requires manual compliance review before proceeding
        BLOCKED    // confirmed sanctions match — transaction must not proceed, ever
    }
}
