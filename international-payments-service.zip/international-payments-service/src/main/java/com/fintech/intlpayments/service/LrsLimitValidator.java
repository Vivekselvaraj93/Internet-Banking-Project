package com.fintech.intlpayments.service;

import com.fintech.intlpayments.exception.LrsLimitExceededException;
import com.fintech.intlpayments.repository.InternationalPaymentTransactionRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.temporal.TemporalAdjusters;
import java.util.UUID;

/**
 * Enforces RBI's Liberalised Remittance Scheme (LRS) annual limit —
 * currently USD 250,000 per individual per financial year (April–March) —
 * across all outward remittance purposes combined (education, travel,
 * gifts, investments, etc. all draw from the same combined limit).
 *
 * IMPORTANT: this is a simplified, single-currency approximation. A
 * production implementation must:
 *   1. Convert every historical remittance to USD at the rate applicable
 *      on ITS transaction date (not today's rate) for an accurate
 *      cumulative total, since LRS is denominated in USD.
 *   2. Reverify the current limit figure against the latest RBI Master
 *      Direction on LRS — this changes periodically.
 *   3. Consider that this platform's own transaction history is not
 *      necessarily the customer's ONLY LRS usage — a customer may have
     *      remitted through other banks/platforms in the same financial year,
 *      which this service has no visibility into. A real implementation
 *      typically relies on the AD bank's own LRS tracking (banks report to
 *      RBI centrally) rather than the fintech's local count being the
 *      source of truth.
 */
@Component
public class LrsLimitValidator {

    private final InternationalPaymentTransactionRepository repository;
    private final BigDecimal annualLimitUsd;

    public LrsLimitValidator(
            InternationalPaymentTransactionRepository repository,
            @Value("${intlpayments.lrs.annual-limit-usd:250000}") BigDecimal annualLimitUsd) {
        this.repository = repository;
        this.annualLimitUsd = annualLimitUsd;
    }

    public void validate(UUID remitterUserId, BigDecimal requestedAmountUsdEquivalent) {
        var financialYearStart = currentFinancialYearStart();

        BigDecimal alreadyRemitted = repository.sumSuccessfulRemittancesSinceFinancialYearStart(
                remitterUserId, financialYearStart);

        BigDecimal projectedTotal = alreadyRemitted.add(requestedAmountUsdEquivalent);

        if (projectedTotal.compareTo(annualLimitUsd) > 0) {
            throw new LrsLimitExceededException(String.format(
                    "This remittance would bring the customer's total outward remittances for FY to %s USD, " +
                    "exceeding the RBI LRS annual limit of %s USD. Already remitted: %s USD.",
                    projectedTotal, annualLimitUsd, alreadyRemitted));
        }
    }

    private java.time.Instant currentFinancialYearStart() {
        LocalDate today = LocalDate.now(ZoneOffset.UTC);
        // Indian financial year runs April 1 - March 31
        LocalDate fyStart = today.getMonthValue() >= 4
                ? LocalDate.of(today.getYear(), 4, 1)
                : LocalDate.of(today.getYear() - 1, 4, 1);
        return fyStart.atStartOfDay(ZoneOffset.UTC).toInstant();
    }
}
