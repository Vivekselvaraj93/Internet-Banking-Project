package com.fintech.intlpayments.client;

import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Abstraction over the cross-border payments partner (Nium, Thunes, Wise
 * Platform) or AD bank SWIFT gateway. Keeps the platform swappable between
 * providers without touching business logic.
 */
public interface CrossBorderPartnerClient {

    Mono<FxQuote> getFxQuote(String sourceCurrency, String destinationCurrency, BigDecimal sourceAmount);

    Mono<PartnerInitiationResult> initiateTransfer(
            UUID orchestrationTransactionId,
            String beneficiaryName,
            String beneficiaryCountry,
            String beneficiaryBankSwift,
            String beneficiaryAccountOrIban,
            BigDecimal sourceAmount,
            String sourceCurrency,
            String destinationCurrency,
            String purposeCode,
            String fxQuoteId
    );

    Mono<PartnerStatusResult> checkStatus(String partnerReference);

    record FxQuote(
            String quoteId,
            BigDecimal rate,
            BigDecimal destinationAmount,
            java.time.Instant expiresAt
    ) {}

    record PartnerInitiationResult(
            String partnerReference,
            String status,
            String swiftUetr
    ) {}

    record PartnerStatusResult(
            String status,
            String swiftUetr,
            String failureReason
    ) {}
}
