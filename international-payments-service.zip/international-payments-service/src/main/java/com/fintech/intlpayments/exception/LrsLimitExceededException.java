package com.fintech.intlpayments.exception;

public class LrsLimitExceededException extends RuntimeException {
    public LrsLimitExceededException(String message) {
        super(message);
    }
}
