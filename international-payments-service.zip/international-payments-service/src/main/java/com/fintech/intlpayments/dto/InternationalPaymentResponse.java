package com.fintech.intlpayments.dto;

import com.fintech.intlpayments.model.InternationalPaymentTransaction;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public record InternationalPaymentResponse(
        UUID orchestrationTransactionId,
        InternationalPaymentTransaction.IntlPaymentStatus status,
        InternationalPaymentTransaction.ScreeningStatus screeningStatus,
        BigDecimal fxRate,
        BigDecimal destinationAmount,
        String swiftUetr,
        String partnerReference,
        String failureReason,
        Instant initiatedAt,
        Instant completedAt
) {
    public static InternationalPaymentResponse from(InternationalPaymentTransaction txn) {
        return new InternationalPaymentResponse(
                txn.getOrchestrationTransactionId(),
                txn.getStatus(),
                txn.getScreeningStatus(),
                txn.getFxRate(),
                txn.getDestinationAmount(),
                txn.getSwiftUetr(),
                txn.getPartnerReference(),
                txn.getFailureReason(),
                txn.getInitiatedAt(),
                txn.getCompletedAt()
        );
    }
}
