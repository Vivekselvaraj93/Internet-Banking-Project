package com.fintech.intlpayments.exception;

public class SanctionsScreeningBlockedException extends RuntimeException {
    public SanctionsScreeningBlockedException(String message) {
        super(message);
    }
}
