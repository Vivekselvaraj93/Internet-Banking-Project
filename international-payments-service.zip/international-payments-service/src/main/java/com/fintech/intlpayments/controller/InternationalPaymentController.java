package com.fintech.intlpayments.controller;

import com.fintech.intlpayments.dto.InternationalPaymentRequest;
import com.fintech.intlpayments.dto.InternationalPaymentResponse;
import com.fintech.intlpayments.service.InternationalPaymentService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/international-payments")
public class InternationalPaymentController {

    private final InternationalPaymentService service;

    public InternationalPaymentController(InternationalPaymentService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<InternationalPaymentResponse> initiatePayment(
            @Valid @RequestBody InternationalPaymentRequest request) {
        return ResponseEntity.ok(service.initiatePayment(request));
    }

    @GetMapping("/{orchestrationTransactionId}")
    public ResponseEntity<InternationalPaymentResponse> getStatus(@PathVariable UUID orchestrationTransactionId) {
        return ResponseEntity.ok(service.getStatus(orchestrationTransactionId));
    }
}
