package com.fintech.intlpayments.config;

import com.fintech.intlpayments.service.InternationalPaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ReconciliationScheduler {

    private static final Logger log = LoggerFactory.getLogger(ReconciliationScheduler.class);

    private final InternationalPaymentService internationalPaymentService;

    public ReconciliationScheduler(InternationalPaymentService internationalPaymentService) {
        this.internationalPaymentService = internationalPaymentService;
    }

    /** Runs every 10 minutes — cross-border settlement is inherently slower than domestic rails. */
    @Scheduled(fixedDelay = 600_000)
    public void reconcile() {
        try {
            internationalPaymentService.reconcilePendingTransactions();
        } catch (Exception ex) {
            log.error("Reconciliation job failed: {}", ex.getMessage(), ex);
        }
    }
}
