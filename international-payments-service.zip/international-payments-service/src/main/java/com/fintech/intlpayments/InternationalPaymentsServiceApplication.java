package com.fintech.intlpayments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * International Payments Service — cross-border remittance connector.
 *
 * Integrates with an Authorized Dealer (AD) bank or a cross-border payments
 * specialist (Nium, Thunes, Wise Platform) since this platform does not
 * itself hold AD bank status.
 *
 * This service carries the heaviest regulatory load in the platform:
 *  - RBI LRS (Liberalised Remittance Scheme) limit enforcement for individuals
 *  - FEMA purpose code classification (mandatory on every outward remittance)
 *  - Sanctions/OFAC screening before every transfer is allowed to proceed
 *  - Form A2 declaration data capture (required for AD bank compliance filing)
 *
 * None of the above are optional compliance decorations — an outward
 * remittance that skips sanctions screening or purpose coding is not just
 * risky, it is very likely to be rejected by the AD bank or to expose the
 * platform to regulatory action.
 */
@SpringBootApplication
@EnableRetry
@EnableScheduling
public class InternationalPaymentsServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(InternationalPaymentsServiceApplication.class, args);
    }
}
