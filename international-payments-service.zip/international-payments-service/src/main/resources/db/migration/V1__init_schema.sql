CREATE TABLE international_payment_transactions (
    id                              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    orchestration_transaction_id    UUID NOT NULL UNIQUE,
    remitter_user_id                UUID NOT NULL,
    beneficiary_name                VARCHAR(140) NOT NULL,
    beneficiary_country             CHAR(2) NOT NULL,
    beneficiary_bank_swift          VARCHAR(11) NOT NULL,
    beneficiary_account_or_iban     VARCHAR(64) NOT NULL,
    source_amount                   NUMERIC(20,4) NOT NULL CHECK (source_amount > 0),
    source_currency                 CHAR(3) NOT NULL,
    destination_amount              NUMERIC(20,4),
    destination_currency            CHAR(3) NOT NULL,
    fx_rate                         NUMERIC(20,8),
    purpose_code                    VARCHAR(10) NOT NULL,
    purpose_description             TEXT,
    screening_status                VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    screening_reference             VARCHAR(64),
    status                          VARCHAR(20) NOT NULL DEFAULT 'INITIATED',
    partner_reference               VARCHAR(64),
    partner_provider                VARCHAR(30),
    swift_uetr                      VARCHAR(36),
    failure_reason                  TEXT,
    initiated_at                    TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at                    TIMESTAMPTZ,
    version                         BIGINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_ipt_orchestration_ref ON international_payment_transactions(orchestration_transaction_id);
CREATE INDEX idx_ipt_partner_ref ON international_payment_transactions(partner_reference);
CREATE INDEX idx_ipt_remitter ON international_payment_transactions(remitter_user_id);
CREATE INDEX idx_ipt_status_initiated ON international_payment_transactions(status, initiated_at);

-- Speeds up the LRS annual-limit aggregate query, which filters by
-- remitter + status + a date range every time a new remittance is attempted
CREATE INDEX idx_ipt_lrs_lookup ON international_payment_transactions(remitter_user_id, status, initiated_at);
