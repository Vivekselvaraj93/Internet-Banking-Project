# Kubernetes HA Overlay — High Throughput, Zero-Downtime, Fault-Tolerant

Applies availability and throughput hardening on top of the 7 services'
existing manifests, without duplicating those manifests — this is a
Kustomize **overlay**, not a replacement.

## How this fits with everything already built

| Piece | Role |
|---|---|
| `terraform-gke-infra/` | The cluster/DB/cache foundation: regional multi-zone GKE, HA Cloud SQL, HA Redis |
| `k8s-ha-overlay/` (this) | Pod-level HA: anti-affinity, graceful shutdown, priority, tuned autoscaling, network isolation |
| `harness-deployment/` | **Zero-downtime delivery mechanism** — Blue-Green swap, so a *deploy* never causes downtime |
| Each service's own `k8s/` folder | The base manifests this overlay patches |

Together: Terraform gives you a cluster that can survive a zone failure;
this overlay makes sure pods are actually *placed* so that failure only
costs you a fraction of capacity; Harness makes sure *deploying a new
version* never costs you any capacity at all. All three are needed — none
of them alone gets you "zero downtime + fault tolerant + HA".

## What this overlay adds, and why each piece matters

| File | What it does | Why it matters for HA/throughput |
|---|---|---|
| `00-priorityclasses.yaml` | 2 PriorityClasses: `payment-critical`, `standard` | Under resource pressure, the scheduler favors ledger/UPI/bank-rails/gateway pods; if eviction is ever necessary, lower-priority services get squeezed first |
| `01-resourcequota-limitrange.yaml` | Namespace-wide caps + sane per-container defaults | One misconfigured HPA can't silently consume the whole cluster and starve everyone else |
| `02-networkpolicies.yaml` | Default-deny + explicit allows matching the real call graph | Limits blast radius of a compromised pod; also documents the actual service-to-service dependency graph as enforceable policy, not just a diagram |
| `03-ha-deployment-patch-template.yaml` | Master patch: hard pod anti-affinity, preStop graceful shutdown, priorityClassName, extended grace period | See detailed breakdown below |
| `hpa/*.yaml` | Per-service tuned HPA: faster scale-up, slower scale-down, higher ceilings for payment-critical services | Genuine high-frequency headroom — UPI connector can scale to 25 pods, general services cap lower |
| `kustomize/<service>/` | Wires the patch + HPA onto each service's existing base manifests | Apply with `kubectl apply -k kustomize/<service>/` |

### The four things the HA patch changes, in detail

1. **Hard pod anti-affinity** (`requiredDuringSchedulingIgnoredDuringExecution`)
   — the original manifests used a *soft* topology spread
   (`whenUnsatisfiable: ScheduleAnyway`). This patch makes it a hard
   requirement: no two pods of the same service can ever share a node. One
   node failure can then never take out more than one replica of any service.

2. **Graceful shutdown via `preStop` sleep (20s)** — without this, a pod
   gets `SIGTERM` the instant Kubernetes decides to remove it, but the
   Service's endpoint list can take a few seconds to propagate the removal
   cluster-wide. In that window, in-flight requests can be routed to a pod
   that's already shutting down, causing user-visible errors during
   perfectly ordinary scale-down/rolling-update events — this is one of the
   most common causes of "phantom" errors during deploys that teams
   struggle to diagnose. The sleep buys time for the endpoint removal to
   propagate before the app process actually receives the shutdown signal.

3. **`priorityClassName`** — ties each service to the PriorityClass from
   step 1.

4. **`terminationGracePeriodSeconds: 45`** — must exceed the preStop sleep
   (20s) + Spring Boot's own graceful shutdown timeout (already configured
   as `spring.lifecycle.timeout-per-shutdown-phase: 20s` in every service's
   `application.yml`), or Kubernetes force-kills the process before it
   finishes draining. 20 + 20 = 40s, with a 5s buffer.

## Applying this

**Path adjustment required first:** every `kustomize/<service>/kustomization.yaml`
assumes each service's repo (from its own earlier zip deliverable) is
checked out as a sibling directory. Adjust the `resources:` relative paths
to match your actual repo layout — this can't be guessed correctly in advance.

```bash
kubectl apply -f 00-priorityclasses.yaml
kubectl apply -f 01-resourcequota-limitrange.yaml
kubectl apply -f 02-networkpolicies.yaml

# Per service:
kubectl apply -k kustomize/api-gateway/
kubectl apply -k kustomize/ledger-service/
kubectl apply -k kustomize/auth-service/
kubectl apply -k kustomize/upi-connector-service/
kubectl apply -k kustomize/neft-rtgs-imps-connector-service/
kubectl apply -k kustomize/international-payments-service/
kubectl apply -k kustomize/insurance-payments-service/
```

**Note on `payment-orchestration-service`**: `02-networkpolicies.yaml`
references this service by label (`app: payment-orchestration-service`) in
several `NetworkPolicy` ingress/egress rules, since it's the intended
central caller of the ledger and every rail connector — but that service
hasn't been built yet (see the earlier conversation). Until it exists, those
specific policy rules simply match nothing and have no effect; they're not
harmful to apply early, but the rail connectors won't actually be reachable
via that path until you build and deploy it.

## Verifying HA is actually working

```bash
# Confirm no two pods of the same service share a node:
kubectl get pods -n fintech -o wide -l app=upi-connector-service

# Confirm PriorityClass is applied:
kubectl get pods -n fintech -o jsonpath='{.items[*].spec.priorityClassName}'

# Watch a rolling update and confirm zero dropped requests: run a load
# generator (e.g. hey/vegeta) against the service while triggering a
# Harness Blue-Green deploy, and confirm the error rate panel on the
# "Fintech Platform Overview" Grafana dashboard stays flat through the swap.
```

## What this does NOT cover

- **Multi-region disaster recovery.** Everything here is single-region,
  multi-zone. A full region outage (rare, but not impossible) would still
  cause an outage. Multi-region active-active or active-passive is a
  substantially bigger undertaking (data replication strategy for Cloud
  SQL/Redis across regions, global load balancing) — worth planning for
  once you have a clearer picture of your actual uptime SLA commitments.
- **Database read replicas for read-heavy throughput scaling.** The
  Terraform Cloud SQL setup is HA (failover-capable) but not yet scaled out
  with read replicas — add these if read query volume (e.g. balance
  checks, statement fetches) becomes a bottleneck separate from write throughput.
- **Load testing.** None of the sizing here (replica counts, node pool
  sizes, HPA thresholds) has been validated against your actual peak
  transaction volume — treat every number in this overlay as a starting
  point to tune after real load testing, not a guarantee.
