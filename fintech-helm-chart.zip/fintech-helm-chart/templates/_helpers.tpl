{{/* Resolves the service name — nameOverride if set, else the release name */}}
{{- define "fintech-service.name" -}}
{{- .Values.nameOverride | default .Release.Name -}}
{{- end -}}

{{/* Standard labels applied to every resource this chart creates */}}
{{- define "fintech-service.labels" -}}
app: {{ include "fintech-service.name" . }}
app.kubernetes.io/name: {{ include "fintech-service.name" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/version: {{ .Values.image.tag | quote }}
version: {{ .Values.version }}
{{- end -}}

{{/* Selector labels — must be a stable subset of the full labels above, never changes across releases */}}
{{- define "fintech-service.selectorLabels" -}}
app: {{ include "fintech-service.name" . }}
{{- end -}}

{{- define "fintech-service.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{ include "fintech-service.name" . }}-ksa
{{- else -}}
default
{{- end -}}
{{- end -}}
