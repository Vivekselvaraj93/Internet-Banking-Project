# Fintech Service — Reusable Helm Chart

One chart, deployed 7 times with 7 different `values/*.yaml` files. Change
the chart's templates once, every service picks up the change on its next
`helm upgrade` — this is the tradeoff you chose over 7 separate charts.

## Structure

```
fintech-helm-chart/
├── Chart.yaml
├── values.yaml                    # defaults, documented — every field explained inline
├── values/
│   ├── api-gateway.yaml            # 7 per-service overrides
│   ├── ledger-service.yaml
│   ├── auth-service.yaml
│   ├── upi-connector-service.yaml
│   ├── neft-rtgs-imps-connector-service.yaml
│   ├── international-payments-service.yaml
│   └── insurance-payments-service.yaml
└── templates/
    ├── _helpers.tpl                # naming/label conventions
    ├── deployment.yaml
    ├── service.yaml                 # ONE Service — Istio handles version routing, no primary/stage pair needed
    ├── config-account-pdb-hpa.yaml
    ├── networkpolicy-servicemonitor.yaml
    └── NOTES.txt
```

## What's built in (same HA principles as the earlier Kustomize overlay, now as chart defaults)

- Hard pod anti-affinity (no two pods of a service share a node)
- Hard topology spread across zones (`whenUnsatisfiable: DoNotSchedule`)
- `preStop` graceful shutdown sleep + extended `terminationGracePeriodSeconds`
- `priorityClassName` (payment-critical vs standard)
- Tuned HPA: fast scale-up, slow scale-down
- PodDisruptionBudget, ServiceMonitor (Prometheus scraping), optional NetworkPolicy

## ⚠️ One placement tension to know about

`deployment.yaml` combines **hard** pod anti-affinity (one pod per node)
with **hard** zone spread. At low replica counts (3-4, matching most
services' `minReplicas`) this is fine across a 3-zone regional cluster. But
`upi-connector-service` can scale to 25 replicas under load — at that
count, "one pod per node" requires at least 25 distinct nodes to exist and
have capacity, which depends entirely on your node pool's `maxNodeCount` in
`terraform-gke-infra`. If the HPA wants to scale past however many nodes
actually exist, pods will go `Pending` instead of failing over gracefully.
**Size your payment-critical node pool's max node count with this in mind**,
or relax the anti-affinity to `preferredDuringScheduling...` (soft) for
services with a high `maxReplicas` if strict one-per-node isn't achievable
at your actual scale.

## Install / upgrade

```bash
# Prerequisites: namespaces created, secrets already populated (via each
# service's own ExternalSecret pattern), Cloud SQL private IP filled into
# each values file (currently a placeholder), GCP project ID substituted
# into image.repository and serviceAccount.gcpServiceAccountEmail.

helm upgrade --install ledger-service . \
  -f values/ledger-service.yaml \
  --namespace fintech \
  --wait --timeout 5m

# Repeat per service:
helm upgrade --install api-gateway . -f values/api-gateway.yaml -n fintech --wait
helm upgrade --install auth-service . -f values/auth-service.yaml -n fintech --wait
helm upgrade --install upi-connector-service . -f values/upi-connector-service.yaml -n fintech --wait
helm upgrade --install neft-rtgs-imps-connector-service . -f values/neft-rtgs-imps-connector-service.yaml -n fintech --wait
helm upgrade --install international-payments-service . -f values/international-payments-service.yaml -n fintech --wait
helm upgrade --install insurance-payments-service . -f values/insurance-payments-service.yaml -n fintech --wait
```

Each `helm upgrade --install` is its own Helm release — this is what keeps
them independently upgradeable/rollback-able (`helm rollback ledger-service 1`
rolls back only the ledger, not the whole platform), even though they all
come from one chart.

## Relationship to Harness

Per your earlier choice, **Harness remains the deploy mechanism** — its
Blue-Green pipelines can be pointed at this Helm chart instead of raw K8s
manifests (Harness supports Helm charts as a manifest source type
natively; swap the `K8sManifest` store type in each service's Harness
Service definition to `HelmChart` pointing at this chart + the matching
values file). This chart doesn't replace those pipelines — it replaces the
raw manifests they were deploying.

## Relationship to Istio

If Istio is installed (`../istio-config/`), every pod gets an Envoy
sidecar automatically via namespace injection — no chart changes needed.
The `version: v1` label baked into every pod (see `values.yaml`) is what
Istio's DestinationRule subsets and VirtualService routing key off of.
