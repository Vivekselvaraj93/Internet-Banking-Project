# UPI Connector Service

The only service that talks to the UPI rail — via a BaaS/PSP partner (Setu,
Cashfree, Decentro, etc.), since operating this platform does not require
(and does not have) direct NPCI TPAP membership.

## Key design points

- **`UpiPartnerClient` interface** decouples the service layer from any
  specific vendor. `SetuUpiPartnerClient` is a structural example — swap in
  a different implementation (or add a second for failover) without
  touching the database schema or business logic.
- **Idempotent initiation** by `orchestrationTransactionId` — a retried
  request from the Payment Orchestration Service returns the existing
  transaction instead of double-firing a real UPI payment with the partner.
- **Webhook + polling reconciliation, not webhook alone.** UPI webhooks can
  be missed or delayed. `ReconciliationScheduler` runs every 60s and
  actively checks partner status for anything stuck in `SENT_TO_PARTNER`/
  `PENDING` past 2 minutes; anything unresolved after 30 minutes is flagged
  `TIMED_OUT` for manual ops review rather than polled forever.
- **HMAC-signed webhook verification** (constant-time comparison) — without
  this, anyone who discovers the webhook URL could forge a fake "payment
  succeeded" callback.
- **NPCI RRN tracked explicitly** — this is the definitive reference number
  for UPI disputes/reconciliation with NPCI and must be captured whenever
  the partner provides it.
- Retries on the partner call are limited to transient failures (timeouts,
  5xx) — a 4xx from the partner is a validation/business error that will
  fail identically on retry and is never retried automatically.

## API

| Method | Path | Purpose |
|---|---|---|
| POST | `/upi/payments` | Initiate a UPI COLLECT or PAY request |
| GET | `/upi/payments/{orchestrationTransactionId}` | Check status |
| POST | `/upi/webhooks/setu` | Partner webhook receiver (HMAC-verified) |

### Example: initiate a UPI payment

```bash
curl -X POST http://upi-connector-service:8080/upi/payments \
  -H "Content-Type: application/json" \
  -d '{
    "orchestrationTransactionId": "33333333-3333-3333-3333-333333333333",
    "type": "PAY",
    "payerVpa": "user@okhdfcbank",
    "payeeVpa": "merchant@paytm",
    "amount": 499.00,
    "currency": "INR",
    "narration": "Order #4821"
  }'
```

## Important: partner API details are illustrative

`SetuUpiPartnerClient` uses placeholder field names, endpoint paths, and
response shapes based on typical BaaS API conventions. **Before going live,
verify every field against your chosen partner's current API documentation**
— exact request/response contracts vary by provider and change over time.
Treat this class as the integration point to fill in, not a finished driver.

## Build & Deploy (same flow as other services)

```bash
export PROJECT_ID=$(gcloud config get-value project)
export REGION=us-central1

docker build -t ${REGION}-docker.pkg.dev/${PROJECT_ID}/fintech-images/upi-connector-service:1.0.0 .
gcloud auth configure-docker ${REGION}-docker.pkg.dev
docker push ${REGION}-docker.pkg.dev/${PROJECT_ID}/fintech-images/upi-connector-service:1.0.0
```

```bash
kubectl apply -f k8s/01-configmap.yaml
kubectl apply -f k8s/02-secret-template.yaml
kubectl apply -f k8s/03-deployment.yaml
kubectl apply -f k8s/04-service.yaml
kubectl apply -f k8s/05-hpa-pdb.yaml
```
