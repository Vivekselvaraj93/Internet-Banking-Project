CREATE TABLE upi_transactions (
    id                              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    orchestration_transaction_id    UUID NOT NULL UNIQUE,
    type                            VARCHAR(20) NOT NULL CHECK (type IN ('COLLECT','PAY')),
    payer_vpa                       VARCHAR(100) NOT NULL,
    payee_vpa                       VARCHAR(100) NOT NULL,
    amount                          NUMERIC(20,4) NOT NULL CHECK (amount > 0),
    currency                        CHAR(3) NOT NULL,
    status                          VARCHAR(20) NOT NULL DEFAULT 'INITIATED',
    npci_rrn                        VARCHAR(20),
    partner_reference               VARCHAR(64),
    partner_provider                VARCHAR(30),
    failure_reason                  TEXT,
    initiated_at                    TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at                    TIMESTAMPTZ,
    webhook_received_at             TIMESTAMPTZ,
    version                         BIGINT NOT NULL DEFAULT 0
);

CREATE UNIQUE INDEX idx_upi_txn_orchestration_ref ON upi_transactions(orchestration_transaction_id);
CREATE INDEX idx_upi_txn_partner_ref ON upi_transactions(partner_reference);
CREATE INDEX idx_upi_txn_status_initiated ON upi_transactions(status, initiated_at);
