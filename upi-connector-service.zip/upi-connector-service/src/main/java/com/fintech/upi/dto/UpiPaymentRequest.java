package com.fintech.upi.dto;

import com.fintech.upi.model.UpiTransaction;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import java.math.BigDecimal;
import java.util.UUID;

public class UpiPaymentRequest {

    @NotNull
    private UUID orchestrationTransactionId;

    @NotNull
    private UpiTransaction.UpiTransactionType type;

    @NotBlank
    @Pattern(regexp = "^[\\w.\\-]{2,256}@[a-zA-Z]{2,64}$", message = "payerVpa must be a valid VPA, e.g. user@bank")
    private String payerVpa;

    @NotBlank
    @Pattern(regexp = "^[\\w.\\-]{2,256}@[a-zA-Z]{2,64}$", message = "payeeVpa must be a valid VPA, e.g. merchant@bank")
    private String payeeVpa;

    @NotNull
    @DecimalMin(value = "1.00", message = "UPI transactions must be at least ₹1")
    private BigDecimal amount;

    @NotBlank
    private String currency;

    private String narration;

    public UUID getOrchestrationTransactionId() { return orchestrationTransactionId; }
    public void setOrchestrationTransactionId(UUID orchestrationTransactionId) { this.orchestrationTransactionId = orchestrationTransactionId; }
    public UpiTransaction.UpiTransactionType getType() { return type; }
    public void setType(UpiTransaction.UpiTransactionType type) { this.type = type; }
    public String getPayerVpa() { return payerVpa; }
    public void setPayerVpa(String payerVpa) { this.payerVpa = payerVpa; }
    public String getPayeeVpa() { return payeeVpa; }
    public void setPayeeVpa(String payeeVpa) { this.payeeVpa = payeeVpa; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public String getNarration() { return narration; }
    public void setNarration(String narration) { this.narration = narration; }
}
