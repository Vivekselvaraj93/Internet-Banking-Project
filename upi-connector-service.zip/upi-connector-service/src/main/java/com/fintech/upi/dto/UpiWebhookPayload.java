package com.fintech.upi.dto;

public class UpiWebhookPayload {

    private String partnerReference;
    private String status;       // e.g. "SUCCESS", "FAILED", "PENDING"
    private String npciRrn;
    private String failureReason;

    public String getPartnerReference() { return partnerReference; }
    public void setPartnerReference(String partnerReference) { this.partnerReference = partnerReference; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getNpciRrn() { return npciRrn; }
    public void setNpciRrn(String npciRrn) { this.npciRrn = npciRrn; }
    public String getFailureReason() { return failureReason; }
    public void setFailureReason(String failureReason) { this.failureReason = failureReason; }
}
