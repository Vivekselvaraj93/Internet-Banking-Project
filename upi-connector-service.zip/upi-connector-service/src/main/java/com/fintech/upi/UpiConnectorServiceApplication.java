package com.fintech.upi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;

/**
 * UPI Connector Service — the only service that talks to the UPI rail
 * (via a BaaS/PSP partner such as Setu, Cashfree, or Decentro, since this
 * platform does not hold an NPCI TPAP license directly).
 *
 * Responsibilities:
 *  - Translate internal payment requests into the partner's UPI API contract
 *  - Handle VPA (Virtual Payment Address) validation, collect/pay requests
 *  - Track UPI-specific transaction state (NPCI RRN, partner reference)
 *  - Process partner webhooks reporting async success/failure
 *  - Never touches the ledger directly — reports outcomes back to the
 *    Payment Orchestration Service, which is the only caller of the Ledger Service
 */
@SpringBootApplication
@EnableRetry
public class UpiConnectorServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(UpiConnectorServiceApplication.class, args);
    }
}
