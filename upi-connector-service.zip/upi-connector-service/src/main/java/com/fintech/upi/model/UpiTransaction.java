package com.fintech.upi.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "upi_transactions", indexes = {
        @Index(name = "idx_upi_txn_orchestration_ref", columnList = "orchestration_transaction_id", unique = true),
        @Index(name = "idx_upi_txn_partner_ref", columnList = "partner_reference")
})
public class UpiTransaction {

    @Id
    @GeneratedValue
    private UUID id;

    // The transactionId assigned by the Payment Orchestration Service —
    // this is what ties this record back to the ledger transfer.
    @Column(name = "orchestration_transaction_id", nullable = false, unique = true)
    private UUID orchestrationTransactionId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private UpiTransactionType type; // COLLECT or PAY

    @Column(name = "payer_vpa", nullable = false, length = 100)
    private String payerVpa;

    @Column(name = "payee_vpa", nullable = false, length = 100)
    private String payeeVpa;

    @Column(nullable = false, precision = 20, scale = 4)
    private BigDecimal amount;

    @Column(nullable = false, length = 3)
    private String currency;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private UpiStatus status;

    // NPCI Retrieval Reference Number — the definitive proof of a UPI transaction,
    // required for reconciliation and dispute handling
    @Column(name = "npci_rrn", length = 20)
    private String npciRrn;

    // The BaaS/PSP partner's own transaction reference
    @Column(name = "partner_reference", length = 64)
    private String partnerReference;

    @Column(name = "partner_provider", length = 30)
    private String partnerProvider;

    @Column(name = "failure_reason")
    private String failureReason;

    @Column(name = "initiated_at", nullable = false)
    private Instant initiatedAt;

    @Column(name = "completed_at")
    private Instant completedAt;

    @Column(name = "webhook_received_at")
    private Instant webhookReceivedAt;

    @Version
    private Long version;

    @PrePersist
    void onCreate() {
        if (initiatedAt == null) initiatedAt = Instant.now();
        if (status == null) status = UpiStatus.INITIATED;
    }

    public UUID getId() { return id; }
    public UUID getOrchestrationTransactionId() { return orchestrationTransactionId; }
    public void setOrchestrationTransactionId(UUID orchestrationTransactionId) { this.orchestrationTransactionId = orchestrationTransactionId; }
    public UpiTransactionType getType() { return type; }
    public void setType(UpiTransactionType type) { this.type = type; }
    public String getPayerVpa() { return payerVpa; }
    public void setPayerVpa(String payerVpa) { this.payerVpa = payerVpa; }
    public String getPayeeVpa() { return payeeVpa; }
    public void setPayeeVpa(String payeeVpa) { this.payeeVpa = payeeVpa; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public UpiStatus getStatus() { return status; }
    public void setStatus(UpiStatus status) { this.status = status; }
    public String getNpciRrn() { return npciRrn; }
    public void setNpciRrn(String npciRrn) { this.npciRrn = npciRrn; }
    public String getPartnerReference() { return partnerReference; }
    public void setPartnerReference(String partnerReference) { this.partnerReference = partnerReference; }
    public String getPartnerProvider() { return partnerProvider; }
    public void setPartnerProvider(String partnerProvider) { this.partnerProvider = partnerProvider; }
    public String getFailureReason() { return failureReason; }
    public void setFailureReason(String failureReason) { this.failureReason = failureReason; }
    public Instant getInitiatedAt() { return initiatedAt; }
    public Instant getCompletedAt() { return completedAt; }
    public void setCompletedAt(Instant completedAt) { this.completedAt = completedAt; }
    public Instant getWebhookReceivedAt() { return webhookReceivedAt; }
    public void setWebhookReceivedAt(Instant webhookReceivedAt) { this.webhookReceivedAt = webhookReceivedAt; }

    public enum UpiTransactionType { COLLECT, PAY }

    public enum UpiStatus {
        INITIATED,       // request built, not yet sent to partner
        SENT_TO_PARTNER, // partner acknowledged receipt
        PENDING,         // partner processing (typical for COLLECT awaiting payer approval)
        SUCCESS,
        FAILED,
        TIMED_OUT,       // no webhook received within SLA — needs reconciliation
        EXPIRED          // COLLECT request expired unapproved
    }
}
