package com.fintech.upi.dto;

import com.fintech.upi.model.UpiTransaction;

import java.time.Instant;
import java.util.UUID;

public record UpiPaymentResponse(
        UUID orchestrationTransactionId,
        UpiTransaction.UpiStatus status,
        String npciRrn,
        String partnerReference,
        String failureReason,
        Instant initiatedAt,
        Instant completedAt
) {
    public static UpiPaymentResponse from(UpiTransaction txn) {
        return new UpiPaymentResponse(
                txn.getOrchestrationTransactionId(),
                txn.getStatus(),
                txn.getNpciRrn(),
                txn.getPartnerReference(),
                txn.getFailureReason(),
                txn.getInitiatedAt(),
                txn.getCompletedAt()
        );
    }
}
