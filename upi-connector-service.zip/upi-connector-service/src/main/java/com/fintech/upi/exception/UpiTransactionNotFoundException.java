package com.fintech.upi.exception;

public class UpiTransactionNotFoundException extends RuntimeException {
    public UpiTransactionNotFoundException(String message) {
        super(message);
    }
}
