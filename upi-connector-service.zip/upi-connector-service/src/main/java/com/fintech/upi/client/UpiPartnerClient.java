package com.fintech.upi.client;

import com.fintech.upi.model.UpiTransaction;
import reactor.core.publisher.Mono;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Abstraction over the actual UPI BaaS/PSP partner (Setu, Cashfree, Decentro,
 * RazorpayX...). Swapping providers — or adding a second one for failover —
 * means implementing this interface again, without touching the service layer
 * or database schema. Keeps the platform from being hard-coupled to one vendor.
 */
public interface UpiPartnerClient {

    Mono<PartnerInitiationResult> initiatePayment(
            UUID orchestrationTransactionId,
            UpiTransaction.UpiTransactionType type,
            String payerVpa,
            String payeeVpa,
            BigDecimal amount,
            String currency,
            String narration
    );

    Mono<PartnerStatusResult> checkStatus(String partnerReference);

    record PartnerInitiationResult(
            String partnerReference,
            String status,       // partner's raw status string
            String npciRrn        // may be null until the payment settles
    ) {}

    record PartnerStatusResult(
            String status,
            String npciRrn,
            String failureReason
    ) {}
}
