package com.fintech.upi.repository;

import com.fintech.upi.model.UpiTransaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface UpiTransactionRepository extends JpaRepository<UpiTransaction, UUID> {

    Optional<UpiTransaction> findByOrchestrationTransactionId(UUID orchestrationTransactionId);

    Optional<UpiTransaction> findByPartnerReference(String partnerReference);

    /**
     * Used by the reconciliation job to find transactions stuck in a
     * non-terminal state past a reasonable SLA — these need an active status
     * check against the partner rather than waiting indefinitely for a webhook.
     */
    List<UpiTransaction> findByStatusInAndInitiatedAtBefore(
            List<UpiTransaction.UpiStatus> statuses, Instant cutoff);
}
