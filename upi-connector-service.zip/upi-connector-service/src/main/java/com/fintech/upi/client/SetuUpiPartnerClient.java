package com.fintech.upi.client;

import com.fintech.upi.model.UpiTransaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.Map;
import java.util.UUID;

/**
 * Example implementation wired for a Setu-style UPI payout/collect API.
 *
 * IMPORTANT: field names, endpoint paths, and auth headers below are
 * illustrative placeholders based on typical BaaS API shapes — they must be
 * verified and adjusted against the partner's current API documentation
 * before going live. Treat this as a structural template, not a drop-in
 * production integration.
 */
@Component
public class SetuUpiPartnerClient implements UpiPartnerClient {

    private static final Logger log = LoggerFactory.getLogger(SetuUpiPartnerClient.class);

    private final WebClient webClient;

    public SetuUpiPartnerClient(
            WebClient.Builder webClientBuilder,
            @Value("${upi.partner.setu.base-url}") String baseUrl,
            @Value("${upi.partner.setu.api-key}") String apiKey,
            @Value("${upi.partner.setu.scheme-id}") String schemeId) {

        this.webClient = webClientBuilder
                .baseUrl(baseUrl)
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .defaultHeader("x-api-key", apiKey)
                .defaultHeader("x-scheme-id", schemeId)
                .build();
    }

    @Override
    public Mono<PartnerInitiationResult> initiatePayment(
            UUID orchestrationTransactionId,
            UpiTransaction.UpiTransactionType type,
            String payerVpa,
            String payeeVpa,
            BigDecimal amount,
            String currency,
            String narration) {

        String path = type == UpiTransaction.UpiTransactionType.COLLECT
                ? "/upi/collect-requests"
                : "/upi/payouts";

        Map<String, Object> body = Map.of(
                "clientReferenceId", orchestrationTransactionId.toString(),
                "payerVpa", payerVpa,
                "payeeVpa", payeeVpa,
                "amount", amount,
                "currency", currency,
                "remarks", narration == null ? "" : narration
        );

        return webClient.post()
                .uri(path)
                .bodyValue(body)
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(10))
                .retryWhen(Retry.backoff(2, Duration.ofMillis(500))
                        .filter(this::isRetryable))
                .map(this::mapInitiationResponse)
                .doOnError(ex -> log.error("Setu initiatePayment failed for txn {}: {}",
                        orchestrationTransactionId, ex.getMessage()));
    }

    @Override
    public Mono<PartnerStatusResult> checkStatus(String partnerReference) {
        return webClient.get()
                .uri("/upi/transactions/{ref}", partnerReference)
                .retrieve()
                .bodyToMono(Map.class)
                .timeout(Duration.ofSeconds(10))
                .map(this::mapStatusResponse);
    }

    @SuppressWarnings("unchecked")
    private PartnerInitiationResult mapInitiationResponse(Map<String, Object> response) {
        return new PartnerInitiationResult(
                (String) response.get("id"),
                (String) response.get("status"),
                (String) response.get("npciTxnId")
        );
    }

    @SuppressWarnings("unchecked")
    private PartnerStatusResult mapStatusResponse(Map<String, Object> response) {
        return new PartnerStatusResult(
                (String) response.get("status"),
                (String) response.get("npciTxnId"),
                (String) response.get("errorReason")
        );
    }

    /**
     * Only retry on transient failures (timeouts, 5xx). Never retry a 4xx —
     * that's a validation/business error that will fail identically every
     * time, and retrying it risks the partner interpreting it as a new request.
     */
    private boolean isRetryable(Throwable ex) {
        String message = ex.getMessage();
        return message != null && (message.contains("timeout") || message.contains("5"));
    }
}
