package com.fintech.upi.controller;

import com.fintech.upi.dto.UpiPaymentRequest;
import com.fintech.upi.dto.UpiPaymentResponse;
import com.fintech.upi.service.UpiPaymentService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/upi")
public class UpiController {

    private final UpiPaymentService upiPaymentService;

    public UpiController(UpiPaymentService upiPaymentService) {
        this.upiPaymentService = upiPaymentService;
    }

    /**
     * Called exclusively by the Payment Orchestration Service after it has
     * decided UPI is the right rail and reserved the ledger movement.
     */
    @PostMapping("/payments")
    public ResponseEntity<UpiPaymentResponse> initiatePayment(@Valid @RequestBody UpiPaymentRequest request) {
        return ResponseEntity.ok(upiPaymentService.initiatePayment(request));
    }

    @GetMapping("/payments/{orchestrationTransactionId}")
    public ResponseEntity<UpiPaymentResponse> getStatus(@PathVariable UUID orchestrationTransactionId) {
        return ResponseEntity.ok(upiPaymentService.getStatus(orchestrationTransactionId));
    }
}
