package com.fintech.upi.config;

import com.fintech.upi.service.UpiPaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@EnableScheduling
public class ReconciliationScheduler {

    private static final Logger log = LoggerFactory.getLogger(ReconciliationScheduler.class);

    private final UpiPaymentService upiPaymentService;

    public ReconciliationScheduler(UpiPaymentService upiPaymentService) {
        this.upiPaymentService = upiPaymentService;
    }

    /**
     * Runs every 60 seconds. Webhooks from UPI partners can be missed,
     * delayed, or (rarely) never sent — this is the backstop that guarantees
     * every transaction eventually reaches a terminal state instead of
     * hanging forever in PENDING.
     */
    @Scheduled(fixedDelay = 60_000)
    public void reconcile() {
        try {
            upiPaymentService.reconcilePendingTransactions();
        } catch (Exception ex) {
            log.error("Reconciliation job failed: {}", ex.getMessage(), ex);
        }
    }
}
