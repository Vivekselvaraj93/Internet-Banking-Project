package com.fintech.upi.controller;

import com.fintech.upi.dto.UpiWebhookPayload;
import com.fintech.upi.service.UpiPaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.HexFormat;
import java.util.Map;

/**
 * Receives async status callbacks from the UPI BaaS partner. This endpoint
 * is exposed outside the cluster via the API Gateway (unauthenticated by
 * user JWT, since the caller is the partner, not our own client) but MUST
 * be protected by HMAC signature verification so an attacker can't forge
 * fake "payment successful" callbacks.
 */
@RestController
public class UpiWebhookController {

    private static final Logger log = LoggerFactory.getLogger(UpiWebhookController.class);

    private final UpiPaymentService upiPaymentService;
    private final String webhookSigningSecret;

    public UpiWebhookController(UpiPaymentService upiPaymentService,
                                 @Value("${upi.partner.setu.webhook-secret}") String webhookSigningSecret) {
        this.upiPaymentService = upiPaymentService;
        this.webhookSigningSecret = webhookSigningSecret;
    }

    @PostMapping("/upi/webhooks/setu")
    public ResponseEntity<Map<String, String>> handleWebhook(
            @RequestHeader(value = "X-Setu-Signature", required = false) String signature,
            @RequestBody String rawBody) {

        if (!isValidSignature(rawBody, signature)) {
            log.warn("Rejected UPI webhook with invalid signature");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "invalid_signature"));
        }

        UpiWebhookPayload payload = parsePayload(rawBody);
        upiPaymentService.handleWebhook(payload);

        return ResponseEntity.ok(Map.of("status", "received"));
    }

    private boolean isValidSignature(String rawBody, String providedSignature) {
        if (providedSignature == null) return false;
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(webhookSigningSecret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] computedHash = mac.doFinal(rawBody.getBytes(StandardCharsets.UTF_8));
            String computedSignature = HexFormat.of().formatHex(computedHash);
            return constantTimeEquals(computedSignature, providedSignature);
        } catch (Exception ex) {
            log.error("Webhook signature verification failed: {}", ex.getMessage());
            return false;
        }
    }

    // Prevents timing-attack-based signature guessing
    private boolean constantTimeEquals(String a, String b) {
        if (a.length() != b.length()) return false;
        int result = 0;
        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }
        return result == 0;
    }

    private UpiWebhookPayload parsePayload(String rawBody) {
        // In a real implementation, use Jackson ObjectMapper to deserialize;
        // simplified here for illustration. Actual field mapping depends on
        // the partner's exact webhook schema.
        try {
            com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
            return mapper.readValue(rawBody, UpiWebhookPayload.class);
        } catch (Exception ex) {
            throw new IllegalArgumentException("Malformed webhook payload", ex);
        }
    }
}
