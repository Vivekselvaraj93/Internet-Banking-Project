package com.fintech.upi.service;

import com.fintech.upi.client.UpiPartnerClient;
import com.fintech.upi.dto.UpiPaymentRequest;
import com.fintech.upi.dto.UpiPaymentResponse;
import com.fintech.upi.dto.UpiWebhookPayload;
import com.fintech.upi.exception.DuplicateTransactionException;
import com.fintech.upi.exception.UpiTransactionNotFoundException;
import com.fintech.upi.model.UpiTransaction;
import com.fintech.upi.repository.UpiTransactionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;

@Service
public class UpiPaymentService {

    private static final Logger log = LoggerFactory.getLogger(UpiPaymentService.class);

    private final UpiTransactionRepository repository;
    private final UpiPartnerClient partnerClient;

    public UpiPaymentService(UpiTransactionRepository repository, UpiPartnerClient partnerClient) {
        this.repository = repository;
        this.partnerClient = partnerClient;
    }

    /**
     * Initiates a UPI payment. Idempotent on orchestrationTransactionId: if
     * the Payment Orchestration Service retries (e.g. after a gateway
     * timeout), we return the existing record instead of double-initiating
     * a real-money UPI transaction with the partner.
     */
    @Transactional
    public UpiPaymentResponse initiatePayment(UpiPaymentRequest request) {
        var existing = repository.findByOrchestrationTransactionId(request.getOrchestrationTransactionId());
        if (existing.isPresent()) {
            log.info("UPI transaction for orchestration txn {} already exists, returning existing state",
                    request.getOrchestrationTransactionId());
            return UpiPaymentResponse.from(existing.get());
        }

        UpiTransaction txn = new UpiTransaction();
        txn.setOrchestrationTransactionId(request.getOrchestrationTransactionId());
        txn.setType(request.getType());
        txn.setPayerVpa(request.getPayerVpa());
        txn.setPayeeVpa(request.getPayeeVpa());
        txn.setAmount(request.getAmount());
        txn.setCurrency(request.getCurrency());
        txn.setPartnerProvider("setu");
        txn = repository.save(txn);

        try {
            UpiPartnerClient.PartnerInitiationResult result = partnerClient.initiatePayment(
                    request.getOrchestrationTransactionId(),
                    request.getType(),
                    request.getPayerVpa(),
                    request.getPayeeVpa(),
                    request.getAmount(),
                    request.getCurrency(),
                    request.getNarration()
            ).block(); // synchronous boundary at the service layer; the client itself uses non-blocking I/O

            txn.setPartnerReference(result.partnerReference());
            txn.setNpciRrn(result.npciRrn());
            txn.setStatus(mapPartnerStatus(result.status()));

            if (txn.getStatus() == UpiTransaction.UpiStatus.SUCCESS
                    || txn.getStatus() == UpiTransaction.UpiStatus.FAILED) {
                txn.setCompletedAt(Instant.now());
            }

        } catch (Exception ex) {
            log.error("Failed to initiate UPI payment with partner for txn {}: {}",
                    request.getOrchestrationTransactionId(), ex.getMessage());
            // Leave status as INITIATED / mark SENT_TO_PARTNER=false so the
            // reconciliation job retries — do NOT mark FAILED here, since we
            // don't actually know if the partner received the request before
            // the error (e.g. a timeout could mean it succeeded on their side).
            txn.setFailureReason("Partner call failed: " + ex.getMessage());
        }

        txn = repository.save(txn);
        return UpiPaymentResponse.from(txn);
    }

    @Transactional(readOnly = true)
    public UpiPaymentResponse getStatus(UUID orchestrationTransactionId) {
        UpiTransaction txn = repository.findByOrchestrationTransactionId(orchestrationTransactionId)
                .orElseThrow(() -> new UpiTransactionNotFoundException(
                        "No UPI transaction found for orchestration txn " + orchestrationTransactionId));
        return UpiPaymentResponse.from(txn);
    }

    /**
     * Processes an async webhook from the partner reporting final status.
     * Never trust this alone as the only path to a terminal state — see
     * reconcilePendingTransactions() for the polling backstop.
     */
    @Transactional
    public void handleWebhook(UpiWebhookPayload payload) {
        UpiTransaction txn = repository.findByPartnerReference(payload.getPartnerReference())
                .orElseThrow(() -> new UpiTransactionNotFoundException(
                        "No UPI transaction found for partner reference " + payload.getPartnerReference()));

        if (txn.getStatus() == UpiTransaction.UpiStatus.SUCCESS
                || txn.getStatus() == UpiTransaction.UpiStatus.FAILED) {
            log.info("Webhook received for already-terminal txn {} — ignoring duplicate", txn.getId());
            return;
        }

        txn.setStatus(mapPartnerStatus(payload.getStatus()));
        txn.setNpciRrn(payload.getNpciRrn());
        txn.setFailureReason(payload.getFailureReason());
        txn.setWebhookReceivedAt(Instant.now());

        if (txn.getStatus() == UpiTransaction.UpiStatus.SUCCESS
                || txn.getStatus() == UpiTransaction.UpiStatus.FAILED) {
            txn.setCompletedAt(Instant.now());
        }

        repository.save(txn);
        log.info("Updated UPI txn {} to status {} via webhook", txn.getId(), txn.getStatus());
    }

    /**
     * Reconciliation backstop: for any transaction stuck in a non-terminal
     * state past a reasonable SLA (webhooks can be missed/delayed/never
     * sent), actively poll the partner's status API. Intended to be called
     * by a scheduled job (see ReconciliationScheduler).
     */
    @Transactional
    public void reconcilePendingTransactions() {
        Instant cutoff = Instant.now().minus(2, ChronoUnit.MINUTES);
        List<UpiTransaction> stuck = repository.findByStatusInAndInitiatedAtBefore(
                List.of(UpiTransaction.UpiStatus.SENT_TO_PARTNER, UpiTransaction.UpiStatus.PENDING),
                cutoff
        );

        for (UpiTransaction txn : stuck) {
            if (txn.getPartnerReference() == null) continue;

            try {
                UpiPartnerClient.PartnerStatusResult result =
                        partnerClient.checkStatus(txn.getPartnerReference()).block();

                UpiTransaction.UpiStatus newStatus = mapPartnerStatus(result.status());
                if (newStatus != txn.getStatus()) {
                    txn.setStatus(newStatus);
                    txn.setNpciRrn(result.npciRrn());
                    txn.setFailureReason(result.failureReason());
                    if (newStatus == UpiTransaction.UpiStatus.SUCCESS
                            || newStatus == UpiTransaction.UpiStatus.FAILED) {
                        txn.setCompletedAt(Instant.now());
                    }
                    repository.save(txn);
                    log.info("Reconciliation updated UPI txn {} to {}", txn.getId(), newStatus);
                }
            } catch (Exception ex) {
                log.warn("Reconciliation status check failed for txn {}: {}", txn.getId(), ex.getMessage());
            }
        }

        // Anything past a much longer cutoff with still no resolution gets
        // flagged TIMED_OUT for manual ops review rather than polled forever.
        Instant hardCutoff = Instant.now().minus(30, ChronoUnit.MINUTES);
        List<UpiTransaction> timedOut = repository.findByStatusInAndInitiatedAtBefore(
                List.of(UpiTransaction.UpiStatus.SENT_TO_PARTNER, UpiTransaction.UpiStatus.PENDING),
                hardCutoff
        );
        for (UpiTransaction txn : timedOut) {
            txn.setStatus(UpiTransaction.UpiStatus.TIMED_OUT);
            repository.save(txn);
            log.error("UPI txn {} marked TIMED_OUT after 30 minutes unresolved — needs manual review", txn.getId());
        }
    }

    private UpiTransaction.UpiStatus mapPartnerStatus(String partnerStatus) {
        if (partnerStatus == null) return UpiTransaction.UpiStatus.SENT_TO_PARTNER;
        return switch (partnerStatus.toUpperCase()) {
            case "SUCCESS", "COMPLETED" -> UpiTransaction.UpiStatus.SUCCESS;
            case "FAILED", "REJECTED", "DECLINED" -> UpiTransaction.UpiStatus.FAILED;
            case "EXPIRED" -> UpiTransaction.UpiStatus.EXPIRED;
            case "PENDING", "IN_PROGRESS" -> UpiTransaction.UpiStatus.PENDING;
            default -> UpiTransaction.UpiStatus.SENT_TO_PARTNER;
        };
    }
}
